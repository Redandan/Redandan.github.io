((a,b)=>{a[b]=a[b]||{}})(self,"$__dart_deferred_initializers__")
$__dart_deferred_initializers__.current=function(a,b,c,$){var A,B
A=c[0]
B=c[329]
var z=a.updateTypes([]);(function constants(){B.F4=new A.a0(58240,"MaterialIcons",!1)})()};
(a=>{a["YNeyjboTlDUCj1b+Wvo8kAgQjEo="]=a.current})($__dart_deferred_initializers__);