((a,b)=>{a[b]=a[b]||{}})(self,"$__dart_deferred_initializers__")
$__dart_deferred_initializers__.current=function(a,b,c,$){var A,B,C
A=c[0]
B=c[381]
C=c[708]
var z=a.updateTypes([]);(function constants(){C.ae1=new A.aX(1/0,14,6,B.x2,null)})()};
(a=>{a["VPFAsLnNOoJdaZg8sYOMJVcgPIA="]=a.current})($__dart_deferred_initializers__);