((a,b)=>{a[b]=a[b]||{}})(self,"$__dart_deferred_initializers__")
$__dart_deferred_initializers__.current=function(a,b,c,$){var J,A,B,K,L,F,G,M,H,N,O,E,P,C={aBW:function aBW(d,e,f,g,h,i){var _=this
_.a=d
_.b=e
_.c=f
_.d=g
_.e=h
_.f=i},aOh:function aOh(d,e,f,g,h,i){var _=this
_.a=d
_.b=e
_.c=f
_.d=g
_.e=h
_.f=i},
ewh(){return new C.I7(null)},
I7:function I7(d){this.a=d},
b_C:function b_C(d){this.d=d
this.c=this.a=null},
cPv:function cPv(d){this.a=d},
cPu:function cPu(){},
cPt:function cPt(d,e){this.a=d
this.b=e},
cPr:function cPr(d){this.a=d},
cPs:function cPs(d){this.a=d},
cPo:function cPo(d,e){this.a=d
this.b=e},
cPn:function cPn(d,e){this.a=d
this.b=e},
cPq:function cPq(d,e){this.a=d
this.b=e},
cPp:function cPp(d,e){this.a=d
this.b=e}},D,Q,I,R,S,T,U,V
J=c[1]
A=c[0]
B=c[2]
K=c[351]
L=c[352]
F=c[414]
G=c[594]
M=c[373]
H=c[260]
N=c[502]
O=c[597]
E=c[279]
P=c[270]
C=a.updateHolder(c[40],C)
D=c[595]
Q=c[513]
I=c[458]
R=c[349]
S=c[359]
T=c[319]
U=c[596]
V=c[263]
C.aBW.prototype={}
C.aOh.prototype={}
C.I7.prototype={
P(){return new C.b_C(new A.ai(B.N,$.a9()))}}
C.b_C.prototype={
q(){var x=this.d
x.ok$=$.a9()
x.k4$=0
this.a5()},
u(d){var x,w,v,u,t,s,r=this,q=null,p=y.J,o=A.f(d,B.b,p).gaWv(),n=A.f(d,B.b,p).gVy(),m=r.cV5(d),l=A.f(d,B.b,p),k=l.gaWp()
l=l.gaWo()
x=A.t(d).ax
w=A.G(8)
v=x.ry
if(v==null){v=x.E
if(v==null)v=x.k3}v=A.aL(v.A(0.14),B.u,1)
u=x.k3
t=A.I(q,q,u,q,q,q,q,q,q,q,q,16,q,q,q,q,q,!0,q,q,q,q,q,q,q,q)
p=A.f(d,B.b,p).gaWn()
s=A.I(q,q,u.A(0.541),q,q,q,q,q,q,q,q,16,q,q,q,q,q,!0,q,q,q,q,q,q,q,q)
u=A.Q(G.ng,u.A(0.541),q,q,q)
return P.KD(B.aV,A.a([m,B.a8,new E.iF(k,new A.c6(new A.S(x.k2,q,v,w,q,q,B.r),B.aw,A.by(q,B.O,!1,q,!0,B.q,q,A.bA(),r.d,q,q,q,q,q,2,A.aI(q,new A.dH(4,A.G(12),B.C),q,B.D,q,q,q,q,!0,q,q,q,q,q,q,B.a5,!0,q,q,q,q,q,q,q,q,q,q,q,q,q,s,p,q,q,q,q,q,q,q,q,q,!0,!0,!1,q,u,q,q,q,q,q,q,q,q,q,q,q,q),B.w,!0,q,!0,q,!1,q,B.a4,q,q,q,q,q,q,q,q,q,1,q,q,!1,"\u2022",q,q,q,q,q,!1,q,q,!1,q,!0,q,B.X,q,q,q,q,q,q,q,q,q,q,q,t,!0,B.L,q,B.M,q,q,q,q),q),G.ng,l,q),B.a8,r.cT9(d)],y.p),F.jk,new C.cPv(r),B.cv,n,o)},
cV5(d){var x=A.f(d,B.b,y.J),w=x.gaWj(),v=x.gaWk()
return new E.iF(w,A.d4(new C.cPt(this,x)),F.jk,v,null)},
c68(d,e,f,g,h,i,j){var x,w,v,u,t=null,s=A.t(d),r=f?s.ax.b.A(0.055):t,q=f?s.ax.b.A(0.24):t,p=s.ax,o=p.b,n=f?o:o.A(0.1),m=A.G(8)
n=A.X(t,A.Q(g,f?B.G:o,t,t,26),B.o,t,t,new A.S(n,t,t,m,t,t,B.r),t,t,t,t,B.D,t,t,t)
m=p.k3
x=A.d(h,t,t,t,t,t,A.I(t,t,m,t,t,t,t,t,t,t,t,16,t,t,B.B,t,t,!0,t,t,t,t,t,t,t,t),t,t,t)
w=o.A(0.08)
v=A.G(99)
u=y.p
v=A.P(A.w(A.a([A.bh(B.a1,A.a([x,A.X(t,A.d(e,t,t,t,t,t,A.I(t,t,o,t,t,t,t,t,t,t,t,11,t,t,B.B,t,t,!0,t,t,t,t,t,t,t,t),t,t,t),B.o,t,t,new A.S(w,t,t,v,t,t,B.r),t,t,t,t,L.n1,t,t,t)],u),B.by,t,4,8),B.Q,A.d(j,t,t,t,t,t,A.I(t,t,m.A(0.62),t,t,t,t,t,t,t,t,13,t,t,t,t,1.35,!0,t,t,t,t,t,t,t,t),t,t,t)],u),B.m,t,B.e,B.f,0,B.j),1,t)
p=p.rx
return A.bb(r,q,A.z(A.a([n,B.ak,v,B.z,A.Q(B.kh,p==null?m:p,t,t,20)],u),B.l,t,B.e,B.f,0,t,t),t,B.K,i,B.aW,!1,h)},
cT9(d){var x,w,v,u,t,s,r=y.J,q=A.f(d,B.b,r),p=q.gaVP()
q=q.gaVQ()
r=A.f(d,B.b,r)
x=y.N
w=y.K
v=y.x
u=y.z
t=y.m
s=y.U
r=A.T(new A.C(A.a([A.Z(["title",r.gaVR(),"icon",B.S5,"isExpanded",!1,"questions",A.a([A.Z(["question",r.gaVF(),"answer",r.ga5v(),"homeScreenGuide",!0],x,w),A.Z(["question",r.gaVL(),"answer",r.gaVK(),"action",A.Z(["label",r.gaWw(),"route","chatgpt_mcp_guide"],x,x)],x,w)],v)],x,u),A.Z(["title",r.gaVE(),"icon",D.aPL,"isExpanded",!1,"questions",A.a([A.Z(["question",r.gaVY(),"answer",r.gaVZ()],x,x),A.Z(["question",r.gaW_(),"answer",r.gaW0()],x,x)],t)],x,u),A.Z(["title",r.gaWd(),"icon",B.bZ,"isExpanded",!1,"questions",A.a([A.Z(["question",r.gaW1(),"answer",r.gaW2()],x,x),A.Z(["question",r.gaWt(),"answer",r.gaWu()],x,x),A.Z(["question",r.gaW3(),"answer",r.gaW4()],x,x)],t)],x,u),A.Z(["title",r.gaWi(),"icon",B.kk,"isExpanded",!1,"questions",A.a([A.Z(["question",r.gaWe(),"answer",r.gaWf()],x,x),A.Z(["question",r.gaWg(),"answer",r.gaWh()],x,x),A.Z(["question",r.gaWb(),"answer",r.gaWc()],x,x),A.Z(["question",r.gaW7(),"answer",r.gaW8(),"action",A.Z(["label",r.gaWx(),"route","seller_guidelines"],x,x)],x,w)],v)],x,u),A.Z(["title",r.gaWq(),"icon",B.d4,"isExpanded",!1,"questions",A.a([A.Z(["question",r.gaVW(),"answer",r.gaVX()],x,x),A.Z(["question",r.gaWl(),"answer",r.gaWm()],x,x)],t)],x,u)],y.t),new C.cPo(this,d),s),s.k("aj.E"))
return new E.iF(p,A.w(r,B.l,null,B.e,B.f,0,B.j),N.h8,q,null)},
cT8(d,e){var x,w,v,u,t,s=null,r=A.t(d),q=A.f(d,B.b,y.J)
q.toString
x=A.t(d).cqk(B.a5)
q=q.gaVI()
w=r.ax
v=w.b
u=v.A(0.1)
t=A.G(8)
t=A.X(s,A.Q(y.Z.a(e.i(0,"icon")),v,s,s,20),B.o,s,s,new A.S(u,s,s,t,s,s,B.r),s,s,s,s,B.au,s,s,s)
w=A.d(A.b8(e.i(0,"title")),s,s,s,s,s,A.I(s,s,w.k3,s,s,s,s,s,s,s,s,16,s,s,B.T,s,s,!0,s,s,s,s,s,s,s,s),s,s,s)
u=J.ds(y.D.a(e.i(0,"questions")),new C.cPn(this,d),y.l)
v=A.T(u,u.$ti.k("aj.E"))
return A.bb(s,s,new A.nV(x,H.DT(v,s,s,!1,q,t,!1,s,s,w,s),s),s,K.cF,s,B.K,!1,s)},
cV4(d,e){var x,w,v,u,t,s,r,q,p,o,n,m=this,l=null,k="question",j="action",i=A.t(d).ax,h=i.ry
if(h==null){h=i.E
if(h==null)h=i.k3}h=h.A(0.2)
x=A.t(d).cqk(B.a5)
w=A.b8(e.i(0,k))
v=i.k3
u=A.d(A.b8(e.i(0,k)),l,l,l,l,l,A.I(l,l,v,l,l,l,l,l,l,l,l,14,l,l,B.a6,l,l,!0,l,l,l,l,l,l,l,l),l,l,l)
t=y.p
v=A.a([A.d(A.b8(e.i(0,"answer")),l,l,l,l,l,A.I(l,l,v.A(0.702),l,l,l,l,l,l,l,l,14,l,l,l,l,1.5,!0,l,l,l,l,l,l,l,l),l,l,l)],t)
if(J.p(e.i(0,"homeScreenGuide"),!0)){s=A.f(d,B.b,y.J)
s.toString
r=m.cTj(d)
q=s.gPG()
p=y.s
o=A.a([s.ga5B(),s.ga5C(),s.ga5D(),s.gaW6()],p)
q=m.bJ_(d,D.QM,s.ga5A(),o,q)
o=s.gPF()
n=A.a([s.ga5w(),s.gPD(),s.gaVH(),s.gPE()],p)
o=m.bJ_(d,I.En,s.gaVG(),n,o)
n=s.gGw()
p=A.a([s.ga5x(),s.gaVN(),s.gGv(),s.gaVO()],p)
B.d.B(v,A.a([B.n,A.w(A.a([r,B.n,q,B.S,o,B.S,m.bJ_(d,R.p9,s.gaVM(),p,n)],t),B.m,l,B.e,B.f,0,B.j)],t))}if(e.i(0,j)!=null){s=A.b8(J.ax(e.i(0,j),"label"))
r=A.co(i.b,l,l,l,l,B.en,new A.b6(A.G(8),B.C),l,l,l)
B.d.B(v,A.a([B.n,new A.ad(1/0,l,A.R(l,!0,l,A.c0(A.d(A.b8(J.ax(e.i(0,j),"label")),l,l,l,l,l,D.bMx,l,l,l),l,new C.cPq(e,d),r),!1,l,l,l,!1,l,!1,l,l,l,l,l,l,l,l,l,l,l,s,l,l,l,l,l,l,l,l,l,l,l,l,l,l,l,l,l,l,l,l,l,l,l,l,l,l,l,l,l,l,B.p,l),l)],t))}return new A.c6(new A.S(i.k2,l,new A.dJ(new A.aS(h,0.5,B.u,-1),B.C,B.C,B.C),l,l,l,B.r),B.aw,new A.nV(x,H.DT(A.a([new A.J(B.D,A.w(v,B.m,l,B.e,B.f,0,B.j),l)],t),l,l,!1,w,l,!1,l,l,u,l),l),l)},
cTj(d){var x,w,v,u=null,t=A.t(d),s=A.f(d,B.b,y.J)
s.toString
x=t.ax.b
w=x.A(0.06)
v=A.G(8)
return new A.c6(new A.S(w,u,A.aL(x.A(0.16),B.u,1),v,u,u,B.r),B.aw,new A.J(B.D,A.d4(new C.cPp(this,s)),u),u)},
bJ7(d,e,a0,a1,a2){var x,w,v,u,t,s,r,q,p,o,n,m=null,l=A.t(d).ax,k=l.k3,j=A.d(a2,m,m,m,m,m,A.I(m,m,k,m,m,m,m,m,m,m,m,13,m,m,B.T,m,m,!0,m,m,m,m,m,m,m,m),B.aE,m,m),i=l.k2,h=A.G(22),g=l.ry,f=g==null
if(f){x=l.E
if(x==null)x=k}else x=g
x=A.aL(x.A(0.35),B.u,2)
w=A.a([new A.cm(0,B.aQ,B.W.A(0.08),B.ku,18)],y.V)
if(f){g=l.E
if(g==null)g=k}g=A.X(m,m,B.o,m,m,new A.S(g.A(0.35),m,m,A.G(99),m,m,B.r),m,5,m,m,m,m,m,44)
f=l.RG
f=(f==null?i:f).A(0.58)
v=A.G(12)
u=l.rx
t=u==null
s=y.p
r=A.z(A.a([A.Q(M.eI,t?k:u,m,m,12),B.aO,A.P(A.X(m,m,B.o,m,m,new A.S(i,m,m,A.G(99),m,m,B.r),m,10,m,m,m,m,m,m),1,m)],s),B.l,m,B.e,B.f,0,m,m)
l=l.b
q=A.G(14)
q=A.X(m,A.Q(a1,B.G,m,m,28),B.o,m,m,new A.S(l,m,m,q,m,m,B.r),m,54,m,m,m,m,m,54)
p=l.A(0.12)
o=A.G(8)
n=A.aL(l.A(0.24),B.u,1)
o=A.X(m,A.d(a0,m,m,m,m,m,A.I(m,m,l,m,m,m,m,m,m,m,m,12,m,m,B.B,m,m,!0,m,m,m,m,m,m,m,m),B.aE,m,m),B.o,m,m,new A.S(p,m,n,o,m,m,B.r),m,m,m,m,D.aIg,m,m,1/0)
return A.w(A.a([j,B.v,A.X(m,A.w(A.a([g,B.S,A.P(new A.c6(new A.S(f,m,m,v,m,m,B.r),B.aw,new A.J(B.au,A.w(A.a([r,B.n,q,B.S,o,B.bO,A.d(e,m,m,m,m,m,A.I(m,m,t?k:u,m,m,m,m,m,m,m,m,11,m,m,m,m,m,!0,m,m,m,m,m,m,m,m),B.aE,m,m)],s),B.l,m,B.e,B.f,0,B.j),m),m),1,m)],s),B.l,m,B.e,B.f,0,B.j),B.o,m,m,new A.S(i,m,x,h,w,m,B.r),m,230,m,m,T.kd,m,m,150)],s),B.l,m,B.e,B.f,0,B.j)},
bJ_(d,e,f,g,h){var x,w,v,u,t,s,r,q,p,o,n=null,m=A.t(d).ax,l=m.RG
l=(l==null?m.k2:l).A(0.32)
x=A.G(8)
w=m.ry
if(w==null){w=m.E
if(w==null)w=m.k3}w=A.aL(w.A(0.14),B.u,1)
v=m.b
u=v.A(0.1)
t=A.G(8)
s=m.k3
r=y.p
t=A.a([A.z(A.a([A.X(n,A.Q(e,v,n,n,20),B.o,n,n,new A.S(u,n,n,t,n,n,B.r),n,n,n,n,B.au,n,n,n),B.aj,A.P(A.d(h,n,n,n,n,n,A.I(n,n,s,n,n,n,n,n,n,n,n,15,n,n,B.B,n,n,!0,n,n,n,n,n,n,n,n),n,n,n),1,n)],r),B.m,n,B.e,B.f,0,n,n),B.S],r)
for(q=0;q<4;q=p){p=q+1
v=g[q]
u=A.t(d).ax
o=new A.c_(99,99)
o=A.X(B.ax,A.d(""+p,n,n,n,n,n,U.adA,n,n,n),B.o,n,n,new A.S(u.b,n,n,new A.e1(o,o,o,o),n,n,B.r),n,22,n,n,n,n,n,22)
u=u.k3.A(0.78)
v=A.a([new A.dg(B.aa,B.e,B.f,B.m,n,B.j,n,0,A.a([o,B.aj,new A.dd(1,B.aK,A.d(v,n,n,n,n,n,new A.ag(!0,u,n,n,n,n,14,n,n,n,n,n,1.45,n,n,n,n,n,n,n,n,n,n,n,n,n),n,n,n),n)],r),n)],r)
if(q!==3)v.push(B.v)
B.d.B(t,v)}t.push(B.S)
m=m.rx
v=m==null
u=A.Q(B.bf,v?s:m,n,n,16)
t.push(A.z(A.a([u,B.aO,A.P(A.d(f,n,n,n,n,n,A.I(n,n,v?s:m,n,n,n,n,n,n,n,n,13,n,n,n,n,1.45,!0,n,n,n,n,n,n,n,n),n,n,n),1,n)],r),B.m,n,B.e,B.f,0,n,n))
return new A.c6(new A.S(l,n,w,x,n,n,B.r),B.aw,new A.J(B.D,A.w(t,B.m,n,B.e,B.f,0,B.j),n),n)}}
var z=a.updateTypes([])
C.cPv.prototype={
$0(){var x=0,w=A.l(y.H),v,u=this
var $async$$0=A.h(function(d,e){if(d===1)return A.i(e,w)
for(;;)switch(x){case 0:v=u.a.n(new C.cPu())
x=1
break
case 1:return A.j(v,w)}})
return A.k($async$$0,w)},
$S:3}
C.cPu.prototype={
$0(){},
$S:0}
C.cPt.prototype={
$2(d,e){var x,w,v=null,u=this.a,t=this.b,s=t.gaWr(),r=t.gaWs()
r=u.c68(d,t.gaVJ(),!0,B.lo,s,new C.cPr(d),r)
s=t.gaW9()
x=t.gaWa()
w=[r,u.c68(d,t.gaW5(),!1,Q.xp,s,new C.cPs(d),x)]
if(e.b<560)return A.w(A.a([w[0],B.S,w[1]],y.p),B.l,v,B.e,B.f,0,B.j)
return A.z(A.a([A.P(w[0],1,v),B.aj,A.P(w[1],1,v)],y.p),B.l,v,B.e,B.f,0,v,v)},
$S:58}
C.cPr.prototype={
$0(){A.aM(this.a,!1).f.aK(V.QO(null,"0"),y.X)},
$S:0}
C.cPs.prototype={
$0(){A.aM(this.a,!1).f.aK(D.aA_,y.X)},
$S:0}
C.cPo.prototype={
$1(d){return this.a.cT8(this.b,d)},
$S:551}
C.cPn.prototype={
$1(d){return this.a.cV4(this.b,d)},
$S:551}
C.cPq.prototype={
$0(){if(A.b3(J.ax(this.a.i(0,"action"),"route"))==="chatgpt_mcp_guide"){A.aM(this.b,!1).f.aK(O.BX,y.X)
return}A.aM(this.b,!1).f.aK(D.bzk,y.X)},
$S:0}
C.cPp.prototype={
$2(d,e){var x,w,v,u,t=null,s=this.a,r=this.b,q=r.gaVV()
q=s.bJ7(d,r.ga5z(),r.gyn(),D.QM,q)
x=r.gaVS()
x=s.bJ7(d,"Agora Market",r.ga5y(),S.EX,x)
w=r.gaVU()
v=[q,x,s.bJ7(d,r.gaVT(),"Agora",I.Qr,w)]
if(e.b<620){s=y.p
r=A.a([],s)
for(u=0;u<3;++u){q=A.a([v[u]],s)
if(u!==2)q.push(B.S)
B.d.B(r,q)}return A.w(r,B.a9,t,B.e,B.f,0,B.j)}s=y.p
r=A.a([],s)
for(u=0;u<3;++u){q=A.a([new A.dd(1,B.aK,v[u],t)],s)
if(u!==2)q.push(B.aj)
B.d.B(r,q)}return A.z(r,B.m,t,B.e,B.f,0,t,t)},
$S:58};(function inheritance(){var x=a.inheritMany,w=a.inherit
x(A.bS,[C.aBW,C.aOh])
w(C.I7,A.L)
w(C.b_C,A.U)
x(A.bs,[C.cPv,C.cPu,C.cPr,C.cPs,C.cPq])
x(A.c5,[C.cPt,C.cPp])
x(A.bt,[C.cPo,C.cPn])})()
A.aY(b.typeUniverse,JSON.parse('{"aBW":{"bS":["~"]},"aOh":{"bS":["~"]},"I7":{"L":[],"m":[]},"b_C":{"U":["I7"]}}'))
var y=(function rtii(){var x=A.F
return{J:x("bv"),Z:x("a_"),V:x("v<cm>"),x:x("v<a1<n,A>>"),m:x("v<a1<n,n>>"),t:x("v<a1<n,@>>"),s:x("v<n>"),p:x("v<m>"),D:x("a3<a1<n,@>>"),U:x("C<a1<n,@>,m>"),K:x("A"),N:x("n"),l:x("m"),z:x("@"),X:x("A?"),H:x("~")}})();(function constants(){D.aA_=new C.aBW("CustomerIssueRoute",null,B.af,B.af,null,"")
D.aIg=new A.ar(8,7,8,7)
D.QM=new A.a_(58189,"MaterialIcons",!1)
D.aPL=new A.a_(984824,"MaterialIcons",!1)
D.bzk=new C.aOh("SellerGuidelinesRoute",null,B.af,B.af,null,"")
D.bMx=new A.ag(!0,B.G,null,null,null,null,null,B.a6,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null)})()};
(a=>{a["2MX53OcbVkc1bt2cdzVl9eFDxGM="]=a.current})($__dart_deferred_initializers__);