((a,b)=>{a[b]=a[b]||{}})(self,"$__dart_deferred_initializers__")
$__dart_deferred_initializers__.current=function(a,b,c,$){var C,A={iR:function iR(d){this.a=d}},B
C=c[0]
A=a.updateHolder(c[187],A)
B=c[701]
A.iR.prototype={
l(d){return this.a},
A(){return this.a}}
var z=a.updateTypes([]);(function inheritance(){var y=a.inherit
y(A.iR,C.A)})();(function constants(){B.kL=new A.iR("HOME_DELIVERY")
B.iN=new A.iR("SEVEN_ELEVEN")
B.m5=new A.iR("FAMILY_MART")
B.qb=new A.iR("HILIFE")
B.qc=new A.iR("OK_MART")
B.aan=new A.iR("PLATFORM_DELIVERY")
B.aao=new A.iR("unknown_default_open_api")})()};
(a=>{a["DGlgHX475bJrICtPi6vwz4/SBvg="]=a.current})($__dart_deferred_initializers__);