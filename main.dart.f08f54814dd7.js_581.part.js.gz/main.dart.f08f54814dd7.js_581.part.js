((a,b)=>{a[b]=a[b]||{}})(self,"$__dart_deferred_initializers__")
$__dart_deferred_initializers__.current=function(a,b,c,$){var J,A,C,F,G,E,H,I,K,L,M,N,B={aBp:function aBp(d,e,f,g,h,i){var _=this
_.a=d
_.b=e
_.c=f
_.d=g
_.e=h
_.f=i},
eyF(){return new B.HZ(null)},
HZ:function HZ(d){this.a=d},
an4:function an4(d,e){var _=this
_.d=d
_.e=e
_.r=_.f=$
_.w=null
_.x=$
_.z=_.y=!1
_.c=_.a=null},
cEu:function cEu(){},
cEv:function cEv(d){this.a=d},
cEt:function cEt(d){this.a=d},
cEo:function cEo(d){this.a=d},
cEs:function cEs(d){this.a=d},
cEr:function cEr(){},
cEq:function cEq(d,e){this.a=d
this.b=e},
cEp:function cEp(d){this.a=d},
b_1:function b_1(d){this.a=d},
b_0:function b_0(d){this.a=d},
cEx:function cEx(){},
cEw:function cEw(){},
a4u:function a4u(d){this.a=d},
eyG(d,e,f,g,h,i){var x=A.b7("ChatSessionListState"),w=A.a([],y.Z)
w=new B.a9z(h,new A.a0I(),$.al().$1$0(y.d),x,D.O2,w,A.q(y.S,y.N),g,e,f,i,$.aa())
w.cQg(d,e,f,g,h,i)
return w},
Py:function Py(d,e){this.a=d
this.b=e},
a9z:function a9z(d,e,f,g,h,i,j,k,l,m,n,o){var _=this
_.a=$
_.b=d
_.c=!1
_.e=_.d=0
_.f=e
_.r=f
_.w=g
_.x=h
_.y=i
_.z=j
_.Q=null
_.as=0
_.at=!0
_.ay=_.ax=null
_.ch=k
_.CW=l
_.cx=m
_.cy=n
_.k4$=0
_.ok$=o
_.p2$=_.p1$=0},
bqU:function bqU(d){this.a=d},
bqS:function bqS(d,e,f){this.a=d
this.b=e
this.c=f},
bqP:function bqP(d,e){this.a=d
this.b=e},
bqO:function bqO(d,e){this.a=d
this.b=e},
bqQ:function bqQ(d,e){this.a=d
this.b=e},
bqR:function bqR(d,e){this.a=d
this.b=e},
bqT:function bqT(d,e){this.a=d
this.b=e},
bqK:function bqK(d,e){this.a=d
this.b=e},
bqL:function bqL(){},
bqM:function bqM(d){this.a=d},
bqN:function bqN(){},
bqJ:function bqJ(d){this.a=d},
bqV:function bqV(d,e){this.a=d
this.b=e},
bqW:function bqW(){},
bqX:function bqX(){},
a9y:function a9y(d,e,f,g,h){var _=this
_.c=d
_.d=e
_.e=f
_.r=g
_.a=h},
an3:function an3(d,e,f){var _=this
_.d=d
_.e=$
_.f=e
_.r=f
_.w=null
_.x=0
_.c=_.a=null},
cEn:function cEn(d){this.a=d},
cE8:function cE8(d){this.a=d},
cE5:function cE5(d){this.a=d},
cEk:function cEk(d){this.a=d},
cEj:function cEj(d,e){this.a=d
this.b=e},
cE6:function cE6(d){this.a=d},
cE7:function cE7(d){this.a=d},
cEm:function cEm(d,e){this.a=d
this.b=e},
cEl:function cEl(d,e){this.a=d
this.b=e},
cEi:function cEi(d){this.a=d},
cEf:function cEf(d,e){this.a=d
this.b=e},
cEg:function cEg(d,e){this.a=d
this.b=e},
cEh:function cEh(d,e){this.a=d
this.b=e},
cEb:function cEb(d){this.a=d},
cE9:function cE9(d,e){this.a=d
this.b=e},
cEa:function cEa(d,e){this.a=d
this.b=e},
cEe:function cEe(d){this.a=d},
cEc:function cEc(d,e){this.a=d
this.b=e},
cEd:function cEd(d,e){this.a=d
this.b=e}},D,O,P,Q
J=c[1]
A=c[0]
C=c[2]
F=c[239]
G=c[544]
E=c[297]
H=c[543]
I=c[140]
K=c[502]
L=c[247]
M=c[331]
N=c[267]
B=a.updateHolder(c[24],B)
D=c[541]
O=c[545]
P=c[542]
Q=c[457]
B.aBp.prototype={}
B.HZ.prototype={
R(){return new B.an4(new A.fB(0,!0,null,null,null,A.a([],y.F),$.aa()),A.b7("ChatSessionListPage"))}}
B.an4.prototype={
aZ(){var x,w,v,u,t,s,r=this
r.bB()
x=r.c
x.toString
r.w=A.cs(x,null,y.X)
x=r.c
x.toString
x=A.f(x,C.c,y.J)
x.toString
r.x=x
if(!r.y){w=$.al().$1$0(y.U)
x=r.r
x===$&&A.e()
v=r.x.ga4r()
x=B.eyG(w,r.x.gvZ(),r.x.ga21(),v,x,r.x.gD0())
r.f!==$&&A.aK()
r.f=x
r.y=!0}else{v=r.f
v===$&&A.e()
x=x.ga4r()
u=r.x.gvZ()
t=r.x.ga21()
s=r.x.gD0()
v.ch=x
v.CW=u
v.cx=t
v.cy=s}if(!r.z){r.z=!0
r.dGs()
r.ZV()}},
Y(){var x,w,v,u=this
u.a6()
x=$.al()
w=x.$1$0(y.E)
v=y.r
x=A.j8(w,x.ah(v)?x.$1$0(v):null)
x.a4(u.gc8q())
u.r!==$&&A.aK()
u.r=x
u.e.m(C.i,"ChatSessionListPage initialized",null,null)
u.d.a4(u.gdqm())},
d_5(){var x,w,v=this
if(v.c!=null){x=v.r
x===$&&A.e()
x=x.gN()}else x=!0
if(x)return
v.n(new B.cEu())
w=v.w
$.am.y2$.push(new B.cEv(w))},
dGs(){var x,w,v,u,t=this,s=null
try{w=t.e
w.m(C.i,"Testing GetIt registration...",s,s)
w.m(C.i,"ChatAuthService retrieved successfully from GetIt",s,s)}catch(v){x=A.u(v)
t.e.m(C.F,"Failed to get ChatAuthService from GetIt: "+A.b(x),s,s)
w=t.f
w===$&&A.e()
u=t.x
u===$&&A.e()
w.alO(u.a3q(J.at(x)))}},
ZV(){var x=0,w=A.l(y.H),v,u=2,t=[],s=this,r,q,p,o,n,m,l,k
var $async$ZV=A.h(function(d,e){if(d===1){t.push(e)
x=u}for(;;)switch(x){case 0:l=s.r
l===$&&A.e()
r=l.fw(new B.cEt(s))
if(!r.$0()){x=1
break}u=4
q=$.al().$1$0(y.C)
x=7
return A.c(q.V7(),$async$ZV)
case 7:p=e
if(!r.$0()){x=1
break}l=s.f
x=p!=null?8:10
break
case 8:l===$&&A.e()
l.bqd(p)
x=11
return A.c(l.R5(!0),$async$ZV)
case 11:x=9
break
case 10:l===$&&A.e()
n=s.x
n===$&&A.e()
l.alO(n.gaJB())
case 9:u=2
x=6
break
case 4:u=3
k=t.pop()
o=A.u(k)
if(!r.$0()){x=1
break}s.e.m(C.F,"Failed to initialize data: "+A.b(o),null,null)
l=s.f
l===$&&A.e()
n=s.x
n===$&&A.e()
l.alO(n.a3q(J.at(o)))
x=6
break
case 3:x=2
break
case 6:case 1:return A.j(v,w)
case 2:return A.i(t.at(-1),w)}})
return A.k($async$ZV,w)},
dqn(){var x,w=this,v=w.r
v===$&&A.e()
if(!v.gN()||w.d.f.length===0)return
v=w.d.f
x=C.d.gde(v).at
x.toString
v=C.d.gde(v).Q
v.toString
if(x>=v-200)w.buV()},
buV(){var x=0,w=A.l(y.H),v,u=this,t
var $async$buV=A.h(function(d,e){if(d===1)return A.i(e,w)
for(;;)switch(x){case 0:t=u.f
t===$&&A.e()
if(!t.at||t.x===D.Cp){x=1
break}x=3
return A.c(t.e1W(),$async$buV)
case 3:case 1:return A.j(v,w)}})
return A.k($async$buV,w)},
brV(){var x=0,w=A.l(y.H),v=this
var $async$brV=A.h(function(d,e){if(d===1)return A.i(e,w)
for(;;)switch(x){case 0:x=2
return A.c(v.ZV(),$async$brV)
case 2:return A.j(null,w)}})
return A.k($async$brV,w)},
q(){var x,w=this
w.d.q()
if(w.y){x=w.f
x===$&&A.e()
x.q()}x=w.r
x===$&&A.e()
x.T(w.gc8q())
x.q()
w.a5()},
u(d){var x,w=null,v=this.r
v===$&&A.e()
if(!v.gN())return C.ab
v=y.J
x=this.gc8p()
return A.bQ(A.e1(w,w,!0,d,C.MG,w,w,A.f(d,C.c,v).gb0J()),w,A.fR(this.d_4(),w,x),w,w,w,F.bBd(w,C.bk,!1,x,A.f(d,C.c,v).glg()),w)},
d_4(){var x=this.f
x===$&&A.e()
return new A.ml(new B.cEo(this),null,x,null)},
cXR(){var x=this.f
x===$&&A.e()
return new A.ml(new B.cEs(this),null,x,null)}}
B.b_1.prototype={
u(d){return D.bsu}}
B.b_0.prototype={
u(d){return A.xa(null,new B.cEw(),8,null,C.C,null,C.y,new B.cEx(),!1)}}
B.a4u.prototype={
u(d){return D.aZs}}
B.Py.prototype={
W(){return"ChatSessionListStatus."+this.b}}
B.a9z.prototype={
cQg(d,e,f,g,h,i){var x=this,w=x.b,v=d.bX2(w,new B.bqU(x))
x.a!==$&&A.aK()
x.a=v
w.a4(x.gc8r())},
d_7(){var x,w=this
if(w.c||w.b.gN())return;++w.d;++w.e
x=w.f
x.c=!0
x.b=null
x=w.ay
if(x!=null)x.a9()
w.ax=w.ay=null
w.z.a2(0)
w.cjN()
w.x=D.O2
w.P()},
bqd(d){var x=this
if(!(!x.c&&x.b.gN()))return
x.ax=d
x.dFU()
x.P()},
dFU(){var x=this,w=++x.e,v=x.b,u=v.a,t=u.geK()?x.r.go:null,s=x.ay
if(s!=null)s.a9()
if(!(!x.c&&v.gN())||x.ax==null)return
v=u.geK()?"WEB_SESSION_CHAT_INVALIDATED":"NEW_MESSAGE"
x.r.m5(v).b4(new B.bqS(x,w,t),y.a).iN(new B.bqT(x,w))},
bwp(){var x=0,w=A.l(y.H),v,u=2,t=[],s=this,r,q,p,o,n,m,l,k,j,i,h,g,f,e
var $async$bwp=A.h(function(d,a0){if(d===1){t.push(a0)
x=u}for(;;)switch(x){case 0:if(!(!s.c&&s.b.gN())||s.ax==null){x=1
break}r=s.b.fw(new B.bqK(s,++s.d))
i=s.as
q=i>0?i:1
p=A.a([],y.Z)
o=!0
n=0
u=4
m=0
case 7:if(!(m<q&&o)){x=8
break}h=s.a
h===$&&A.e()
g=s.ax
g.toString
x=9
return A.c(h.Jf(g,m,20),$async$bwp)
case 9:l=a0
if(!r.$0()){x=1
break}h=p
k=new A.E(h,new B.bqL(),A.W(h).k("E<1,n>")).eJ(0)
J.fv(p,J.hs(l,new B.bqM(k)))
o=J.aC(l)>=20
n=m+1;++m
x=7
break
case 8:if(!r.$0()){x=1
break}if(!J.a7O(p,new B.bqN())){h=s.ax
h.toString
J.ewA(p,0,s.c9F(h))}s.y=p
s.at=o
s.as=n
s.Q=null
s.x=D.Co
s.P()
u=2
x=6
break
case 4:u=3
e=t.pop()
j=A.u(e)
if(!r.$0()){x=1
break}s.Q=J.at(j)
s.x=D.Co
s.P()
x=6
break
case 3:x=2
break
case 6:case 1:return A.j(v,w)
case 2:return A.i(t.at(-1),w)}})
return A.k($async$bwp,w)},
d_6(d){var x,w,v,u,t=this,s=null
try{x=A.bqB(y.P.a(d))
if(x==null)return
w=J.ewz(t.y,new B.bqJ(x))
if(!J.p(w,-1)){t.w.m(C.aN,"New message received for session "+x.d+", refreshing chat list",s,s)
t.R5(!0)}}catch(u){v=A.u(u)
t.w.m(C.t,"Failed to process new message: "+A.b(v),s,s)}},
alO(d){var x=this
if(!(!x.c&&x.b.gN()))return
x.Q=d
x.x=D.atp
x.P()},
R5(d){return this.e1X(d)},
e1W(){return this.R5(!1)},
e1X(d){var x=0,w=A.l(y.H),v,u=2,t=[],s=this,r,q,p,o,n,m,l,k,j,i,h,g
var $async$R5=A.h(function(e,f){if(e===1){t.push(f)
x=u}for(;;)switch(x){case 0:if(!(!s.c&&s.b.gN())){x=1
break}if(s.ax==null){s.alO(s.ch)
x=1
break}if(d)s.cjN()
else{j=s.x
if(j===D.wg||j===D.Cp){s.w.m(C.i,"Already loading, skipping duplicate request",null,null)
x=1
break}else if(!s.at){s.w.m(C.i,"No more data to load",null,null)
x=1
break}}s.x=d?D.wg:D.Cp
s.P()
r=s.b.fw(new B.bqV(s,++s.d))
u=4
j=s.a
j===$&&A.e()
i=s.ax
i.toString
x=7
return A.c(j.Jf(i,s.as,20),$async$R5)
case 7:q=f
if(!r.$0()){x=1
break}j=s.w
j.m(C.i,"Retrieved "+J.aC(q)+" sessions",null,null)
s.at=J.aC(q)>=20
p=J.a7O(q,new B.bqW())
if(!p&&!J.a7O(s.y,new B.bqX())&&s.ax!=null){l=s.ax
l.toString
o=s.c9F(l)
if(d){n=A.a([o],y.Z)
J.fv(n,q)
s.y=n}else{n=A.Q(s.y,y.K)
m=n
J.c3(m,o)
J.fv(m,q)
s.y=m}j.m(C.i,"\ud83e\udd16 \u5df2\u6dfb\u52a0AI\u52a9\u624b\u6703\u8a71\u81f3\u5217\u8868\u9802\u90e8: "+o.a,null,null)}else if(d)s.y=q
else{n=A.Q(s.y,y.K)
l=n
J.fv(l,q)
s.y=l}++s.as
s.Q=null
s.x=D.Co
s.P()
u=2
x=6
break
case 4:u=3
g=t.pop()
k=A.u(g)
if(!r.$0()){x=1
break}s.w.m(C.F,"Failed to load sessions: "+A.b(k),null,null)
s.alO(J.at(k))
x=6
break
case 3:x=2
break
case 6:case 1:return A.j(v,w)
case 2:return A.i(t.at(-1),w)}})
return A.k($async$R5,w)},
c9F(d){var x=null,w=this.CW,v=this.cx,u=Date.now()
return A.e_k(new A.aG(Date.now(),0,!1),x,"0_"+d,v,x,new A.aG(u,0,!1),x,x,0,w,x,x,0,!1,new A.aG(Date.now(),0,!1),d,x,x,0)},
cjN(){var x=this
x.y=A.a([],y.Z)
x.as=0
x.at=!0
x.Q=null},
q(){var x,w=this
w.c=!0
x=w.f
x.c=!0
x.b=null;++w.e
w.b.T(w.gc8r())
x=w.ay
if(x!=null)x.a9()
w.dY()}}
B.a9y.prototype={
R(){var x=$.ta
if(x==null)x=$.ta=A.YL()
return new B.an3(x,A.aU(y.n),A.b7("ChatSessionItem"))}}
B.an3.prototype={
Y(){var x,w,v=this
v.a6()
x=v.a.d.mg($.al().$1$0(y.x).a,new B.cEn(v))
v.e!==$&&A.aK()
v.e=new A.qv(x)
v.a.d.a4(v.gc8o())
x=v.a.c
w=v.x=x.d
if(w>0)v.d.c3p(x.a,w)
v.dFX()},
q(){var x,w=this
w.a.d.T(w.gc8o())
w.c95()
x=w.w
if(x!=null)x.a9()
w.a5()},
d_3(){var x,w=this
if(w.a.d.gN())return
x=w.w
if(x!=null)x.a9()
w.c95()
if(w.c!=null)w.n(new B.cE8(w))},
bRb(d){var x=A.cs(d,null,y.X)
if(x!=null)this.f.H(0,x)},
c95(){var x=this.f,w=A.Q(x,A.D(x).c)
x.a2(0)
$.am.y2$.push(new B.cE5(w))},
Aa(d){var x=!1
if(this.c!=null&&this.a.d.gN())if(d.e!=null){x=A.cs(d,null,y.X)
x=(x==null?null:x.gN())===!0}return x},
dFX(){var x,w=this
w.r.m(C.i,"\ud83d\udd14 [CHAT_SESSION] Subscribing to state changes for session "+w.a.c.a+", initial count: "+w.x,null,null)
x=w.d.r
w.w=new A.eY(x,A.D(x).k("eY<1>")).h3(new B.cEk(w))},
d93(d){var x,w,v,u,t,s,r,q,p=this.a.c.z,o=p==null?"":p
if(J.aC(o)===0)return A.f(d,C.c,y.J).gz4()
t=this.dkc()
s=A.f(d,C.c,y.J)
s.toString
x=s
w=t?x.gHs()+": ":""
if(J.GW(o,"http"))s=J.dY(o,".jpg")||J.dY(o,".jpeg")||J.dY(o,".png")||J.dY(o,".gif")||J.dY(o,".webp")
else s=!1
if(s)return A.b(w)+"\ud83d\uddbc\ufe0f "+x.gft()
try{v=C.H.D(o)
if(y.P.b(v)&&v.ao("fileType")){u=A.b6(v.i(0,"fileName"))
s=A.b(w)
r=u
r=A.b(r==null?x.gPZ():r)
return s+"\ud83d\udcce "+r}}catch(q){}if(J.aC(o)>50)return A.b(w)+J.dZN(o,0,50)+"..."
return A.b(w)+A.b(o)},
dkc(){var x=this.a.c,w=x.f,v=x.Q,u=x.as
if(w==null)return!1
if(v!=null)return w>v
if(u!=null)return w===u
return!1},
cfc(d){var x
if(d.length===0)return!1
if(!C.b.aQ(d,"http://")&&!C.b.aQ(d,"https://"))return!1
x=y.s
if(!C.d.c9(A.a([".jpg",".jpeg",".png",".gif",".webp",".svg"],x),new B.cE6(d)))return C.d.c9(A.a(["objectstorage","cloudinary","imgur","flickr","amazonaws","googleusercontent","gravatar","githubusercontent"],x),new B.cE7(d))
return!0},
u(d){var x,w,v,u,t,s,r,q,p,o,n,m,l,k=this,j=null
if(!(k.c!=null&&k.a.d.gN()))return C.ab
x=A.t(d).ax
w=x.a===C.K
v=k.d93(d)
u=k.a
t=u.c
s=t.r
if(s==null)s=t.ch
r=t.c===0
q=r?A.f(d,C.c,y.J).gvZ():u.e
if(!r){u=k.a.c.y
u=u!=null&&k.cfc(u)}else u=!1
if(u){u=k.a.c.y
u.toString
u=new A.lm(u,1,j,C.eA)}else u=j
if(r)t=x.y
else{t=k.a.c.y
t=t==null||!k.cfc(t)?x.b:j}if(r)p=A.S(P.xM,x.z,j,j,j)
else if(k.a.c.y==null){p=q.length!==0?q[0].toUpperCase():"?"
p=A.d(p,j,j,j,j,j,A.I(j,j,x.c,j,j,j,j,j,j,j,j,j,j,j,C.B,j,j,!0,j,j,j,j,j,j,j,j),j,j,j)}else p=j
p=A.iq(t,u,p,j,j)
u=A.d(q,j,j,j,j,j,A.I(j,j,x.k3,j,j,j,j,j,j,j,j,j,j,j,C.a6,j,j,!0,j,j,j,j,j,j,j,j),j,j,j)
t=k.x>0
if(t)o=x.b
else o=w?C.ei:C.cz
o=A.d(v,j,1,C.S,j,j,A.I(j,j,o,j,j,j,j,j,j,j,j,j,j,j,t?C.a6:C.aH,j,j,!0,j,j,j,j,j,j,j,j),j,j,j)
n=k.d8f(s,d)
t=y.p
n=A.a([A.d(n,j,j,j,j,j,A.I(j,j,w?C.ei:C.cz,j,j,j,j,j,j,j,j,12,j,j,j,j,j,!0,j,j,j,j,j,j,j,j),j,j,j)],t)
m=k.x
if(m>0){l=A.G(10)
C.d.v(n,A.a([C.Q,A.X(j,A.d(C.h.l(m),j,j,j,j,j,A.I(j,j,x.go,j,j,j,j,j,j,j,j,12,j,j,C.B,j,j,!0,j,j,j,j,j,j,j,j),j,j,j),C.o,j,j,new A.T(x.fy,j,j,l,j,j,C.r),j,j,j,j,C.fB,j,j,j)],t))}return A.dm(!1,j,j,j,!0,j,j,j,!0,j,j,p,j,j,j,j,new B.cEl(k,d),new B.cEm(k,d),!1,j,j,j,j,o,j,u,j,j,A.w(n,C.eH,j,C.b9,C.f,0,C.j),j)},
d8f(d,e){var x=L.wN(d),w=new A.aG(Date.now(),0,!1).ds(x).a,v=C.h.bX(w,864e8)
if(v>7){w=y.J
return""+A.bO(x)+A.f(e,C.c,w).gaJy()+A.cv(x)+A.f(e,C.c,w).gaJs()}else if(v>0)return""+v+A.f(e,C.c,y.J).gaJt()
else{v=C.h.bX(w,36e8)
if(v>0)return""+v+A.f(e,C.c,y.J).gaJu()
else{w=C.h.bX(w,6e7)
v=y.J
if(w>0)return""+w+A.f(e,C.c,v).gaJx()
else return A.f(e,C.c,v).gaJw()}}},
dDq(d){if(!this.Aa(d))return
A.Os(null,new B.cEi(this),null,d,!1,null,!1,y.z)},
byy(){var x=0,w=A.l(y.H),v,u=2,t=[],s=this,r,q,p,o,n
var $async$byy=A.h(function(d,e){if(d===1){t.push(e)
x=u}for(;;)switch(x){case 0:if(!(s.c!=null&&s.a.d.gN())){x=1
break}u=4
p=s.e
p===$&&A.e()
x=7
return A.c(p.TC(s.a.c.a),$async$byy)
case 7:r=e
if(!(s.c!=null&&s.a.d.gN())){x=1
break}if(r!=null){s.a.r.$0()
if(s.c!=null)p=s.a.d.gN()
else p=!1
if(p){p=s.c
p.toString
A.a7(p,r.w?"Chat pinned":"Chat unpinned",C.a_,null)}}u=2
x=6
break
case 4:u=3
n=t.pop()
q=A.u(n)
s.r.m(C.F,"Failed to toggle session pin: "+A.b(q),null,null)
if(s.c!=null)p=s.a.d.gN()
else p=!1
if(p){p=s.c
p.toString
E.cq(p,q,"Failed to update pinned chat")}x=6
break
case 3:x=2
break
case 6:case 1:return A.j(v,w)
case 2:return A.i(t.at(-1),w)}})
return A.k($async$byy,w)},
dCA(){var x,w=this,v=null
if(!(w.c!=null&&w.a.d.gN()))return
x=w.c
x.toString
A.be(v,v,!0,v,new B.cEb(w),x,v,!0,!0,y.z)},
bs3(){var x=0,w=A.l(y.H),v,u=2,t=[],s=this,r,q,p,o
var $async$bs3=A.h(function(d,e){if(d===1){t.push(e)
x=u}for(;;)switch(x){case 0:if(!(s.c!=null&&s.a.d.gN())){x=1
break}u=4
q=s.e
q===$&&A.e()
x=7
return A.c(q.aKT(s.a.c.a),$async$bs3)
case 7:if(!(s.c!=null&&s.a.d.gN())){x=1
break}s.a.r.$0()
if(s.c!=null)q=s.a.d.gN()
else q=!1
if(q){q=s.c
q.toString
A.a7(q,"Messages cleared",C.a_,null)}u=2
x=6
break
case 4:u=3
o=t.pop()
r=A.u(o)
s.r.m(C.F,"Failed to clear session: "+A.b(r),null,null)
if(s.c!=null)q=s.a.d.gN()
else q=!1
if(q){q=s.c
q.toString
E.cq(q,r,"Failed to clear messages")}x=6
break
case 3:x=2
break
case 6:case 1:return A.j(v,w)
case 2:return A.i(t.at(-1),w)}})
return A.k($async$bs3,w)},
dCF(){var x,w=this,v=null
if(!(w.c!=null&&w.a.d.gN()))return
x=w.c
x.toString
A.be(v,v,!0,v,new B.cEe(w),x,v,!0,!0,y.z)},
bsJ(){var x=0,w=A.l(y.H),v,u=2,t=[],s=this,r,q,p,o
var $async$bsJ=A.h(function(d,e){if(d===1){t.push(e)
x=u}for(;;)switch(x){case 0:if(!(s.c!=null&&s.a.d.gN())){x=1
break}u=4
q=s.e
q===$&&A.e()
x=7
return A.c(q.aO1(s.a.c.a),$async$bsJ)
case 7:if(!(s.c!=null&&s.a.d.gN())){x=1
break}s.a.r.$0()
if(s.c!=null)q=s.a.d.gN()
else q=!1
if(q){q=s.c
q.toString
A.a7(q,"Chat deleted",C.a_,null)}u=2
x=6
break
case 4:u=3
o=t.pop()
r=A.u(o)
s.r.m(C.F,"Failed to delete session: "+A.b(r),null,null)
if(s.c!=null)q=s.a.d.gN()
else q=!1
if(q){q=s.c
q.toString
E.cq(q,r,"Failed to delete chat")}x=6
break
case 3:x=2
break
case 6:case 1:return A.j(v,w)
case 2:return A.i(t.at(-1),w)}})
return A.k($async$bsJ,w)}}
var z=a.updateTypes(["~()","B<~>()","a4u(M,y)"])
B.cEu.prototype={
$0(){},
$S:0}
B.cEv.prototype={
$1(d){var x=this.a,w=x==null?null:x.b
if(w!=null&&w.c!=null&&x.gfd()&&!x.gle())w.ho(x)},
$S:2}
B.cEt.prototype={
$0(){return this.a.c!=null},
$S:1}
B.cEo.prototype={
$2(d,e){var x=null,w=this.a,v=w.f
v===$&&A.e()
if(v.x===D.wg)return D.cb_
if(v.Q!=null&&J.ev(v.y)){v=v.Q
v.toString
return I.eb_(v,w.gc8p())}if(v.x!==D.wg&&J.ev(v.y)){w=y.J
v=A.f(d,C.c,w).gb1_()
return N.aFI(x,C.lx,A.f(d,C.c,w).ganF(),x,x,x,v)}return w.cXR()},
$S:49}
B.cEs.prototype={
$2(d,e){var x,w,v=this.a,u=v.f
u===$&&A.e()
x=J.aC(u.y)
w=u.at?1:0
return A.xa(v.d,new B.cEq(v,u),x+w,null,C.C,null,C.y,new B.cEr(),!1)},
$S:1699}
B.cEr.prototype={
$2(d,e){return C.c1},
$S:150}
B.cEq.prototype={
$2(d,e){var x,w,v,u=this.b
if(e===J.aC(u.y)&&u.at)return D.cb0
x=J.ax(u.y,e)
w=x.x
if(w==null)w=u.cy
u=this.a
v=u.r
v===$&&A.e()
return new B.a9y(x,v,w,new B.cEp(u),new A.K(x.a,y.O))},
$S:68}
B.cEp.prototype={
$0(){var x=this.a.f
x===$&&A.e()
return x.R5(!0)},
$S:0}
B.cEx.prototype={
$2(d,e){return C.c1},
$S:150}
B.cEw.prototype={
$2(d,e){return D.agU},
$S:z+2}
B.bqU.prototype={
$0(){var x=this.a
return!x.c&&x.b.gN()},
$S:1}
B.bqS.prototype={
$1(d){var x,w,v=this,u=v.a
if(!(!u.c&&u.b.gN())||v.b!==u.e)return
x=v.b
u.ay=d.ir(new B.bqP(u,x),new B.bqQ(u,x))
w=v.c
if(w!=null&&w!==u.r.go)u.f.bEJ(u.gcj9(),new B.bqR(u,x))},
$S:61}
B.bqP.prototype={
$1(d){var x,w,v=null,u=this.a
if(!(!u.c&&u.b.gN())||this.b!==u.e)return
if(u.b.a.geK()){u.f.bEJ(u.gcj9(),new B.bqO(u,this.b))
return}try{u.w.m(C.aN,"Received new message in chat list: "+d.l(0),v,v)
u.d_6(d)}catch(w){x=A.u(w)
u.w.m(C.t,"Failed to handle new message in chat list: "+A.b(x),v,v)}},
$S:30}
B.bqO.prototype={
$0(){var x=this.a
return!x.c&&x.b.gN()&&this.b===x.e},
$S:1}
B.bqQ.prototype={
$1(d){var x=this.a
if(!(!x.c&&x.b.gN())||this.b!==x.e)return
x.w.m(C.t,"Message subscription error in chat list: "+A.b(d),null,null)},
$S:21}
B.bqR.prototype={
$0(){var x=this.a
return!x.c&&x.b.gN()&&this.b===x.e},
$S:1}
B.bqT.prototype={
$1(d){var x=this.a
if(!(!x.c&&x.b.gN())||this.b!==x.e)return
x.w.m(C.t,"Message subscription unavailable: "+A.b(d),null,null)},
$S:40}
B.bqK.prototype={
$0(){var x=this.a
return!x.c&&x.b.gN()&&this.b===x.d},
$S:1}
B.bqL.prototype={
$1(d){return d.a},
$S:1701}
B.bqM.prototype={
$1(d){return this.a.H(0,d.a)},
$S:168}
B.bqN.prototype={
$1(d){return d.c===0},
$S:168}
B.bqJ.prototype={
$1(d){return d.a===this.a.d},
$S:168}
B.bqV.prototype={
$0(){var x=this.a
return!x.c&&x.b.gN()&&this.b===x.d},
$S:1}
B.bqW.prototype={
$1(d){return d.c===0},
$S:168}
B.bqX.prototype={
$1(d){return d.c===0},
$S:168}
B.cEn.prototype={
$0(){var x=this.a
return x.c!=null&&x.a.d.gN()},
$S:1}
B.cE8.prototype={
$0(){return this.a.x=0},
$S:0}
B.cE5.prototype={
$1(d){var x,w,v,u,t
for(x=this.a,w=x.length,v=0;v<x.length;x.length===w||(0,A.a6)(x),++v){u=x[v]
t=u.b
if(t!=null&&t.c!=null&&u.gfd()&&!u.gle())t.ho(u)}},
$S:2}
B.cEk.prototype={
$1(d){var x,w,v,u="event",t=null,s=this.a,r=s.r
r.m(C.i,"\ud83d\udd14 [CHAT_SESSION] Received state event: "+A.b(d.i(0,u))+", data: "+d.l(0),t,t)
if(s.c!=null&&s.a.d.gN()&&J.p(d.i(0,u),"sessionUnreadCountChanged")){x=A.b6(d.i(0,"sessionId"))
w=A.b(x)
r.m(C.i,"\ud83d\udd14 [CHAT_SESSION] Checking sessionId: "+w+" vs "+s.a.c.a,t,t)
if(x===s.a.c.a){v=A.eE(d.i(0,"unreadCount"))
if(v==null)v=0
r.m(C.i,"\ud83d\udd14 [CHAT_SESSION] Updating unread count for session "+s.a.c.a+": "+s.x+" -> "+v,t,t)
s.n(new B.cEj(s,v))
r.m(C.i,"\ud83d\udd14 [CHAT_SESSION] Updated unread count for session "+s.a.c.a+": "+s.x,t,t)}else r.m(C.i,"\ud83d\udd14 [CHAT_SESSION] Ignoring event for different session: "+w,t,t)}else r.m(C.i,"\ud83d\udd14 [CHAT_SESSION] Ignoring event: "+A.b(d.i(0,u)),t,t)},
$S:30}
B.cEj.prototype={
$0(){this.a.x=this.b},
$S:0}
B.cE6.prototype={
$1(d){return C.b.t(this.a.toLowerCase(),d)},
$S:9}
B.cE7.prototype={
$1(d){return C.b.t(this.a.toLowerCase(),d)},
$S:9}
B.cEm.prototype={
$0(){var x,w=this.a,v=this.b
if(!w.Aa(v))return
w.a.toString
v=A.aN(v,!1).f
w=w.a.c.a
x=A.a_(["sessionId",w],y.N,y.z)
v.aL(new B.aBp("ChatRoute",new A.Cw(w,null),x,C.af,null,""),y.X)},
$S:0}
B.cEl.prototype={
$0(){return this.a.dDq(this.b)},
$S:0}
B.cEi.prototype={
$1(d){var x,w,v,u,t,s,r=null,q=this.a
q.bRb(d)
x=A.t(d).ax
w=q.a.c.w
v=w?H.S_:D.aSW
if(w){u=x.CW
if(u==null)u=x.y}else u=r
u=A.S(v,u,r,r,r)
v=A.dm(!1,r,r,r,!0,r,r,r,!0,r,r,u,r,r,r,r,r,new B.cEf(q,d),!1,r,r,r,r,r,r,A.d(w?"Unpin Chat":"Pin Chat",r,r,r,r,r,r,r,r,r),r,r,r,r)
u=x.CW
w=u==null
t=A.S(D.aRf,w?x.y:u,r,r,r)
s=x.fy
return new A.dC(!0,!0,!0,!0,C.J,!1,A.w(A.a([v,A.dm(!1,r,r,r,!0,r,r,r,!0,r,r,t,r,r,r,r,r,new B.cEg(q,d),!1,r,r,r,r,r,r,A.d("Clear Messages",r,r,r,r,r,A.I(r,r,w?x.y:u,r,r,r,r,r,r,r,r,r,r,r,r,r,r,!0,r,r,r,r,r,r,r,r),r,r,r),r,r,r,r),A.dm(!1,r,r,r,!0,r,r,r,!0,r,r,A.S(K.jm,s,r,r,r),r,r,r,r,r,new B.cEh(q,d),!1,r,r,r,r,r,r,A.d("Delete Chat",r,r,r,r,r,A.I(r,r,s,r,r,r,r,r,r,r,r,r,r,r,r,r,r,!0,r,r,r,r,r,r,r,r),r,r,r),r,r,r,r)],y.p),C.l,r,C.e,C.I,0,C.j),r)},
$S:550}
B.cEf.prototype={
$0(){var x=this.a,w=this.b
if(!x.Aa(w))return
A.ac(w,!1).af(null)
x.byy()},
$S:0}
B.cEg.prototype={
$0(){var x=this.a,w=this.b
if(!x.Aa(w))return
A.ac(w,!1).af(null)
x.dCA()},
$S:0}
B.cEh.prototype={
$0(){var x=this.a,w=this.b
if(!x.Aa(w))return
A.ac(w,!1).af(null)
x.dCF()},
$S:0}
B.cEb.prototype={
$1(d){var x,w,v,u,t,s,r=null,q=this.a
q.bRb(d)
x=y.J
w=A.d(A.f(d,C.c,x).gaKR(),r,r,r,r,r,r,r,r,r)
v=A.f(d,C.c,x).ghN()
v=A.R(r,!0,r,A.aH(A.d(A.f(d,C.c,x).ghN(),r,r,r,r,r,r,r,r,r),r,r,r,new B.cE9(q,d),r,r),!1,r,r,r,!1,r,!1,r,r,r,r,r,r,r,r,r,r,r,v,r,r,r,r,r,r,r,r,r,r,r,r,r,r,r,r,r,r,r,r,r,r,r,r,r,r,r,r,r,r,C.p,r)
u=A.f(d,C.c,x)
u=u.gl3(u)
t=A.t(d).ax
s=t.CW
t=A.f3(r,r,r,r,r,r,r,r,r,s==null?t.y:s,r,r,r,r,r,r,r,r,r,r,r)
x=A.f(d,C.c,x)
return A.bg(A.a([v,A.R(r,!0,r,A.aH(A.d(x.gl3(x),r,r,r,r,r,r,r,r,r),r,r,r,new B.cEa(q,d),r,t),!1,r,r,r,!1,r,!1,r,r,r,r,r,r,r,r,r,r,r,u,r,r,r,r,r,r,r,r,r,r,r,r,r,r,r,r,r,r,r,r,r,r,r,r,r,r,r,r,r,r,C.p,r)],y.p),r,r,D.bVp,r,r,!1,r,w)},
$S:6}
B.cE9.prototype={
$0(){var x=this.b
if(this.a.Aa(x))A.ac(x,!1).af(null)},
$S:0}
B.cEa.prototype={
$0(){var x=this.a,w=this.b
if(!x.Aa(w))return
A.ac(w,!1).af(null)
x.bs3()},
$S:0}
B.cEe.prototype={
$1(d){var x,w,v,u,t,s=null,r=this.a
r.bRb(d)
x=y.J
w=A.d(A.f(d,C.c,x).gaNV(),s,s,s,s,s,s,s,s,s)
v=A.f(d,C.c,x).ghN()
v=A.R(s,!0,s,A.aH(A.d(A.f(d,C.c,x).ghN(),s,s,s,s,s,s,s,s,s),s,s,s,new B.cEc(r,d),s,s),!1,s,s,s,!1,s,!1,s,s,s,s,s,s,s,s,s,s,s,v,s,s,s,s,s,s,s,s,s,s,s,s,s,s,s,s,s,s,s,s,s,s,s,s,s,s,s,s,s,s,C.p,s)
u=A.f(d,C.c,x).gqT()
t=A.f3(s,s,s,s,s,s,s,s,s,A.t(d).ax.fy,s,s,s,s,s,s,s,s,s,s,s)
return A.bg(A.a([v,A.R(s,!0,s,A.aH(A.d(A.f(d,C.c,x).gqT(),s,s,s,s,s,s,s,s,s),s,s,s,new B.cEd(r,d),s,t),!1,s,s,s,!1,s,!1,s,s,s,s,s,s,s,s,s,s,s,u,s,s,s,s,s,s,s,s,s,s,s,s,s,s,s,s,s,s,s,s,s,s,s,s,s,s,s,s,s,s,C.p,s)],y.p),s,s,D.bVt,s,s,!1,s,w)},
$S:6}
B.cEc.prototype={
$0(){var x=this.b
if(this.a.Aa(x))A.ac(x,!1).af(null)},
$S:0}
B.cEd.prototype={
$0(){var x=this.a,w=this.b
if(!x.Aa(w))return
A.ac(w,!1).af(null)
x.bsJ()},
$S:0};(function installTearOffs(){var x=a._instance_0u
var w
x(w=B.an4.prototype,"gc8q","d_5",0)
x(w,"gdqm","dqn",0)
x(w,"gc8p","brV",1)
x(w=B.a9z.prototype,"gc8r","d_7",0)
x(w,"gcj9","bwp",1)
x(w,"gdC","q",0)
x(B.an3.prototype,"gc8o","d_3",0)})();(function inheritance(){var x=a.inherit,w=a.inheritMany
x(B.aBp,A.bV)
w(A.L,[B.HZ,B.a9y])
w(A.U,[B.an4,B.an3])
w(A.bt,[B.cEu,B.cEt,B.cEp,B.bqU,B.bqO,B.bqR,B.bqK,B.bqV,B.cEn,B.cE8,B.cEj,B.cEm,B.cEl,B.cEf,B.cEg,B.cEh,B.cE9,B.cEa,B.cEc,B.cEd])
w(A.bu,[B.cEv,B.bqS,B.bqP,B.bqQ,B.bqT,B.bqL,B.bqM,B.bqN,B.bqJ,B.bqW,B.bqX,B.cE5,B.cEk,B.cE6,B.cE7,B.cEi,B.cEb,B.cEe])
w(A.ca,[B.cEo,B.cEs,B.cEr,B.cEq,B.cEx,B.cEw])
w(A.x,[B.b_1,B.b_0,B.a4u])
x(B.Py,A.eA)
x(B.a9z,A.hy)})()
A.b_(b.typeUniverse,JSON.parse('{"aBp":{"bV":["Cw"]},"a4u":{"x":[],"m":[]},"HZ":{"L":[],"m":[]},"an4":{"U":["HZ"]},"b_1":{"x":[],"m":[]},"b_0":{"x":[],"m":[]},"a9z":{"b2":[]},"a9y":{"L":[],"m":[]},"an3":{"U":["a9y"]}}'))
var y=(function rtii(){var x=A.C
return{J:x("by"),x:x("qv"),C:x("Pw"),K:x("kN"),U:x("Cx"),Z:x("v<kN>"),F:x("v<iE>"),s:x("v<n>"),p:x("v<m>"),P:x("a1<n,@>"),n:x("eN<@>"),a:x("b8"),d:x("lt"),N:x("n"),r:x("ft"),E:x("ec"),O:x("K<n>"),z:x("@"),S:x("y"),X:x("A?"),H:x("~")}})();(function constants(){var x=a.makeConstList
D.O2=new B.Py(0,"initial")
D.wg=new B.Py(1,"loading")
D.Co=new B.Py(2,"loaded")
D.atp=new B.Py(3,"error")
D.Cp=new B.Py(4,"loadingMore")
D.aRf=new A.a0(57705,"MaterialIcons",!1)
D.aSW=new A.a0(62167,"MaterialIcons",!1)
D.bsm=new A.J(Q.eK,G.AC,null)
D.bIY=new A.aX(44,12,6,null,null)
D.bIU=new A.aX(22,18,9,null,null)
D.b24=x([D.bIY,C.Q,D.bIU],y.p)
D.aBo=new A.cA(C.y,C.b9,C.f,C.eH,null,C.j,null,0,D.b24,null)
D.aZs=new A.oe(M.v0,O.adX,D.bsm,D.aBo,null,null,null,null,null,null,null,!0,null,null,null,!1,null,null,null,!1,null,null,null,null,null,null,null,null,!0,null)
D.agU=new B.a4u(null)
D.bsu=new A.J(C.cJ,D.agU,null)
D.bVp=new A.br("Are you sure you want to clear all messages in this chat? This action cannot be undone.",null,null,null,null,null,null,null,null,null,null)
D.bVt=new A.br("Are you sure you want to delete this chat? This will remove the chat and all its messages permanently. This action cannot be undone.",null,null,null,null,null,null,null,null,null,null)
D.cb_=new B.b_0(null)
D.cb0=new B.b_1(null)})()};
(a=>{a["pD9CpBzzu4r2tFN7w+17MvYFBWE="]=a.current})($__dart_deferred_initializers__);