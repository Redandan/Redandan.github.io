((a,b)=>{a[b]=a[b]||{}})(self,"$__dart_deferred_initializers__")
$__dart_deferred_initializers__.current=function(a,b,c,$){var A,B,C
A=c[0]
B=c[703]
C=c[363]
var z=a.updateTypes([]);(function constants(){C.AB=new A.aX(1/0,14,6,B.DC,null)})()};
(a=>{a["R8fbJryw75+t9hlIPJIEE/iSsss="]=a.current})($__dart_deferred_initializers__);