((a,b)=>{a[b]=a[b]||{}})(self,"$__dart_deferred_initializers__")
$__dart_deferred_initializers__.current=function(a,b,c,$){var A,C,B={aaY:function aaY(d,e){this.a=d
this.b=e}}
A=c[0]
C=c[2]
B=a.updateHolder(c[142],B)
B.aaY.prototype={
p(d,e){var x
if(e==null)return!1
if(this!==e)x=e instanceof B.aaY&&e.a===this.a&&e.b===this.b
else x=!0
return x},
gj(d){var x=C.h.gj(this.a),w=C.h.gj(this.b)
return x+w},
l(d){return"DeliveryHistoryParam[page="+this.a+", size="+this.b+"]"},
A(){var x=A.q(y.g,y.b)
x.h(0,"page",this.a)
x.h(0,"size",this.b)
return x}}
var z=a.updateTypes([]);(function inheritance(){var x=a.inherit
x(B.aaY,A.A)})()
var y={g:A.C("n"),b:A.C("@")}};
(a=>{a["uHqflnuvH2soV/PxDPfqhBiK1oc="]=a.current})($__dart_deferred_initializers__);