((a,b)=>{a[b]=a[b]||{}})(self,"$__dart_deferred_initializers__")
$__dart_deferred_initializers__.current=function(a,b,c,$){var A,C,B={bbr:function bbr(d,e){this.a=d
this.b=e},ajd:function ajd(d,e,f,g,h,i,j,k,l){var _=this
_.c=d
_.d=e
_.go=f
_.id=g
_.k3=h
_.k4=i
_.p1=j
_.xr=k
_.a=l},cbz:function cbz(d){this.a=d}},E,D,F
A=c[0]
C=c[2]
B=a.updateHolder(c[214],B)
E=c[771]
D=c[253]
F=c[804]
B.bbr.prototype={
W(){return"_SwitchListTileType."+this.b}}
B.ajd.prototype={
u(d){var x,w,v,u,t,s,r,q,p=this,o=null
switch(p.p1.a){case 1:x=new A.IJ(!0,new D.ajc(p.c,p.d,o,o,o,o,o,o,o,o,o,o,o,o,o,C.cD,F.ahW,p.xr,C.w,o,o,o,o,!1,o),o)
break
case 0:x=new A.IJ(!0,D.a2Z(o,o,o,o,!1,C.w,o,o,o,C.cD,o,o,p.d,o,o,o,o,o,o,o,o,p.c),o)
break
default:x=o}A.adv(d)
A:{w=new A.bc(o,x)
break A}v=w.a
u=w.b
t=A.t(d)
s=D.e2f(d)
w=s.a
w=w==null?o:w.al(A.aT(y.c))
r=w
if(r==null)r=t.ax.y
w=p.d!=null
q=w?new B.cbz(p):o
return new A.r0(A.dm(!1,p.k4,p.k3,o,w,o,o,o,!1,o,o,v,o,o,o,o,o,q,!1,r,o,o,o,p.id,o,p.go,o,o,u,o),o)}}
var z=a.updateTypes([])
B.cbz.prototype={
$0(){var x=this.a
x.d.$1(!x.c)},
$S:0};(function inheritance(){var x=a.inherit
x(B.bbr,A.eA)
x(B.ajd,A.x)
x(B.cbz,A.bt)})()
A.b_(b.typeUniverse,JSON.parse('{"ajd":{"x":[],"m":[]}}'))
var y={c:A.C("eF")};(function constants(){E.cfq=new B.bbr(0,"material")
E.cfr=new B.bbr(1,"adaptive")})()};
(a=>{a["AUmbjwccME1EV+nCfxiQhIq+9L4="]=a.current})($__dart_deferred_initializers__);