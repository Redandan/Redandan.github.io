((a,b)=>{a[b]=a[b]||{}})(self,"$__dart_deferred_initializers__")
$__dart_deferred_initializers__.current=function(a,b,c,$){var A,B,C
A=c[0]
B=c[2]
C=c[557]
var z=a.updateTypes([]);(function constants(){C.TU=new A.at(B.bb,20,null,null,null)})()};
(a=>{a["JpBtrQdqWAgIwchwtpV8gGAsD4c="]=a.current})($__dart_deferred_initializers__);