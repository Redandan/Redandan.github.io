((a,b)=>{a[b]=a[b]||{}})(self,"$__dart_deferred_initializers__")
$__dart_deferred_initializers__.current=function(a,b,c,$){var J,B,A,C={
ege(d,e,f,g,h,i,j,k,l,m,n,o){return new C.aQs(j,n,o,d,m,l,k,i,h,g,e,f)},
aQs:function aQs(d,e,f,g,h,i,j,k,l,m,n,o){var _=this
_.a=d
_.b=e
_.c=f
_.d=g
_.w=h
_.x=i
_.y=j
_.z=k
_.Q=l
_.as=m
_.at=n
_.ax=o}}
J=c[1]
B=c[0]
A=c[2]
C=a.updateHolder(c[170],C)
C.aQs.prototype={
p(d,e){var x,w=this
if(e==null)return!1
if(w!==e){x=!1
if(e instanceof C.aQs)if(e.a===w.a)if(e.b===w.b)if(J.p(e.c,w.c))if(J.p(e.d,w.d))if(e.w==w.w)if(e.x==w.x)if(e.y==w.y)if(e.z==w.z)if(e.Q==w.Q)if(e.as==w.as)x=e.ax==w.ax}else x=!0
return x},
gj(d){var x,w,v,u,t,s,r,q,p=this,o=A.h.gj(p.a),n=A.h.gj(p.b),m=p.c
m=m==null?0:B.Y(m.a,m.b,A.a,A.a,A.a,A.a,A.a,A.a,A.a,A.a,A.a,A.a,A.a,A.a,A.a,A.a,A.a,A.a,A.a,A.a)
x=p.d
x=x==null?0:B.Y(x.a,x.b,A.a,A.a,A.a,A.a,A.a,A.a,A.a,A.a,A.a,A.a,A.a,A.a,A.a,A.a,A.a,A.a,A.a,A.a)
w=p.w
w=w==null?0:A.h.gj(w)
v=p.x
v=v==null?0:A.h.gj(v)
u=p.y
u=u==null?0:A.h.gj(u)
t=p.z
t=t==null?0:A.b.gj(t)
s=p.Q
s=s==null?0:A.h.gj(s)
r=p.as
r=r==null?0:A.h.gj(r)
q=p.ax
if(q==null)q=0
else q=q?519018:218159
return o+n+m+x+w+v+u+t+s+r+q},
l(d){var x=this
return"ReviewSearchParam[page="+x.a+", size="+x.b+", startDate="+B.b(x.c)+", endDate="+B.b(x.d)+", keyword=null, sortBy=null, sortDirection=null, reviewerId="+B.b(x.w)+", reviewedUserId="+B.b(x.x)+", productId="+B.b(x.y)+", orderId="+B.b(x.z)+", minRating="+B.b(x.Q)+", maxRating="+B.b(x.as)+", isAnonymous="+B.b(x.at)+", isReplied="+B.b(x.ax)+"]"},
A(){var x,w=this,v=null,u="startDate",t="reviewerId",s="reviewedUserId",r="productId",q="minRating",p="maxRating",o="isReplied",n=B.q(y.g,y.b)
n.h(0,"page",w.a)
n.h(0,"size",w.b)
x=w.c
if(x!=null)n.h(0,u,x.a3().a_())
else n.h(0,u,v)
x=w.d
if(x!=null)n.h(0,"endDate",x.a3().a_())
else n.h(0,"endDate",v)
n.h(0,"keyword",v)
n.h(0,"sortBy",v)
n.h(0,"sortDirection",v)
x=w.w
if(x!=null)n.h(0,t,x)
else n.h(0,t,v)
x=w.x
if(x!=null)n.h(0,s,x)
else n.h(0,s,v)
x=w.y
if(x!=null)n.h(0,r,x)
else n.h(0,r,v)
x=w.z
if(x!=null)n.h(0,"orderId",x)
else n.h(0,"orderId",v)
x=w.Q
if(x!=null)n.h(0,q,x)
else n.h(0,q,v)
x=w.as
if(x!=null)n.h(0,p,x)
else n.h(0,p,v)
n.h(0,"isAnonymous",v)
x=w.ax
if(x!=null)n.h(0,o,x)
else n.h(0,o,v)
return n}}
var z=a.updateTypes([]);(function inheritance(){var x=a.inherit
x(C.aQs,B.A)})()
var y={g:B.C("n"),b:B.C("@")}};
(a=>{a["j//EeCpHEb7dQ/zW4p67qVl/Jng="]=a.current})($__dart_deferred_initializers__);