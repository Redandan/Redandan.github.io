((a,b)=>{a[b]=a[b]||{}})(self,"$__dart_deferred_initializers__")
$__dart_deferred_initializers__.current=function(a,b,c,$){var A,B
A=c[0]
B=c[490]
var z=a.updateTypes([]);(function constants(){B.Fb=new A.a0(58514,"MaterialIcons",!1)})()};
(a=>{a["TbZhDYUA/o80iAMrJwRnfPWIt+0="]=a.current})($__dart_deferred_initializers__);