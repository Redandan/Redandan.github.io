((a,b)=>{a[b]=a[b]||{}})(self,"$__dart_deferred_initializers__")
$__dart_deferred_initializers__.current=function(a,b,c,$){var A,B
A=c[0]
B=c[508]
var z=a.updateTypes([]);(function constants(){B.nr=new A.a0(58599,"MaterialIcons",!1)})()};
(a=>{a["o23AqdJlq76qM2h+NmVZeJN8IX8="]=a.current})($__dart_deferred_initializers__);