((a,b)=>{a[b]=a[b]||{}})(self,"$__dart_deferred_initializers__")
$__dart_deferred_initializers__.current=function(a,b,c,$){var B,C,A
B=c[0]
C=c[2]
A=c[424]
var z=a.updateTypes([]);(function constants(){var y=a.makeConstList
A.RH=new B.a0(57920,"MaterialIcons",!1)
A.yn=new B.f6(null,null,null,"\u986f\u793a\u540d\u7a31",null,null,null,null,null,null,null,null,null,null,null,null,!0,!0,!1,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,!0,null,null,null,null)
A.tT=new B.f6(null,null,null,"TG \u7fa4\u540d\u7a31",null,null,null,null,null,null,null,null,null,null,null,null,!0,!0,!1,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,!0,null,null,null,null)
A.Ug=new B.f6(null,null,null,"Telegram Group ID",null,null,null,"\u5fc5\u586b\uff0c\u53ef\u586b -100 \u958b\u982d\u7684\u7fa4\u7d44 ID",null,null,null,null,null,null,null,null,!0,!0,!1,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,!0,null,null,null,null)
A.UX=y(["PENDING","APPROVED","REJECTED","CANCELLED"],B.C("v<n>"))
A.pO=y([],B.C("v<kk>"))
A.u0=y([],B.C("v<kX>"))
A.aLt=new B.ar(0,80,0,80)
A.HL=new B.J(A.aLt,C.bV,null)})()};
(a=>{a["2K9WMHhOYLvBTyJ70+MDr5ahydk="]=a.current})($__dart_deferred_initializers__);