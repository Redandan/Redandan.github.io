((a,b)=>{a[b]=a[b]||{}})(self,"$__dart_deferred_initializers__")
$__dart_deferred_initializers__.current=function(a,b,c,$){var A,B
A=c[0]
B=c[526]
var z=a.updateTypes([]);(function constants(){B.F4=new A.a0(58149,"MaterialIcons",!1)})()};
(a=>{a["Tr70VUbP6vg1S1z3CrLxpKAvEGw="]=a.current})($__dart_deferred_initializers__);