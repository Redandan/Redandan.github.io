((a,b)=>{a[b]=a[b]||{}})(self,"$__dart_deferred_initializers__")
$__dart_deferred_initializers__.current=function(a,b,c,$){var A,C,B={bc1:function bc1(d,e){this.a=d
this.b=e},ajx:function ajx(d,e,f,g,h,i,j,k,l){var _=this
_.c=d
_.d=e
_.go=f
_.id=g
_.k3=h
_.k4=i
_.p1=j
_.xr=k
_.a=l},ccs:function ccs(d){this.a=d}},E,D,F
A=c[0]
C=c[2]
B=a.updateHolder(c[214],B)
E=c[772]
D=c[254]
F=c[805]
B.bc1.prototype={
W(){return"_SwitchListTileType."+this.b}}
B.ajx.prototype={
u(d){var x,w,v,u,t,s,r,q,p=this,o=null
switch(p.p1.a){case 1:x=new A.Dc(!0,new D.ajw(p.c,p.d,o,o,o,o,o,o,o,o,o,o,o,o,o,C.cD,F.ai3,p.xr,C.w,o,o,o,o,!1,o),o)
break
case 0:x=new A.Dc(!0,D.a3d(o,o,o,o,!1,C.w,o,o,o,C.cD,o,o,p.d,o,o,o,o,o,o,o,o,p.c),o)
break
default:x=o}A.adQ(d)
A:{w=new A.bc(o,x)
break A}v=w.a
u=w.b
t=A.t(d)
s=D.e4O(d)
w=s.a
w=w==null?o:w.am(A.aS(y.c))
r=w
if(r==null)r=t.ax.y
w=p.d!=null
q=w?new B.ccs(p):o
return new A.r5(A.dm(!1,p.k4,p.k3,o,w,o,o,o,!1,o,o,v,o,o,o,o,o,q,!1,r,o,o,o,p.id,o,p.go,o,o,u,o),o)}}
var z=a.updateTypes([])
B.ccs.prototype={
$0(){var x=this.a
x.d.$1(!x.c)},
$S:0};(function inheritance(){var x=a.inherit
x(B.bc1,A.eD)
x(B.ajx,A.x)
x(B.ccs,A.bu)})()
A.b0(b.typeUniverse,JSON.parse('{"ajx":{"x":[],"m":[]}}'))
var y={c:A.C("eH")};(function constants(){E.cfQ=new B.bc1(0,"material")
E.cfR=new B.bc1(1,"adaptive")})()};
(a=>{a["BT45GeguClf5Lb++F4IllKqrTKA="]=a.current})($__dart_deferred_initializers__);