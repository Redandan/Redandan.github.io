((a,b)=>{a[b]=a[b]||{}})(self,"$__dart_deferred_initializers__")
$__dart_deferred_initializers__.current=function(a,b,c,$){var A={
wQ(d){var y
if(!d.c)return d
y=d.fK()
return y}}
A=a.updateHolder(c[248],A)
var z=a.updateTypes([])};
(a=>{a["unJhvaOiokuAcSBnL6E2848TghM="]=a.current})($__dart_deferred_initializers__);