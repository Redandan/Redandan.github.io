((a,b)=>{a[b]=a[b]||{}})(self,"$__dart_deferred_initializers__")
$__dart_deferred_initializers__.current=function(a,b,c,$){var B,C,A
B=c[0]
C=c[2]
A=c[426]
var z=a.updateTypes([]);(function constants(){var y=a.makeConstList
A.RD=new B.a0(57920,"MaterialIcons",!1)
A.ye=new B.f7(null,null,null,"\u986f\u793a\u540d\u7a31",null,null,null,null,null,null,null,null,null,null,null,null,!0,!0,!1,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,!0,null,null,null,null)
A.tK=new B.f7(null,null,null,"TG \u7fa4\u540d\u7a31",null,null,null,null,null,null,null,null,null,null,null,null,!0,!0,!1,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,!0,null,null,null,null)
A.Uc=new B.f7(null,null,null,"Telegram Group ID",null,null,null,"\u5fc5\u586b\uff0c\u53ef\u586b -100 \u958b\u982d\u7684\u7fa4\u7d44 ID",null,null,null,null,null,null,null,null,!0,!0,!1,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,!0,null,null,null,null)
A.UU=y(["PENDING","APPROVED","REJECTED","CANCELLED"],B.C("v<n>"))
A.pH=y([],B.C("v<kh>"))
A.tR=y([],B.C("v<kQ>"))
A.aLq=new B.ar(0,80,0,80)
A.HA=new B.J(A.aLq,C.bX,null)})()};
(a=>{a["Ko1T9E0nZLAdoKHNl9zwkcY3LLg="]=a.current})($__dart_deferred_initializers__);