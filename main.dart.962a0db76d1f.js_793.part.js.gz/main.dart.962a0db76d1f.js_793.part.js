((a,b)=>{a[b]=a[b]||{}})(self,"$__dart_deferred_initializers__")
$__dart_deferred_initializers__.current=function(a,b,c,$){var A,B
A=c[0]
B=c[735]
var z=a.updateTypes([]);(function constants(){B.T0=new A.a0(984320,"MaterialIcons",!1)})()};
(a=>{a["iCQXwH8nlnFSMLhvo0ZSwodgj/g="]=a.current})($__dart_deferred_initializers__);