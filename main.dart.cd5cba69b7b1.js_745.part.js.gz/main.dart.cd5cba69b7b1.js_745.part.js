((a,b)=>{a[b]=a[b]||{}})(self,"$__dart_deferred_initializers__")
$__dart_deferred_initializers__.current=function(a,b,c,$){var A,B
A=c[0]
B=c[501]
var z=a.updateTypes([]);(function constants(){B.AT=new A.br("\u5168\u90e8",null,null,null,null,null,null,null,null,null,null)})()};
(a=>{a["sWKlQ5iLWPPna5EufB7WPw92i54="]=a.current})($__dart_deferred_initializers__);