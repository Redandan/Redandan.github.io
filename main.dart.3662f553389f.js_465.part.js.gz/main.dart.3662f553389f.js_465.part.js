((a,b)=>{a[b]=a[b]||{}})(self,"$__dart_deferred_initializers__")
$__dart_deferred_initializers__.current=function(a,b,c,$){var A,B,C={
eZB(d,e){var x,w=d.d
w=new A.F(w,new C.dSU(e),A.V(w).k("F<1,n>")).n8(0,new C.dSV())
w=A.en(w,w.$ti.k("a5.E"))
w=A.O(w,A.D(w).c)
w.$flags=1
x=w
if(x.length===0)return""
return e.ax0(B.d.b6(x,e.ga70()))},
eYK(d,e){switch(B.b.F(d).toUpperCase()){case"EMAIL_CODE":return"Email"
case"TELEGRAM_BOT":return"Telegram"
case"GOOGLE":return"Google"
case"WALLET_CONNECT":return e.gIs()
case"PASSKEY_PRIMARY_DOMAIN":return e.gax_()
default:return""}},
dSU:function dSU(d){this.a=d},
dSV:function dSV(){},
a87:function a87(d,e,f,g){var _=this
_.c=d
_.d=e
_.e=f
_.a=g}},D,E
A=c[0]
B=c[2]
C=a.updateHolder(c[113],C)
D=c[752]
E=c[586]
C.a87.prototype={
u(d){var x,w,v,u,t,s,r,q,p,o,n,m,l=null,k=this.c
if((k==null?l:k.a)!==!0)return B.a9
x=A.t(d)
w=x.ax
v=A.f(d,B.c,y.p)
v.toString
k.toString
u=C.eZB(k,v)
t=w.id
t=(t==null?w.fy:t).B(0.36)
s=A.G(8)
r=w.fy
q=A.aN(r.B(0.28),B.u,1)
r=A.T(E.y3,r,l,l,l)
p=v.gawY()
o=x.ok
n=o.x
m=y.e
n=A.a([A.d(p,l,l,l,l,l,n==null?l:n.aX(w.k3,B.F),l,l,l),B.P,A.d(A.epo(k,v),l,l,l,l,l,o.z,l,l,l)],m)
if(u.length!==0){p=o.Q
if(p==null)p=l
else{o=w.rx
p=p.a0(o==null?w.k3:o)}B.d.v(n,A.a([B.P,A.d(u,l,l,l,l,l,p,l,l,l)],m))}r=A.a([r,B.ai,A.P(A.w(n,B.m,l,B.e,B.f,0,B.j),1,l)],m)
p=this.d
if(p!=null){o=this.e
B.d.v(r,A.a([B.ai,A.aI(A.d(o==null?v.ga1s():o,l,l,l,l,l,l,l,l,l),D.c_G,l,l,p,l,l)],m))}return A.W(l,A.z(r,B.m,l,B.e,B.f,0,l,l),B.o,l,l,new A.R(t,l,q,s,l,l,B.r),l,l,D.c_H,l,B.B,l,l,l)}}
var z=a.updateTypes([])
C.dSU.prototype={
$1(d){return C.eYK(d,this.a)},
$S:38}
C.dSV.prototype={
$1(d){return d.length!==0},
$S:9};(function inheritance(){var x=a.inheritMany,w=a.inherit
x(A.bt,[C.dSU,C.dSV])
w(C.a87,A.x)})()
A.b0(b.typeUniverse,JSON.parse('{"a87":{"x":[],"m":[]}}'))
var y={p:A.C("bv"),e:A.C("v<m>"),a:A.C("H<n>")};(function constants(){D.c_G=new A.H("accountRecoveryAdvisoryAction",y.a)
D.c_H=new A.H("accountRecoveryAdvisoryBanner",y.a)})()};
(a=>{a["5i9g0Xb84swb7pIYqP42JDsyuzk="]=a.current})($__dart_deferred_initializers__);