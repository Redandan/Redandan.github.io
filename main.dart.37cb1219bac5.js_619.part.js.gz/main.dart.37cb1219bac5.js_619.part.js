((a,b)=>{a[b]=a[b]||{}})(self,"$__dart_deferred_initializers__")
$__dart_deferred_initializers__.current=function(a,b,c,$){var A,C,B={
ei0(d){var x=A.a_(["id",d],y.g,y.b)
return new B.aUq("TransactionDetailRoute",new A.Fw(null,d),x,C.af,null,"")},
aUq:function aUq(d,e,f,g,h,i){var _=this
_.a=d
_.b=e
_.c=f
_.d=g
_.e=h
_.f=i}}
A=c[0]
C=c[2]
B=a.updateHolder(c[159],B)
B.aUq.prototype={}
var z=a.updateTypes([]);(function inheritance(){var x=a.inherit
x(B.aUq,A.bV)})()
A.b_(b.typeUniverse,JSON.parse('{"aUq":{"bV":["Fw"]}}'))
var y={g:A.B("n"),b:A.B("@")}};
(a=>{a["dNk1/dy/ch0dxcQjiqHHgbLL4vY="]=a.current})($__dart_deferred_initializers__);