((a,b)=>{a[b]=a[b]||{}})(self,"$__dart_deferred_initializers__")
$__dart_deferred_initializers__.current=function(a,b,c,$){var A,C,B={
ejP(d){var x=A.a_(["orderId",d],y.g,y.b)
return new B.aVd("UserOrderDetailRoute",new A.FJ(null,d),x,C.ae,null,"")},
aVd:function aVd(d,e,f,g,h,i){var _=this
_.a=d
_.b=e
_.c=f
_.d=g
_.e=h
_.f=i}}
A=c[0]
C=c[2]
B=a.updateHolder(c[199],B)
B.aVd.prototype={}
var z=a.updateTypes([]);(function inheritance(){var x=a.inherit
x(B.aVd,A.bU)})()
A.b0(b.typeUniverse,JSON.parse('{"aVd":{"bU":["FJ"]}}'))
var y={g:A.C("n"),b:A.C("@")}};
(a=>{a["XvIizG6Mo8K5wdHs+ht3PWrI1rs="]=a.current})($__dart_deferred_initializers__);