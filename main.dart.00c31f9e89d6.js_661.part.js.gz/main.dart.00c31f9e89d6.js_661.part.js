((a,b)=>{a[b]=a[b]||{}})(self,"$__dart_deferred_initializers__")
$__dart_deferred_initializers__.current=function(a,b,c,$){var J,A,C,E,K,F,G,L,M,N,O,P,Q,H,B={
Nd(d,e,f,g,h){return B.eX0(d,e,f,g,h)},
eX0(d,e,f,a0,a1){var x=0,w=A.l(y.H),v,u,t,s,r,q,p,o,n,m,l,k,j,i,h,g
var $async$Nd=A.h(function(a2,a3){if(a2===1)return A.i(a3,w)
for(;;)switch(x){case 0:j={}
i=y.N
h=y.c
g=A.r(i,h)
for(v=e.length,u=0;t=e.length,u<t;e.length===v||(0,A.aa)(e),++u){s=e[u]
if(s.c===D.c3){t=s.a
r=f.i(0,t)
A.b3(r)
if(r==null)r=""
g.h(0,t,new A.ai(new A.bw(r,C.aq,C.ah),$.a9()))}}v=y.z
r=A.r(i,v)
for(u=0;q=e.length,u<q;e.length===t||(0,A.aa)(e),++u){s=e[u]
if(s.c===D.ig){q=s.a
p=f.i(0,q)
r.h(0,q,p)}}for(t=y.m,p=y.R,o=y.y,u=0;u<e.length;e.length===q||(0,A.aa)(e),++u){s=e[u]
if(s.c===D.PF){n=s.a
m=n+"_checkboxes"
l=f.i(0,m)
p.a(l)
n+="_controllers"
k=f.i(0,n)
t.a(k)
if(l!=null)r.h(0,m,A.os(l,i,o))
if(k!=null)r.h(0,n,A.os(k,i,h))}}j.a=!1
x=2
return A.c(A.bc(null,null,!1,null,new B.dRh(j,a1,new A.bf(null,y.w),e,new B.t_(g,r),!0,a0),d,null,!0,!0,v),$async$Nd)
case 2:return A.j(null,w)}})
return A.k($async$Nd,w)},
eLi(d,e,f,g){var x,w,v,u,t=A.r(y.T,y.X)
for(x=e.length,w=0;w<e.length;e.length===x||(0,A.aa)(e),++w){v=e[w]
J.c3(t.dv(v.r,new B.dFu()),v)}u=A.a([],y.p)
t.b8(0,new B.dFv(u,d,f,g))
return u},
eLh(d,e,f,g){var x,w,v,u,t=null,s=e.x,r=e.b
if(s)r+=" *"
switch(e.c.a){case 0:x=e.a
w=f.a.i(0,x)
v=A.t(d)
u=A.P(B.dZ9(x),t,t,t,t)
s=s?D.FB:t
s=A.aH(t,C.U,t,t,t,t,t,t,!0,t,t,t,t,t,t,v.ax.k2,!0,t,t,t,t,t,t,t,t,t,t,t,t,t,t,e.w,t,t,t,t,t,t,t,t,r,!0,!0,!1,t,u,t,t,t,t,t,t,s,t,t,t,t,t)
v=e.d!=null?new B.dFq(e):t
u=x==="description"?4:1
return new A.ad(1/0,t,A.bT(!0,t,!1,w,s,!0,t,!1,t,t,t,t,B.eNc(x),u,t,!1,t,t,t,t,t,!1,t,t,C.L,C.M,t,v),t)
case 1:x=A.t(d)
w=e.a
v=A.P(B.dZ9(w),t,t,t,t)
s=s?D.FB:t
s=A.aH(t,C.U,t,t,t,t,t,t,!0,t,t,t,t,t,t,x.ax.k2,!0,t,t,t,t,t,t,t,t,t,t,t,t,t,t,t,t,t,t,t,t,t,t,t,r,!0,!0,!1,t,v,t,t,t,t,t,t,s,t,t,t,t,t)
w=f.b.i(0,w)
v=e.e
x=v==null?A.a([],y.k):v
v=e.d!=null?new B.dFr(e):t
return new A.ad(1/0,t,A.f3(s,t,w,!1,t,x,t,new B.dFs(g,f,e),t,v,y.z),t)
case 2:return B.eLl(d,e,f,g,r)
case 3:x=e.a
w=f.a.i(0,x)
v=A.t(d)
x=A.P(B.dZ9(x),t,t,t,t)
s=s?D.FB:t
s=A.aH(t,C.U,t,t,t,t,t,t,!0,t,t,t,t,t,t,v.ax.k2,!0,t,t,t,t,t,t,t,t,t,t,t,t,t,t,e.w,t,t,t,t,t,t,t,t,r,!0,!0,!1,t,x,t,t,t,t,t,t,s,t,t,t,t,t)
return new A.ad(1/0,t,A.bT(!0,t,!1,w,s,!0,t,!1,t,t,t,t,1000,4,t,!1,t,t,t,t,t,!1,t,t,C.L,C.M,t,e.d!=null?new B.dFt(e):t),t)
case 4:return B.eLn(d,e,f,g,r)}},
eNb(d){switch(d.toLowerCase()){case"\u57fa\u672c\u8cc7\u8a0a":case"basic info":return I.t5
case"\u904b\u9001\u76f8\u95dc":case"shipping":return G.hM
case"\u4f4d\u7f6e\u8cc7\u8a0a":case"location":return F.fy
case"sku\u8cc7\u8a0a":case"sku":return C.kh
default:return C.rZ}},
dZ9(d){switch(d){case"title":return D.aNA
case"description":return H.n6
case"price":return R.jd
case"stock":return C.kh
case"category":return C.rZ
case"status":return I.t5
case"brand":return D.aMA
case"shippingFee":return G.hM
case"shippingPreparationHours":return P.il
case"dailyShippingDeadline":return Q.oZ
case"shippingDescription":return H.n6
case"freeShippingThreshold":return S.QH
case"longitude":return D.aMT
case"latitude":return F.fy
case"skus":return C.kh
default:return E.cS}},
eNc(d){switch(d){case"title":return 100
case"description":return 1000
case"brand":return 50
case"shippingDescription":return 500
case"skus":return 1000
default:return null}},
eOY(d,e){var x=y.J,w=A.f(d,C.b,x).ayl(e),v=A.t(d)
A.axB(d,w,A.x5(A.f(d,C.b,x).gawv(),new B.dKM(d),A.t(d).ax.go),v.ax.fy,C.id,M.QA)},
eLl(d,e,f,g,h){var x,w,v=null,u=A.d(h,v,v,v,v,v,A.t(d).ok.w,v,v,v),t=A.t(d).ax,s=t.to
if(s==null){s=t.E
t=s==null?t.k3:s}else t=s
t=A.aL(t,C.u,1)
s=A.G(4)
x=A.a([],y.e)
w=y.K
x=A.T(new A.C(x,new B.dFy(A.aV(y.N),g,f,e),w),w.k("aj.E"))
return new A.ad(1/0,v,A.w(A.a([u,C.v,new A.c6(new A.S(v,v,t,s,v,v,C.r),C.aw,A.w(x,C.l,v,C.e,C.f,0,C.j),v)],y.p),C.m,v,C.e,C.f,0,C.j),v)},
eLn(d,e,f,g,h){var x,w,v,u,t,s,r,q,p,o=null,n=f.b,m=e.a,l=m+"_checkboxes"
if(!n.ar(l)){n.h(0,l,A.r(y.N,y.y))
for(x=0;x<5;++x){w=D.G2[x]
J.dq(n.i(0,l),w.i(0,"key"),!1)}}m+="_controllers"
if(!n.ar(m))n.h(0,m,A.r(y.N,y.c))
v=y.n
u=v.a(n.i(0,m))
for(x=0;x<5;++x){t=A.b8(D.G2[x].i(0,"key"))
if(!u.ar(t))u.h(0,t,new A.ai(C.N,$.a9()))}s=y.S.a(n.i(0,l))
r=v.a(n.i(0,m))
n=A.d(h,o,o,o,o,o,A.t(d).ok.w,o,o,o)
m=A.t(d).ax
l=m.d
m=(l==null?m.b:l).A(0.1)
l=A.G(8)
v=A.aL(A.t(d).ax.b.A(0.3),C.u,1)
q=y.p
l=A.X(o,A.z(A.a([A.P(C.bf,A.t(d).ax.b,o,o,16),C.B,A.R(A.d("\u5b85\u914d\u5230\u5e9c",o,o,o,o,o,A.H(o,o,A.t(d).ax.k3,o,o,o,o,o,o,o,o,12,o,o,o,o,o,!0,o,o,o,o,o,o,o,o),o,o,o),1,o)],q),C.l,o,C.e,C.f,0,o,o),C.o,o,o,new A.S(m,o,v,l,o,o,C.r),o,o,o,o,C.Y,o,o,o)
v=A.t(d).ax
m=v.to
if(m==null){m=v.E
if(m==null)m=v.k3}m=A.aL(m,C.u,1)
v=A.G(4)
p=y.F
p=A.T(new A.C(D.G2,new B.dFC(s,g,r),p),p.k("aj.E"))
return new A.ad(1/0,o,A.w(A.a([n,C.v,l,C.v,new A.c6(new A.S(o,o,m,v,o,o,C.r),C.aw,A.w(p,C.l,o,C.e,C.f,0,C.j),o)],q),C.m,o,C.e,C.f,0,C.j),o)},
a9R:function a9R(d,e){this.a=d
this.b=e},
ei:function ei(d,e,f,g,h,i,j,k){var _=this
_.a=d
_.b=e
_.c=f
_.d=g
_.e=h
_.r=i
_.w=j
_.x=k},
t_:function t_(d,e){this.a=d
this.b=e},
dRh:function dRh(d,e,f,g,h,i,j){var _=this
_.a=d
_.b=e
_.c=f
_.d=g
_.e=h
_.f=i
_.r=j},
dRg:function dRg(d,e,f,g,h,i,j){var _=this
_.a=d
_.b=e
_.c=f
_.d=g
_.e=h
_.f=i
_.r=j},
dRe:function dRe(d){this.a=d},
dRf:function dRf(d,e,f,g,h,i){var _=this
_.a=d
_.b=e
_.c=f
_.d=g
_.e=h
_.f=i},
dRc:function dRc(d){this.a=d},
dRd:function dRd(d){this.a=d},
dFu:function dFu(){},
dFv:function dFv(d,e,f,g){var _=this
_.a=d
_.b=e
_.c=f
_.d=g},
dFq:function dFq(d){this.a=d},
dFs:function dFs(d,e,f){this.a=d
this.b=e
this.c=f},
dFp:function dFp(d,e,f){this.a=d
this.b=e
this.c=f},
dFr:function dFr(d){this.a=d},
dFt:function dFt(d){this.a=d},
dKM:function dKM(d){this.a=d},
dFy:function dFy(d,e,f,g){var _=this
_.a=d
_.b=e
_.c=f
_.d=g},
dFx:function dFx(d,e,f,g,h){var _=this
_.a=d
_.b=e
_.c=f
_.d=g
_.e=h},
dFw:function dFw(d,e,f,g,h){var _=this
_.a=d
_.b=e
_.c=f
_.d=g
_.e=h},
dFC:function dFC(d,e,f){this.a=d
this.b=e
this.c=f},
dFB:function dFB(d,e,f,g){var _=this
_.a=d
_.b=e
_.c=f
_.d=g},
dFA:function dFA(d,e,f,g){var _=this
_.a=d
_.b=e
_.c=f
_.d=g}},D,I,R,S
J=c[1]
A=c[0]
C=c[2]
E=c[508]
K=c[397]
F=c[345]
G=c[333]
L=c[467]
M=c[788]
N=c[680]
O=c[322]
P=c[469]
Q=c[507]
H=c[714]
B=a.updateHolder(c[222],B)
D=c[431]
I=c[717]
R=c[436]
S=c[716]
B.a9R.prototype={
Y(){return"FieldType."+this.b}}
B.ei.prototype={}
B.t_.prototype={
dZ(d){var x=this.a.i(0,d)
x=x==null?null:x.a.a
return x==null?"":x}}
var z=a.updateTypes(["a3<ei>()","~(n?,a3<ei>)","GW(dW3)"])
B.dRh.prototype={
$1(d){var x=this
return new A.jQ(new B.dRg(x.a,x.b,x.c,x.d,x.e,x.f,x.r),null)},
$S:50}
B.dRg.prototype={
$2(d,e){var x,w,v,u,t,s,r,q,p,o,n,m,l=this,k=null,j=y.l,i=A.aI(d,C.ar,j).w.a.a
j=A.aI(d,C.ar,j).w
x=i<650
w=x?i-32:600
v=x?16:40
u=A.t(d)
t=y.p
s=A.z(A.a([A.P(E.cS,A.t(d).dx,k,k,k),C.B,A.R(A.d(l.b,k,k,k,k,k,A.t(d).ok.r,k,k,k),1,k)],t),C.l,k,C.e,C.f,0,k,k)
r=l.c
q=l.e
p=A.a([A.fH(k,A.b5(new A.ad(w,k,A.w(B.eLi(d,l.d,q,e),C.m,k,C.e,C.f,0,C.j),k),C.q,k,C.w,k,k,k,k,k,C.y),r)],t)
o=l.a
if(o.a&&l.f){n=C.W.A(0.3)
p.push(A.kG(0,A.bdo(!0,A.eo(A.aK(A.w(A.a([C.j0,C.n,A.d(A.f(d,C.b,y.J).gayT(),k,k,k,k,k,C.hV,k,k,k)],t),C.l,k,C.e,C.I,0,C.j),k,k,k),n,!0))))}n=o.a?k:new B.dRe(d)
m=y.J
n=A.ea(C.SF,k,A.d(A.f(d,C.b,m).gawt(),k,k,k,k,k,k,k,k,k),n,k)
r=o.a?k:new B.dRf(o,d,r,e,l.r,q)
return A.be(A.a([n,A.f7(D.xN,k,A.d(A.f(d,C.b,m).gaAC(),k,k,k,k,k,k,k,k,k),r,A.hk(k,k,A.t(d).ax.b,k,k,k,k,k,k,A.t(d).ax.c,k,k,k,k,k,k,k,k,k,k))],t),k,u.ax.k2,new A.ad(w,j.a.b*0.7,new A.cT(C.aY,k,C.aT,C.q,p,k),k),new A.ar(v,24,v,24),k,!1,k,s)},
$S:66}
B.dRe.prototype={
$0(){A.ac(this.a,!1).af(null)
return null},
$S:0}
B.dRf.prototype={
$0(){var x=0,w=A.l(y.H),v,u=2,t=[],s=this,r,q,p,o,n,m,l
var $async$$0=A.h(function(d,e){if(d===1){t.push(e)
x=u}for(;;)switch(x){case 0:n=s.b
m=n
if(!s.c.gaj().eO()){A.a6(n,A.f(n,C.b,y.J).gawu(),C.a2,null)
x=1
break}q=s.d
p=s.a
q.$1(new B.dRc(p))
u=4
x=7
return A.c(s.e.$1(s.f),$async$$0)
case 7:if(m.e!=null)A.ac(m,!1).af(null)
u=2
x=6
break
case 4:u=3
l=t.pop()
r=A.u(l)
q.$1(new B.dRd(p))
if(m.e!=null)B.eOY(m,J.as(r))
x=6
break
case 3:x=2
break
case 6:case 1:return A.j(v,w)
case 2:return A.i(t.at(-1),w)}})
return A.k($async$$0,w)},
$S:3}
B.dRc.prototype={
$0(){return this.a.a=!0},
$S:0}
B.dRd.prototype={
$0(){return this.a.a=!1},
$S:0}
B.dFu.prototype={
$0(){return A.a([],y.W)},
$S:z+0}
B.dFv.prototype={
$2(d,e){var x,w,v,u,t,s=this,r=null,q=d!=null
if(q&&d.length!==0){x=s.b
s.a.push(new A.J(D.aGW,new A.ad(1/0,r,A.z(A.a([A.P(B.eNb(d),A.t(x).dx,r,r,20),C.B,A.d(d,r,r,r,r,r,A.H(r,r,A.t(x).dx,r,r,r,r,r,r,r,r,16,r,r,C.A,r,r,!0,r,r,r,r,r,r,r,r),r,r,r)],y.p),C.l,r,C.e,C.f,0,r,r),r),r))}for(x=J.aZ(e),w=s.a,v=s.b,u=s.c,t=s.d;x.G();)w.push(new A.J(C.cq,B.eLh(v,x.gR(),u,t),r))
if(q&&d.length!==0)w.push(O.CZ)},
$S:z+1}
B.dFq.prototype={
$1(d){return this.a.d.$1(d)},
$S:12}
B.dFs.prototype={
$1(d){this.a.$1(new B.dFp(this.b,this.c,d))},
$S:13}
B.dFp.prototype={
$0(){var x=this.c
this.a.b.h(0,this.b.a,x)
return x},
$S:0}
B.dFr.prototype={
$1(d){return this.a.d.$1(d)},
$S:22}
B.dFt.prototype={
$1(d){return this.a.d.$1(d)},
$S:12}
B.dKM.prototype={
$0(){this.a.aa(y.q).f.aWf()},
$S:0}
B.dFy.prototype={
$1(d){var x=this,w=null,v=x.a
return A.Oo(w,w,w,w,new B.dFx(x.b,v,d,x.c,x.d),w,A.d(d.ga5S(),w,w,w,w,w,w,w,w,w),v.t(0,d.gD()))},
$S:z+2}
B.dFx.prototype={
$1(d){var x=this
x.a.$1(new B.dFw(d,x.b,x.c,x.d,x.e))},
$S:25}
B.dFw.prototype={
$0(){var x=this,w=x.b,v=x.c
if(x.a===!0)w.I(0,v.gD())
else w.N(0,v.gD())
w=A.T(w,A.E(w).c)
x.d.b.h(0,x.e.a,w)},
$S:0}
B.dFC.prototype={
$1(d){var x,w,v,u,t=null,s=A.b8(d.i(0,"key")),r=A.b8(d.i(0,"label")),q=y.Z.a(d.i(0,"icon")),p=this.a,o=p.i(0,s),n=this.c
o=A.od(t,!1,t,t,t,!1,t,t,t,new B.dFB(this.b,p,s,n),t,t,t,t,t,!1,o===!0,t)
x=A.P(q,t,t,t,20)
w=A.R(A.d(r,t,t,t,t,t,C.ex,t,t,t),2,t)
n=n.i(0,s)
v=s==="HOME_DELIVERY"
u=v?"\u904b\u8cbb\uff08100\uff09":"\u904b\u8cbb\uff0860\uff09"
u=A.aH(t,C.U,t,C.au,t,t,t,t,!0,t,t,t,t,t,t,t,t,t,t,t,t,t,t,t,t,t,t,t,t,t,t,v?"100":"60",t,t,t,t,t,t,t,t,u,!0,!0,!1,t,t,t,t,t,t,t,t,t,t,t,t,t,t)
p=p.i(0,s)
return new A.J(C.au,A.z(A.a([o,x,C.B,w,C.B,A.R(A.bT(!0,t,!1,n,u,!0,p===!0,!1,t,t,t,C.aE,t,1,t,!1,t,t,t,t,t,!1,t,L.fX,C.L,C.M,t,t),1,t)],y.p),C.l,t,C.e,C.f,0,t,t),t)},
$S:1830}
B.dFB.prototype={
$1(d){var x=this
x.a.$1(new B.dFA(x.b,x.c,d,x.d))},
$S:25}
B.dFA.prototype={
$0(){var x=this,w=x.b,v=x.c===!0
x.a.h(0,w,v)
if(!v){w=x.d.i(0,w)
if(w!=null)w.sD(C.a0)}},
$S:0};(function inheritance(){var x=a.inherit,w=a.inheritMany
x(B.a9R,A.ew)
w(A.A,[B.ei,B.t_])
w(A.bt,[B.dRh,B.dFq,B.dFs,B.dFr,B.dFt,B.dFy,B.dFx,B.dFC,B.dFB])
w(A.c5,[B.dRg,B.dFv])
w(A.bs,[B.dRe,B.dRf,B.dRc,B.dRd,B.dFu,B.dFp,B.dKM,B.dFw,B.dFA])})()
var y=(function rtii(){var x=A.F
return{J:x("bv"),M:x("aT<n,A>"),Z:x("a_"),k:x("v<bB<@>>"),W:x("v<ei>"),e:x("v<dW3>"),p:x("v<m>"),w:x("bf<ig>"),X:x("a3<ei>"),n:x("a1<n,ai>"),S:x("a1<n,D>"),K:x("C<dW3,GW>"),F:x("C<a1<n,A>,J>"),l:x("dZ"),N:x("n"),c:x("ai"),q:x("lH"),y:x("D"),z:x("@"),m:x("a1<n,ai>?"),R:x("a1<n,D>?"),T:x("n?"),H:x("~")}})();(function constants(){var x=a.makeConstList
D.aGW=new A.ar(0,16,0,8)
D.c3=new B.a9R(0,"text")
D.ig=new B.a9R(1,"dropdown")
D.PF=new B.a9R(4,"shippingCompanies")
D.aMA=new A.a_(57603,"MaterialIcons",!1)
D.aMT=new A.a_(57928,"MaterialIcons",!1)
D.aNA=new A.a_(58984,"MaterialIcons",!1)
D.xN=new A.at(N.EM,null,null,null,null)
D.FB=new A.at(K.h7,16,C.aF,null,null)
D.tV={key:0,label:1,icon:2}
D.bgG=new A.aT(D.tV,["HOME_DELIVERY","\u5b85\u914d\u5230\u5e9c",C.p1],y.M)
D.bgH=new A.aT(D.tV,["SEVEN_ELEVEN","7-ELEVEN",C.cr],y.M)
D.bgJ=new A.aT(D.tV,["FAMILY_MART","\u5168\u5bb6\u4fbf\u5229\u5546\u5e97",C.cr],y.M)
D.bgF=new A.aT(D.tV,["HILIFE","\u840a\u723e\u5bcc",C.cr],y.M)
D.bgI=new A.aT(D.tV,["OK_MART","OK\u8d85\u5546",C.cr],y.M)
D.G2=x([D.bgG,D.bgH,D.bgJ,D.bgF,D.bgI],A.F("v<a1<n,A>>"))})()};
(a=>{a["aXV7vYOU6JDmW9UlgNlhyCE/UpE="]=a.current})($__dart_deferred_initializers__);