((a,b)=>{a[b]=a[b]||{}})(self,"$__dart_deferred_initializers__")
$__dart_deferred_initializers__.current=function(a,b,c,$){var A,B
A=c[0]
B=c[538]
var z=a.updateTypes([]);(function constants(){B.adB=new A.aX(80,80,8,null,null)})()};
(a=>{a["Y/pqePyX/lDcR/SsSE/Q2sEg6JE="]=a.current})($__dart_deferred_initializers__);