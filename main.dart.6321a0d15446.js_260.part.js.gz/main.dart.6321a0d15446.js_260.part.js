((a,b)=>{a[b]=a[b]||{}})(self,"$__dart_deferred_initializers__")
$__dart_deferred_initializers__.current=function(a,b,c,$){var J,A,C,B={
a34(d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,a0){return new B.ajn(a0,p,d,e,g,j,l,f,o,k,r,u,w,x,v,m,D.cfF,!1,i,n,s,t,q,!1,null)},
e4N(d){var x=null
return new B.bbG(d,x,x,x,x,x,x,x,x,x,x)},
bbK:function bbK(d,e){this.a=d
this.b=e},
ajn:function ajn(d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,a0,a1,a2,a3){var _=this
_.c=d
_.d=e
_.e=f
_.f=g
_.r=h
_.w=i
_.x=j
_.y=k
_.z=l
_.Q=m
_.as=n
_.at=o
_.ax=p
_.ay=q
_.CW=r
_.cx=s
_.cy=t
_.db=u
_.dx=v
_.dy=w
_.fy=x
_.go=a0
_.k1=a1
_.k2=a2
_.a=a3},
a5x:function a5x(d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,a0,a1,a2,a3,a4,a5,a6){var _=this
_.c=d
_.d=e
_.e=f
_.f=g
_.r=h
_.w=i
_.x=j
_.y=k
_.z=l
_.Q=m
_.as=n
_.at=o
_.ax=p
_.ay=q
_.ch=r
_.cx=s
_.cy=t
_.db=u
_.dx=v
_.dy=w
_.fr=x
_.fx=a0
_.fy=a1
_.go=a2
_.id=a3
_.k1=a4
_.k2=a5
_.a=a6},
aqh:function aqh(d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s){var _=this
_.d=d
_.f=_.e=!1
_.ns$=e
_.l8$=f
_.ow$=g
_.ox$=h
_.qr$=i
_.uw$=j
_.qs$=k
_.ux$=l
_.PQ$=m
_.a5O$=n
_.t_$=o
_.qt$=p
_.qu$=q
_.dx$=r
_.dy$=s
_.c=_.a=null},
cZT:function cZT(d){this.a=d},
cZU:function cZU(d){this.a=d},
cZS:function cZS(d){this.a=d},
cZV:function cZV(d,e){this.a=d
this.b=e},
auJ:function auJ(d,e){var _=this
_.aa=_.E=_.br=_.b3=_.y2=_.y1=_.xr=_.x2=_.x1=_.to=_.ry=_.rx=_.RG=_.R8=_.p4=_.p3=_.p2=_.p1=_.ok=_.k4=_.k3=_.k2=_.k1=_.id=_.go=_.fy=_.fx=_.fr=_.dy=_.dx=null
_.am=_.aq=_.ae=null
_.aL=d
_.b4=_.bn=_.aY=_.aE=null
_.dM=_.b5=!1
_.cj=_.e2=null
_.dv=$
_.ax=_.at=_.as=_.Q=_.z=_.y=_.x=_.w=_.r=_.f=_.e=_.d=_.c=_.b=_.a=null
_.k4$=0
_.ok$=e
_.p2$=_.p1$=0},
dwU:function dwU(d,e,f){this.a=d
this.b=e
this.c=f},
bbI:function bbI(){},
bbE:function bbE(){},
bbF:function bbF(d,e,f,g,h,i,j,k,l,m,n){var _=this
_.z=d
_.a=e
_.b=f
_.c=g
_.d=h
_.e=i
_.f=j
_.r=k
_.w=l
_.x=m
_.y=n},
dwM:function dwM(){},
dwO:function dwO(d){this.a=d},
dwN:function dwN(d){this.a=d},
dwJ:function dwJ(d,e){this.a=d
this.b=e},
dwK:function dwK(d){this.a=d},
bbG:function bbG(d,e,f,g,h,i,j,k,l,m,n){var _=this
_.z=d
_.Q=$
_.a=e
_.b=f
_.c=g
_.d=h
_.e=i
_.f=j
_.r=k
_.w=l
_.x=m
_.y=n},
dwR:function dwR(d){this.a=d},
dwS:function dwS(d){this.a=d},
dwT:function dwT(d){this.a=d},
dwQ:function dwQ(d){this.a=d},
dwP:function dwP(){},
Xe:function Xe(d,e){this.a=d
this.b=e},
dwL:function dwL(d){this.a=d},
ax3:function ax3(){},
ax4:function ax4(){},
bft:function bft(){},
bfu:function bfu(){},
C5:function C5(){},
e3l(d){var x
d.a9(y.y)
x=A.t(d)
return x.iq}},D,E
J=c[1]
A=c[0]
C=c[2]
B=a.updateHolder(c[254],B)
D=c[803]
E=c[797]
B.bbK.prototype={
W(){return"_SwitchType."+this.b}}
B.ajn.prototype={
db5(d){var x,w,v,u,t,s=A.t(d),r=B.e3l(d),q=B.e4N(d)
if(this.cy===D.ai_){x=s.c2n(y.c)
r=(x==null?D.NQ:x).cqw(s,r)}w=new B.Xe(d,A.t(d).ax)
v=this.cx
u=v==null?r.e:v
if(u==null)u=s.f
t=r.y
if(t==null)t=q.geb()
switch(u.a){case 0:v=new A.ae(w.gc5w()+t.gfS(),w.gcQx()+(t.gea()+t.ged()))
break
case 1:v=new A.ae(w.gc5w()+t.gfS(),w.gcQy()+(t.gea()+t.ged()))
break
default:v=null}return v},
u(d){var x,w,v=this,u=null,t=v.cy,s=u,r=u
switch(t.a){case 0:s=v.e
break
case 1:switch(A.t(d).w.a){case 0:case 1:case 3:case 5:s=v.e
break
case 2:case 4:r=v.e
break}break}x=v.db5(d)
w=v.f
if(w==null)w=s
return new B.a5x(v.c,v.d,w,r,v.w,v.x,v.y,v.z,v.Q,v.as,v.at,v.ax,v.ay,u,v.CW,v.dx,v.dy,u,u,v.fy,v.go,u,v.k1,!1,x,v.db,t,u)}}
B.a5x.prototype={
O(){var x=null
return new B.aqh(new B.auJ(A.y8(x,x,x,x,x,C.J,x,x,C.h7,C.bH),$.aa()),$,$,$,$,$,$,$,$,C.c6,$,x,!1,!1,x,x)}}
B.aqh.prototype={
aQ(d){var x,w=this
w.aZ(d)
if(d.c!==w.a.c){x=w.l8$
x===$&&A.e()
if(x.gC()===0||w.l8$.gC()===1)switch(w.a.k2.a){case 1:x=w.c
x.toString
switch(A.t(x).w.a){case 0:case 1:case 3:case 5:w.czr()
break
case 2:case 4:x=w.l8$
x.c=x.b=C.aJ
break}break
case 0:w.czr()
break}w.aF2()}},
q(){this.d.q()
this.cPh()},
gmt(){return this.a.d!=null?this.gcmZ():null},
gTV(){return!1},
gC(){return this.a.c},
czr(){var x=this.c
x.toString
A.t(x)
x=this.l8$
x===$&&A.e()
x.b=E.Df
x.c=new A.tx(E.Df)},
gawy(){return new A.bX(new B.cZT(this),y.b)},
gcqa(){return new A.bX(new B.cZU(this),y.b)},
gcnR(){var x,w,v,u=this
switch(u.a.k2.a){case 1:x=u.c
x.toString
switch(A.t(x).w.a){case 0:case 1:case 3:case 5:x=u.c
x.toString
A.t(x)
x=u.c
x.toString
w=new B.Xe(x,A.t(x).ax)
v=w.gaaW()/2
return w.gaaY()-v-v
case 2:case 4:x=u.c
x.toString
A.t(x)
return 20}break
case 0:x=u.c
x.toString
A.t(x)
x=u.c
x.toString
w=new B.Xe(x,A.t(x).ax)
v=w.gaaW()/2
return w.gaaY()-v-v}},
dGE(d){var x
if(this.gmt()!=null){x=this.ow$
x===$&&A.e()
x.dA()}},
dGG(d){var x,w,v,u,t=this
if(t.gmt()!=null){x=t.l8$
x===$&&A.e()
x.b=C.aJ
x=x.c=null
w=d.e
w.toString
v=w/t.gcnR()
w=t.ns$
w===$&&A.e()
u=w.x
u===$&&A.e()
switch(t.c.a9(y.I).w.a){case 0:x=-v
break
case 1:x=v
break}w.sC(u+x)}},
dGC(d){var x,w,v=this,u=v.l8$
u===$&&A.e()
u=u.gC()
x=v.a
w=x.c
if(u>=0.5!==w){u=x.d
if(u!=null)u.$1(!w)
v.n(new B.cZS(v))}else v.aF2()
u=v.ow$
u===$&&A.e()
u.eI()},
dGA(d){var x=this.a.d
if(x!=null){d.toString
x.$1(d)}},
u(c5){var x,w,v,u,t,s,r,q,p,o,n,m,l,k,j,i,h,g,f,e,d,a0,a1,a2,a3,a4,a5,a6,a7,a8,a9,b0,b1,b2,b3,b4,b5,b6,b7,b8,b9,c0,c1,c2=this,c3=null,c4={}
if(c2.e){c2.e=!1
c2.aF2()}x=A.t(c5)
w=c4.a=B.e3l(c5)
v=x.ax
u=v.b
c4.b=null
t=c3
s=!1
r=1
q=c3
switch(c2.a.k2.a){case 0:t=new B.Xe(c5,A.t(c5).ax)
p=B.e4N(c5)
c4.b=p
o=p
q=w
break
case 1:n=x.c2n(y.c)
o=c4.a=(n==null?D.NQ:n).cqw(x,w)
switch(x.w.a){case 0:case 1:case 3:case 5:t=new B.Xe(c5,A.t(c5).ax)
p=B.e4N(c5)
c4.b=p
q=p
break
case 2:case 4:c2.f=!0
q=c2.a.k1
if(q==null)q=c3
s=q===!0
t=new B.dwJ(c5,A.t(c5).ax)
p=new B.bbF(c5,c3,c3,c3,c3,c3,c3,c3,c3,c3,c3)
c4.b=p
q=c2.ow$
q===$&&A.e()
q.e=C.am
q=p
r=0.5
break}m=o
o=q
q=m
break
default:o=q
q=w}l=c2.ns$
l===$&&A.e()
l.e=A.dN(0,0,0,t.gcza(),0)
k=c2.giw()
k.H(0,C.an)
j=c2.giw()
j.M(0,C.an)
c2.a.toString
i=c2.gawy().a.$1(k)
if(i==null){l=q.a
i=l==null?c3:l.al(k)}l=i==null
if(l){h=o.gnL().al(k)
h.toString
g=h}else g=i
c2.a.toString
f=c2.gawy().a.$1(j)
if(f==null){h=q.a
f=h==null?c3:h.al(j)}h=f==null
if(h){e=o.gnL().al(j)
e.toString
d=e}else d=f
c2.a.toString
e=c2.gcqa().a.$1(k)
if(e==null)if(s)e=u
else{e=q.b
e=e==null?c3:e.al(k)}if(e==null){e=c2.gawy().a.$1(k)
e=e==null?c3:e.hv(128)
a0=e}else a0=e
if(a0==null){e=o.gzt().a.$1(k)
e.toString
a0=e}c2.a.toString
e=q.c
a1=e==null?c3:e.al(k)
a2=a1
if(a2==null)a2=o.gTA().al(k)
c2.a.toString
a1=q.d
a3=a1==null?c3:a1.al(k)
a4=a3
if(a4==null){a3=o.gaaX()
a4=a3==null?c3:a3.al(k)}c2.a.toString
a3=c2.gcqa().a.$1(j)
if(a3==null){a3=q.b
a3=a3==null?c3:a3.al(j)
a5=a3}else a5=a3
if(a5==null){a3=o.gzt().a.$1(j)
a3.toString
a5=a3}c2.a.toString
e=e==null?c3:e.al(j)
a6=e
if(a6==null)a6=o.gTA().al(j)
c2.a.toString
e=a1==null?c3:a1.al(j)
a7=e
if(a7==null){e=o.gaaX()
a7=e==null?c3:e.al(j)}c2.a.toString
a8=t.gfl().al(k)
a9=t.gfl().al(j)
b0=c2.giw()
b0.H(0,C.ax)
c2.a.toString
e=q.r
a1=e==null?c3:e.al(b0)
if(a1==null){if(s){a1=A.aHq(u.bj(0.8))
a1=new A.Ds(a1.a,a1.b,0.835,0.69).beb()}else a1=c3
b1=a1}else b1=a1
if(b1==null){a1=o.geg().a.$1(b0)
a1.toString
b1=a1}b2=c2.giw()
b2.H(0,C.az)
c2.a.toString
a1=e==null?c3:e.al(b2)
b3=a1
if(b3==null){a1=o.geg().a.$1(b2)
a1.toString
b3=a1}k.H(0,C.aG)
c2.a.toString
a1=c2.gawy().a.$1(k)
if(a1==null){a1=q.a
a1=a1==null?c3:a1.al(k)
b4=a1}else b4=a1
if(b4==null){a1=o.gnL().al(k)
a1.toString
b4=a1}c2.a.toString
a1=e==null?c3:e.al(k)
if(a1==null){l=l?c3:i.hv(31)
b5=l}else b5=a1
if(b5==null){l=o.geg().a.$1(k)
l.toString
b5=l}j.H(0,C.aG)
c2.a.toString
l=c2.gawy().a.$1(j)
if(l==null){q=q.a
q=q==null?c3:q.al(j)
b6=q}else b6=l
if(b6==null){q=o.gnL().al(j)
q.toString
b6=q}c2.a.toString
q=e==null?c3:e.al(j)
if(q==null){q=h?c3:f.hv(31)
b7=q}else b7=q
if(b7==null){q=o.geg().a.$1(j)
q.toString
b7=q}b8=t.gbzI()
c2.a.toString
b9=t.gbCG()
c2.a.toString
c0=c4.a.w
if(c0==null)c0=c4.b.gnS()
q=c2.a
o=q.c
l=q.cx
h=(q.d!=null?c2.gcmZ():c3)==null?r:1
e=q.fx
a1=q.fy
q=q.id
a3=c2.d
c1=c2.l8$
c1===$&&A.e()
a3.sbD(c1)
c1=c2.ox$
c1===$&&A.e()
a3.sbaL(c1)
c1=c2.qs$
c1===$&&A.e()
a3.sc_I(c1)
c1=c2.qr$
c1===$&&A.e()
a3.sc_J(c1)
a3.sbY0(b7)
a3.sc_H(b5)
a3.sCd(b3)
a3.swp(b1)
a3.snS(c0)
a3.saUt(c2.t_$)
a3.swv(c2.giw().t(0,C.ax))
a3.sbCU(c2.giw().t(0,C.az))
a3.sawZ(g)
a3.saXR(d)
a3.sdMZ(b4)
a3.se00(b6)
a3.sdN_(c2.a.x)
a3.se4j(c2.a.y)
a3.se01(c2.a.z)
a3.se4S(c2.a.Q)
a3.sB6(a0)
a3.sdN0(a2)
a3.sdN1(a4)
a3.sCg(a5)
a3.se02(a6)
a3.se03(a7)
a3.sys(A.Xz(c5,c3))
a3.st8(c2.gmt()!=null)
a3.seb_(c2.gcnR())
a3.sdU(c5.a9(y.I).w)
a3.scQv(v.k2)
a3.sbCG(b9)
a3.sbzI(b8)
a3.sbEl(t.gbEl())
a3.sbFf(t.gbFf())
a3.saaW(t.gaaW())
a3.saaY(t.gaaY())
a3.sdMY(a8)
a3.se0_(a9)
a3.sdMX(c3)
a3.se_Z(c3)
a3.si2(A.a_H(c5))
a3.sbFg(t.gbFg())
a3.sbFo(t.gbFo())
a3.se6C(c2.ns$)
a3.se0S(c2.f)
return A.Q(c3,c3,c3,A.ie(c3,A.Kd(c2.crG(!1,e,new A.bX(new B.cZV(c4,c2),y.F),a1,a3,q),h),l,!0,c3,c3,c3,c3,c2.gdGB(),c2.gdGD(),c2.gdGF(),c3,c3,c3,c3,c3,c3,c3,c3,c3,c3,c3,c3,c3,c3,c3,c3,c3,c3,c3,!1,C.cc),!1,c3,c3,c3,!1,c3,!1,c3,c3,c3,c3,c3,c3,c3,c3,c3,c3,c3,c3,c3,c3,c3,c3,c3,c3,c3,c3,c3,c3,c3,c3,c3,c3,c3,c3,c3,c3,c3,c3,c3,c3,c3,c3,c3,c3,c3,o,c3,c3,C.p,c3)}}
B.auJ.prototype={
se6C(d){var x,w=this
if(d===w.dx)return
w.dx=d
x=w.dy
if(x!=null)x.q()
x=w.dx
x.toString
w.dy=A.dt(C.el,x,C.e2)
w.S()},
sdMX(d){return},
se_Z(d){return},
si2(d){if(d.p(0,this.fy))return
this.fy=d
this.S()},
sdMY(d){if(d.p(0,this.go))return
this.go=d
this.S()},
se0_(d){if(d.p(0,this.id))return
this.id=d
this.S()},
sdMZ(d){if(d.p(0,this.k1))return
this.k1=d
this.S()},
se00(d){if(d.p(0,this.k2))return
this.k2=d
this.S()},
sbzI(d){if(d===this.k3)return
this.k3=d
this.S()},
sbCG(d){if(d===this.k4)return
this.k4=d
this.S()},
sbEl(d){if(d===this.ok)return
this.ok=d
this.S()},
sbFf(d){if(d==this.p1)return
this.p1=d
this.S()},
sbFo(d){if(d.p(0,this.p2))return
this.p2=d
this.S()},
saaW(d){if(d===this.p3)return
this.p3=d
this.S()},
saaY(d){if(d===this.p4)return
this.p4=d
this.S()},
sdN_(d){return},
se4j(d){return},
se01(d){return},
se4S(d){return},
sB6(d){if(d.p(0,this.to))return
this.to=d
this.S()},
sdN0(d){if(J.p(d,this.x1))return
this.x1=d
this.S()},
se02(d){if(J.p(d,this.x2))return
this.x2=d
this.S()},
sdN1(d){if(d==this.xr)return
this.xr=d
this.S()},
se03(d){if(d==this.y1)return
this.y1=d
this.S()},
sCg(d){if(d.p(0,this.y2))return
this.y2=d
this.S()},
sys(d){if(d.p(0,this.b3))return
this.b3=d
this.S()},
sdU(d){if(this.br===d)return
this.br=d
this.S()},
scQv(d){if(d.p(0,this.E))return
this.E=d
this.S()},
st8(d){if(d===this.aa)return
this.aa=d
this.S()},
seb_(d){if(d===this.ae)return
this.ae=d
this.S()},
se0S(d){if(d===this.aq)return
this.aq=d
this.S()},
sbFg(d){var x=this.am
if(d==null?x==null:d===x)return
this.am=d
this.S()},
dcP(){if(!this.b5)this.S()},
bb(b2,b3){var x,w,v,u,t,s,r,q,p,o,n,m,l,k,j,i,h,g,f,e,d,a0,a1,a2,a3,a4,a5,a6,a7,a8,a9,b0=this,b1=b0.a.gC()
switch(b0.br.a){case 0:x=1-b1
break
case 1:x=b1
break
default:x=null}w=b0.b.a.gbh()===C.dD&&!b0.dM
if(w)b0.dM=!0
else b0.dM=!1
if(!w){w=b0.aq
w.toString
b0.dv=w?b0.b.gC()*7:0
w=b0.b
if(w.gbh()===C.bz){v=b0.k4
v.toString
u=b0.ok
u.toString
b0.e2=A.b_(v,u,w.gC())
w=b0.k3
w.toString
u=b0.ok
u.toString
b0.cj=A.b_(w,u,b0.b.gC())}if(b1===0){w=b0.k4
w.toString
v=b0.ok
v.toString
b0.e2=A.b_(w,v,b0.b.gC())
v=b0.k3
v.toString
b0.cj=v}if(b1===1){w=b0.k3
w.toString
v=b0.ok
v.toString
b0.cj=A.b_(w,v,b0.b.gC())
v=b0.k4
v.toString
b0.e2=v}}w=b0.aq
w.toString
v=b0.e2
if(w){v.toString
u=v*2
t=b0.dv
t===$&&A.e()
s=new A.ae(u+t,u)}else{if(v==null){u=b0.k4
u.toString}else u=v
u*=2
s=new A.ae(u,u)}u=b0.cj
if(w){u.toString
u*=2
t=b0.dv
t===$&&A.e()
r=new A.ae(u+t,u)}else{if(u==null){u=b0.k3
u.toString}u*=2
r=new A.ae(u,u)}u=new B.dwU(b0,s,r)
if(w)if(b0.b.gbh()===C.bz){v.toString
w=v*2
v=b0.dv
v===$&&A.e()
q=new A.ae(w+v,w)}else{w=b0.a
w=w.gbh()===C.b4||w.a.gbh()===C.dL
v=b0.a
q=w?A.aiv(s,r,v.gC()):A.aiv(s,r,v.gC())}else if(b0.b.gbh()===C.bz){w=b0.ok
w.toString
w*=2
q=new A.ae(w,w)}else{w=b0.a
if(w.gbh()===C.b4||w.a.gbh()===C.dL){w=u.$1(!0)
q=w.b.aN(w.a.gC())}else{w=u.$1(!1)
q=w.b.aN(w.a.gC())}}w=b0.p1
p=w==null?0:1-Math.abs(b1-w)*2
w=q.a-p
v=q.b-p
o=b0.dy.gC()
u=b0.y2
u.toString
t=b0.to
t.toString
t=A.aD(u,t,o)
t.toString
u=b0.x2
n=u==null||b0.x1==null?null:A.aD(u,b0.x1,o)
m=A.b_(b0.y1,b0.xr,o)
if(b0.b.gbh()!==C.b4){u=b0.k2
u.toString
l=b0.k1
l.toString
l=A.aD(u,l,o)
l.toString
k=l}else{u=b0.dx.Q
u===$&&A.e()
if(u===C.dL){u=b0.k2
u.toString
l=b0.e
l.toString
l=A.aD(u,l,o)
l.toString
k=l}else{l=b0.f
if(u===C.dD){l.toString
u=b0.k1
u.toString
u=A.aD(l,u,o)
u.toString
k=u}else{l.toString
u=b0.e
u.toString
u=A.aD(l,u,o)
u.toString
k=u}}}u=b0.E
u.toString
j=A.wF(k,u)
u=b1<0.5
i=u?b0.fx:b0.fr
h=u?b0.rx:b0.R8
g=u?b0.ry:b0.RG
$.b3()
f=A.bF()
f.r=t.gC()
u=b0.p4
u.toString
t=b0.p3
t.toString
e=(b3.a-u)/2
l=b3.b
d=(l-t)/2
a0=t/2
a1=v/2
a2=b0.ae
a2.toString
a3=b0.dv
a3===$&&A.e()
a4=e+a0+a3/2-w/2+x*(a2-a3)
a5=A.u0(new A.ao(e,d,e+u,d+t),new A.c1(a0,a0))
b2.hm(a5,f)
if(n!=null){x=e+1
u=d+1
t=b0.p4
t.toString
a2=b0.p3
a2.toString
a6=A.u0(new A.ao(x,u,x+(t-2),u+(a2-2)),new A.c1(a0,a0))
a7=A.bF()
a7.b=C.bR
a7.c=m==null?2:m
a7.r=n.gC()
b2.hm(a6,a7)}x=b0.aq
x.toString
if(x){x=b0.as
x.toString
if(x){a8=a5.h1(1.75)
a9=A.bF()
a9.b=C.bR
a9.r=b0.y.gC()
a9.c=3.5
b2.hm(a8,a9)}b2.a.clipRRect(A.wn(a5),$.GU(),!0)}b0.c_e(b2,new A.M(a4+a1,l/2))
b0.dsZ(new A.M(a4,d-(a1-a0)),b2,o,j,h,g,i,new A.ae(w,v),p)},
dsZ(d,e,f,g,h,i,j,k,l){var x,w,v=this
try{v.b5=!0
if(v.b4!=null){w=g.p(0,v.aE)
w=!w}else w=!0
if(w){v.aE=g
v.aY=h
v.bn=i
w=v.b4
if(w!=null)w.q()
w=v.aq
w.toString
v.b4=A.eRd(new A.mz(g,null,null,w?null:v.am,C.qw),v.gdcO())}w=v.b4
w.toString
x=w
w=v.aq
w.toString
if(w)v.dsT(e,d,k)
x.kC(e,d,v.b3.a4d(k))}finally{v.b5=!1}},
dsT(d,e,f){var x,w,v,u,t,s=e.a,r=e.b,q=f.b,p=q/2,o=A.aP9(s,r,s+f.a,r+q,new A.c1(p,p))
s=this.am
if(s!=null)for(r=s.length,q=d.a,x=0;x<r;++x){w=s[x]
p=o.hE(w.b)
$.b3()
v=new A.qy(C.dM,C.ch,C.h0,C.hx,C.fC)
v.r=w.a.gC()
u=w.c
u=u>0?u*0.57735+0.5:0
v.z=new A.RK(w.e,u)
t=v.i4()
q.drawRRect(A.wn(p),t)
t.delete()}s=o.h1(0.5)
$.b3()
r=A.bF()
r.r=C.aym.gC()
d.hm(s,r)},
q(){var x,w=this
w.aL.q()
x=w.b4
if(x!=null)x.q()
w.bn=w.aY=w.aE=w.b4=null
x=w.dy
if(x!=null)x.q()
w.cML()}}
B.bbI.prototype={
cqw(d,e){switch(d.w.a){case 0:case 1:case 3:case 5:return e
case 2:case 4:return C.aem}}}
B.bbE.prototype={}
B.bbF.prototype={
gjP(){return new A.bX(new B.dwM(),y.o)},
gnL(){return D.c8s},
gzt(){return new A.bX(new B.dwO(this),y.k)},
gTA(){return C.dZ},
geg(){return new A.bX(new B.dwN(this),y.b)},
gnS(){return 0}}
B.dwJ.prototype={
gfl(){return new A.bX(new B.dwK(this),y.k)},
gbzI(){return 14},
gbCG(){return 14},
gbEl(){return 14},
gbFg(){return D.bfl},
gaaW(){return 31},
gaaY(){return 51},
gbFo(){return D.bI4},
gcza(){return 140},
gbFf(){return null}}
B.bbG.prototype={
gj4(){var x,w=this,v=w.Q
if(v===$){x=A.t(w.z)
w.Q!==$&&A.bf()
v=w.Q=x.ax}return v},
gnL(){return new A.bX(new B.dwR(this),y.k)},
gzt(){return new A.bX(new B.dwS(this),y.k)},
gTA(){return new A.bX(new B.dwT(this),y.b)},
geg(){return new A.bX(new B.dwQ(this),y.b)},
gjP(){return new A.bX(new B.dwP(),y.F)},
gaaX(){return D.c8q},
gnS(){return 20},
geb(){return C.fb}}
B.Xe.prototype={
gbzI(){return 12},
gfl(){return new A.bX(new B.dwL(this),y.k)},
gbCG(){return 8},
gbEl(){return 14},
gcQx(){return 48},
gcQy(){return 40},
gc5w(){return 52},
gbFg(){return C.GE},
gaaW(){return 32},
gaaY(){return 52},
gbFo(){return D.bI8},
gcza(){return 300},
gbFf(){return null}}
B.ax3.prototype={
cd(){this.dg()
this.dl()
this.fR()},
q(){var x=this,w=x.dy$
if(w!=null)w.T(x.gfM())
x.dy$=null
x.a5()}}
B.ax4.prototype={
X(){var x,w=this,v=null
w.a6()
x=A.cL(v,C.am,v,1,!w.a.c?0:1,w)
w.ns$=x
w.l8$=A.dt(C.e2,x,C.el)
x=A.cL(v,w.PQ$,v,1,v,w)
w.ow$=x
w.ox$=A.dt(C.bd,x,v)
x=A.cL(v,C.io,v,1,w.qu$||w.qt$?1:0,w)
w.uw$=x
w.qr$=A.dt(C.bd,x,v)
x=A.cL(v,C.io,v,1,w.qu$||w.qt$?1:0,w)
w.ux$=x
w.qs$=A.dt(C.bd,x,v)},
q(){var x=this,w=x.ns$
w===$&&A.e()
w.q()
w=x.l8$
w===$&&A.e()
w.q()
w=x.ow$
w===$&&A.e()
w.q()
w=x.ox$
w===$&&A.e()
w.q()
w=x.uw$
w===$&&A.e()
w.q()
w=x.qr$
w===$&&A.e()
w.q()
w=x.ux$
w===$&&A.e()
w.q()
w=x.qs$
w===$&&A.e()
w.q()
x.cPg()}}
B.bft.prototype={}
B.bfu.prototype={}
B.C5.prototype={
gjd(){return A.dV(A.D(this).k("C5.T"))}}
var z=a.updateTypes(["~()","~(o8)","~(zC)","~(mh)","~(F?)"])
B.cZT.prototype={
$1(d){if(d.t(0,C.al))return this.a.a.r
if(d.t(0,C.an))return this.a.a.e
return this.a.a.r},
$S:29}
B.cZU.prototype={
$1(d){if(d.t(0,C.an))return this.a.a.f
return this.a.a.w},
$S:29}
B.cZS.prototype={
$0(){this.a.e=!0},
$S:0}
B.cZV.prototype={
$1(d){var x=A.dJ(this.b.a.cy,d,y.Q)
if(x==null)x=null
if(x==null){x=this.a.b.gjP().a.$1(d)
x.toString}return x},
$S:87}
B.dwU.prototype={
$1(d){var x,w=this.b,v=this.a,u=this.c,t=y.h,s=y.e,r=y.W,q=y.M,p=v.p2,o=s.k("h3<by.T>")
if(d){p.toString
x=A.a([new A.oq(new A.h3(new A.i1(D.Pd),new A.bn(w,p,s),o),11,r),new A.oq(new A.h3(new A.i1(C.De),new A.bn(p,u,s),o),72,r),new A.oq(new A.Zp(u,u,q),17,r)],t)}else{p.toString
x=A.a([new A.oq(new A.Zp(w,w,q),17,r),new A.oq(new A.h3(new A.i1(new A.tx(C.De)),new A.bn(w,p,s),o),72,r),new A.oq(new A.h3(new A.i1(new A.tx(D.Pd)),new A.bn(p,u,s),o),11,r)],t)}w=A.e3N(x,y.Y)
v=v.dx
v.toString
return new A.bm(v,w,w.$ti.k("bm<by.T>"))},
$S:1953}
B.dwM.prototype={
$1(d){if(d.t(0,C.al))return C.hy
return C.ms},
$S:1954}
B.dwO.prototype={
$1(d){var x
if(d.t(0,C.an)){x=D.Ph.fw(this.a.z)
return x}x=D.aDK.fw(this.a.z)
return x},
$S:14}
B.dwN.prototype={
$1(d){var x
if(d.t(0,C.ax)){x=D.Ph.fw(this.a.z)
x=A.aHq(x.bj(0.8))
return new A.Ds(x.a,x.b,0.835,0.69).beb()}return C.a4},
$S:14}
B.dwK.prototype={
$1(d){var x,w
if(d.t(0,C.al)){x=this.a.b.k3
return A.bj(97,x.K()>>>16&255,x.K()>>>8&255,x.K()&255)}x=this.a.b
w=x.e
return w==null?x.c:w},
$S:14}
B.dwR.prototype={
$1(d){var x,w,v=this
if(d.t(0,C.al)){if(d.t(0,C.an)){x=v.a.gj4().k2
return A.bj(255,x.K()>>>16&255,x.K()>>>8&255,x.K()&255)}x=v.a.gj4().k3
return A.bj(97,x.K()>>>16&255,x.K()>>>8&255,x.K()&255)}if(d.t(0,C.an)){if(d.t(0,C.aG)){x=v.a.gj4()
w=x.d
return w==null?x.b:w}if(d.t(0,C.az)){x=v.a.gj4()
w=x.d
return w==null?x.b:w}if(d.t(0,C.ax)){x=v.a.gj4()
w=x.d
return w==null?x.b:w}return v.a.gj4().c}if(d.t(0,C.aG)){x=v.a.gj4()
w=x.rx
return w==null?x.k3:w}if(d.t(0,C.az)){x=v.a.gj4()
w=x.rx
return w==null?x.k3:w}if(d.t(0,C.ax)){x=v.a.gj4()
w=x.rx
return w==null?x.k3:w}x=v.a.gj4()
w=x.ry
if(w==null){w=x.E
x=w==null?x.k3:w}else x=w
return x},
$S:14}
B.dwS.prototype={
$1(d){var x,w,v=this
if(d.t(0,C.al)){if(d.t(0,C.an)){x=v.a.gj4().k3
return A.bj(31,x.K()>>>16&255,x.K()>>>8&255,x.K()&255)}x=v.a.gj4()
w=x.RG
x=w==null?x.k2:w
return A.bj(31,x.K()>>>16&255,x.K()>>>8&255,x.K()&255)}if(d.t(0,C.an)){if(d.t(0,C.aG))return v.a.gj4().b
if(d.t(0,C.az))return v.a.gj4().b
if(d.t(0,C.ax))return v.a.gj4().b
return v.a.gj4().b}if(d.t(0,C.aG)){x=v.a.gj4()
w=x.RG
return w==null?x.k2:w}if(d.t(0,C.az)){x=v.a.gj4()
w=x.RG
return w==null?x.k2:w}if(d.t(0,C.ax)){x=v.a.gj4()
w=x.RG
return w==null?x.k2:w}x=v.a.gj4()
w=x.RG
return w==null?x.k2:w},
$S:14}
B.dwT.prototype={
$1(d){var x,w
if(d.t(0,C.an))return C.a4
if(d.t(0,C.al)){x=this.a.gj4().k3
return A.bj(31,x.K()>>>16&255,x.K()>>>8&255,x.K()&255)}x=this.a.gj4()
w=x.ry
if(w==null){w=x.E
x=w==null?x.k3:w}else x=w
return x},
$S:14}
B.dwQ.prototype={
$1(d){var x,w=this
if(d.t(0,C.an)){if(d.t(0,C.aG))return w.a.gj4().b.bj(0.1)
if(d.t(0,C.az))return w.a.gj4().b.bj(0.08)
if(d.t(0,C.ax))return w.a.gj4().b.bj(0.1)
return null}if(d.t(0,C.aG)){x=w.a.gj4().k3
return A.bj(C.k.b0(25.5),x.K()>>>16&255,x.K()>>>8&255,x.K()&255)}if(d.t(0,C.az)){x=w.a.gj4().k3
return A.bj(20,x.K()>>>16&255,x.K()>>>8&255,x.K()&255)}if(d.t(0,C.ax)){x=w.a.gj4().k3
return A.bj(C.k.b0(25.5),x.K()>>>16&255,x.K()>>>8&255,x.K()&255)}return null},
$S:29}
B.dwP.prototype={
$1(d){return A.cnt(d)},
$S:87}
B.dwL.prototype={
$1(d){var x,w,v=this
if(d.t(0,C.al)){if(d.t(0,C.an)){x=v.a.b.k3
return A.bj(97,x.K()>>>16&255,x.K()>>>8&255,x.K()&255)}x=v.a.b
w=x.RG
x=w==null?x.k2:w
return A.bj(97,x.K()>>>16&255,x.K()>>>8&255,x.K()&255)}if(d.t(0,C.an)){if(d.t(0,C.aG)){x=v.a.b
w=x.e
return w==null?x.c:w}if(d.t(0,C.az)){x=v.a.b
w=x.e
return w==null?x.c:w}if(d.t(0,C.ax)){x=v.a.b
w=x.e
return w==null?x.c:w}x=v.a.b
w=x.e
return w==null?x.c:w}if(d.t(0,C.aG)){x=v.a.b
w=x.RG
return w==null?x.k2:w}if(d.t(0,C.az)){x=v.a.b
w=x.RG
return w==null?x.k2:w}if(d.t(0,C.ax)){x=v.a.b
w=x.RG
return w==null?x.k2:w}x=v.a.b
w=x.RG
return w==null?x.k2:w},
$S:14};(function aliases(){var x=B.ax3.prototype
x.cPg=x.q
x=B.ax4.prototype
x.cPh=x.q})();(function installTearOffs(){var x=a._instance_1u,w=a._instance_0u
var v
x(v=B.aqh.prototype,"gdGD","dGE",1)
x(v,"gdGF","dGG",2)
x(v,"gdGB","dGC",3)
x(v,"gcmZ","dGA",4)
w(v=B.auJ.prototype,"gdcO","dcP",0)
w(v,"gdD","q",0)})();(function inheritance(){var x=a.mixinHard,w=a.mixin,v=a.inherit,u=a.inheritMany
v(B.bbK,A.eB)
v(B.ajn,A.x)
v(B.a5x,A.L)
v(B.ax3,A.S)
v(B.ax4,B.ax3)
v(B.aqh,B.ax4)
u(A.bu,[B.cZT,B.cZU,B.cZV,B.dwU,B.dwM,B.dwO,B.dwN,B.dwK,B.dwR,B.dwS,B.dwT,B.dwQ,B.dwP,B.dwL])
v(B.cZS,A.bt)
v(B.auJ,A.UZ)
u(A.A,[B.C5,B.bbE,B.bft,B.bfu])
v(B.bbI,B.C5)
u(A.y5,[B.bbF,B.bbG])
v(B.dwJ,B.bft)
v(B.Xe,B.bfu)
x(B.ax3,A.ft)
x(B.ax4,A.op)
w(B.bft,B.bbE)
w(B.bfu,B.bbE)})()
A.b0(b.typeUniverse,JSON.parse('{"a5x":{"L":[],"m":[]},"ajn":{"x":[],"m":[]},"aqh":{"op":["a5x"],"S":["a5x"]},"auJ":{"b2":[]},"bbI":{"C5":["y5"],"C5.T":"y5"},"bbF":{"y5":[]},"bbG":{"y5":[]},"eMc":{"ct":[],"ch":[],"m":[]}}'))
var y=(function rtii(){var x=A.C
return{M:x("Zp<ae>"),I:x("lj"),h:x("v<oq<ae>>"),Y:x("ae"),y:x("eMc"),c:x("y5"),W:x("oq<ae>"),e:x("bn<ae>"),k:x("bX<a3>"),F:x("bX<hX>"),b:x("bX<a3?>"),o:x("bX<hX?>"),Q:x("hX?")}})();(function constants(){var x=a.makeConstList
D.NQ=new B.bbI()
D.Pd=new A.jp(0.31,0,0.56,1)
D.CR=new A.a3(1,0.20392156862745098,0.7803921568627451,0.34901960784313724,C.A)
D.Om=new A.a3(1,0.18823529411764706,0.8196078431372549,0.34509803921568627,C.A)
D.OB=new A.a3(1,0.1411764705882353,0.5411764705882353,0.23921568627450981,C.A)
D.Oj=new A.a3(1,0.18823529411764706,0.8588235294117647,0.3568627450980392,C.A)
D.Ph=new A.h_(D.CR,"systemGreen",null,D.CR,D.Om,D.OB,D.Oj,D.CR,D.Om,D.OB,D.Oj)
D.CJ=new A.a3(0.1568627450980392,0.47058823529411764,0.47058823529411764,0.5019607843137255,C.A)
D.OW=new A.a3(0.3176470588235294,0.47058823529411764,0.47058823529411764,0.5019607843137255,C.A)
D.OO=new A.a3(0.23921568627450981,0.47058823529411764,0.47058823529411764,0.5019607843137255,C.A)
D.Ol=new A.a3(0.4,0.47058823529411764,0.47058823529411764,0.5019607843137255,C.A)
D.aDK=new A.h_(D.CJ,"secondarySystemFill",null,D.CJ,D.OW,D.OO,D.Ol,D.CJ,D.OW,D.OO,D.Ol)
D.awz=new A.a3(0.14901960784313725,0,0,0,C.A)
D.anb=new A.cq(0,C.aN,D.awz,C.m4,8)
D.azx=new A.a3(0.058823529411764705,0,0,0,C.A)
D.ank=new A.cq(0,C.aN,D.azx,C.m4,1)
D.bfl=x([D.anb,D.ank],A.C("v<cq>"))
D.bI4=new A.ae(28,28)
D.bI8=new A.ae(34,22)
D.c8q=new A.cw(2,A.C("cw<a4>"))
D.c8s=new A.cw(C.M,A.C("cw<a3>"))
D.cfF=new B.bbK(0,"material")
D.ai_=new B.bbK(1,"adaptive")})()};
(a=>{a["zx55Itqrhy3sYnKkDM0eba8GtGw="]=a.current})($__dart_deferred_initializers__);