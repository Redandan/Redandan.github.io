((a,b)=>{a[b]=a[b]||{}})(self,"$__dart_deferred_initializers__")
$__dart_deferred_initializers__.current=function(a,b,c,$){var A,B
A=c[0]
B=c[567]
var z=a.updateTypes([]);(function constants(){B.rj=new A.az(0,1180,0,1/0)})()};
(a=>{a["msliqaEPhBpbxj/rF/PGfCRGbX8="]=a.current})($__dart_deferred_initializers__);