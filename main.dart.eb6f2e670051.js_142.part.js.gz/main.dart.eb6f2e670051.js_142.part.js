((a,b)=>{a[b]=a[b]||{}})(self,"$__dart_deferred_initializers__")
$__dart_deferred_initializers__.current=function(a,b,c,$){var A,B
A=c[0]
B=c[351]
var z=a.updateTypes([]);(function constants(){B.t6=new A.ar(16,0,16,16)})()};
(a=>{a["kBTepcGNdnxFtzQo/1x8bhLKcaM="]=a.current})($__dart_deferred_initializers__);