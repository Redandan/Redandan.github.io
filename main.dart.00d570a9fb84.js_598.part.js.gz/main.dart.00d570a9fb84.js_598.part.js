((a,b)=>{a[b]=a[b]||{}})(self,"$__dart_deferred_initializers__")
$__dart_deferred_initializers__.current=function(a,b,c,$){var A,B,C
A=c[0]
B=c[2]
C=c[491]
var z=a.updateTypes([]);(function constants(){C.tK=new A.at(B.kw,null,null,null,null)})()};
(a=>{a["iNgVD8anOwu5Tez36bMdhWEZuMI="]=a.current})($__dart_deferred_initializers__);