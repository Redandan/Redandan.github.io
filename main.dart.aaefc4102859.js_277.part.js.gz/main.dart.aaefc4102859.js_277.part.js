((a,b)=>{a[b]=a[b]||{}})(self,"$__dart_deferred_initializers__")
$__dart_deferred_initializers__.current=function(a,b,c,$){var A,B
A=c[0]
B=c[703]
var z=a.updateTypes([]);(function constants(){B.D8=new A.ar(0,0,120,0)})()};
(a=>{a["jk1ICs2NTp08R3Lki20bH/7LPMk="]=a.current})($__dart_deferred_initializers__);