((a,b)=>{a[b]=a[b]||{}})(self,"$__dart_deferred_initializers__")
$__dart_deferred_initializers__.current=function(a,b,c,$){var J,A,C,K,L,H,B={
ecN(){var x,w,v=$.pA(),u=J.fg(16,y.S)
for(x=0;x<16;++x)u[x]=v.mY(256)
u[6]=u[6]&15|64
u[8]=u[8]&63|128
w=new A.E(u,new B.bDu(),A.V(u).k("E<1,n>")).kU(0)
return C.b.ai(w,0,8)+"-"+C.b.ai(w,8,12)+"-"+C.b.ai(w,12,16)+"-"+C.b.ai(w,16,20)+"-"+C.b.bv(w,20)},
bDu:function bDu(){},
dTO(d){var x=d==null?null:d.toUpperCase()
if(x==null)x=""
if(x.length===0)return null
if(C.b.t(x,"TELEGRAM_ACCOUNT_NOT_LINKED"))return D.td
if(C.b.t(x,"INSUFFICIENT_BALANCE"))return D.te
if(C.b.t(x,"WALLET_NOT_ACTIVE"))return D.tf
if(C.b.t(x,"REFUND_PENDING")||C.b.t(x,"PENDING_REFUND"))return D.tg
if(C.b.t(x,"ACCESS_EXPIRED"))return D.th
if(C.b.t(x,"ACCESS_REQUIRED")||C.b.t(x,"ENTITLEMENT_NOT_FOUND"))return D.xs
if(C.b.t(x,"GAME_NOT_AVAILABLE"))return D.hb
return null},
e6e(d,e,f){var x=e==null?null:C.b.F(e),w=x==null||x.length===0?"current":x
return"game_access_"+d.b+"_attempt_"+w+"_"+f},
pR:function pR(d,e){this.a=d
this.b=e},
Dn:function Dn(d,e){this.a=d
this.b=e},
aH_:function aH_(d,e){this.a=d
this.b=e},
bDd:function bDd(d,e,f,g,h,i,j){var _=this
_.a=d
_.b=e
_.c=f
_.d=g
_.e=h
_.f=i
_.r=j},
NC:function NC(d,e){this.a=d
this.b=e},
aig:function aig(d,e,f,g,h,i){var _=this
_.c=d
_.d=e
_.e=f
_.f=g
_.r=h
_.a=i},
atK:function atK(){var _=this
_.d=$
_.Q=_.z=_.y=_.x=_.w=_.r=_.f=_.e=null
_.at=_.as=!1
_.ax=!0
_.ay=0
_.c=_.a=_.CW=_.ch=null},
dq_:function dq_(d){this.a=d},
dq0:function dq0(d){this.a=d},
dpS:function dpS(d,e){this.a=d
this.b=e},
dpI:function dpI(d){this.a=d},
dpZ:function dpZ(d,e){this.a=d
this.b=e},
dpT:function dpT(d){this.a=d},
dpU:function dpU(d,e){this.a=d
this.b=e},
dpV:function dpV(d){this.a=d},
dpP:function dpP(d){this.a=d},
dpQ:function dpQ(d){this.a=d},
dpR:function dpR(d,e,f,g){var _=this
_.a=d
_.b=e
_.c=f
_.d=g},
dpD:function dpD(d,e,f,g,h,i){var _=this
_.a=d
_.b=e
_.c=f
_.d=g
_.e=h
_.f=i},
dpB:function dpB(d){this.a=d},
dpC:function dpC(d,e,f,g){var _=this
_.a=d
_.b=e
_.c=f
_.d=g},
dpA:function dpA(d){this.a=d},
dpy:function dpy(d,e){this.a=d
this.b=e},
dpz:function dpz(d,e){this.a=d
this.b=e},
dpv:function dpv(d){this.a=d},
dpu:function dpu(d){this.a=d},
dpO:function dpO(d){this.a=d},
dpK:function dpK(d,e){this.a=d
this.b=e},
dpL:function dpL(d,e){this.a=d
this.b=e},
dpM:function dpM(d,e){this.a=d
this.b=e},
dpN:function dpN(d,e){this.a=d
this.b=e},
dpJ:function dpJ(d){this.a=d},
dpH:function dpH(d){this.a=d},
dpG:function dpG(d,e){this.a=d
this.b=e},
dpF:function dpF(d){this.a=d},
dpE:function dpE(d,e,f){this.a=d
this.b=e
this.c=f},
dpW:function dpW(d){this.a=d},
dpX:function dpX(d){this.a=d},
dpY:function dpY(d){this.a=d},
dpw:function dpw(d){this.a=d},
dpx:function dpx(d){this.a=d},
bfm:function bfm(){},
f2Z(d,e,f){var x=b.G,w=A.dR(new B.dUi(x.window.location.origin,f,e,d))
x.window.addEventListener("message",w)
return new B.dUh(w)},
f3_(d,e,f){var x,w={},v=b.G,u=v.window.location.origin
w.a=!0
x=A.dR(new B.dUl(u,new B.dUj(w,f),e,d))
v.window.addEventListener("message",x)
return new B.dUk(w,x)},
e5j(d,e){var x,w,v
if(e==null)return!0
x=b.G.document.getElementById(e)
w=!1
if(x!=null)if(A.iz(x,"HTMLIFrameElement")){w=d.source
v=x.contentWindow
v=w==null?v==null:w===v
w=v}return w},
eq7(d,e){B.dPg(A.bK(d),b.G.window.location.origin,e)},
dPg(d,e,f){var x,w,v,u,t=b.G.document.querySelectorAll("iframe")
for(x=0;x<t.length;++x){w=t.item(x)
if(w!=null){v=A.iz(w,"HTMLIFrameElement")
v=!v}else v=!0
if(v)continue
if(f!=null&&!J.p(w.id,f))continue
u=w.src
if(C.b.aR(u,e))v=!A.oF(u,"/games/",0)
else v=!0
if(v)continue
v=w.contentWindow
if(v!=null)v.postMessage(d,e)}},
dUi:function dUi(d,e,f,g){var _=this
_.a=d
_.b=e
_.c=f
_.d=g},
dUh:function dUh(d){this.a=d},
dUj:function dUj(d,e){this.a=d
this.b=e},
dUl:function dUl(d,e,f,g){var _=this
_.a=d
_.b=e
_.c=f
_.d=g},
dUm:function dUm(d,e,f,g,h,i){var _=this
_.a=d
_.b=e
_.c=f
_.d=g
_.e=h
_.f=i},
dUk:function dUk(d,e){this.a=d
this.b=e},
aiH:function aiH(d,e,f,g){var _=this
_.c=d
_.d=e
_.e=f
_.a=g},
bbc:function bbc(){var _=this
_.e=_.d=$
_.c=_.a=_.f=null},
drm:function drm(d){this.a=d},
drn:function drn(d){this.a=d},
ehU(d,e){return new B.Fa(d,e,null)},
Fa:function Fa(d,e,f){this.c=d
this.d=e
this.a=f},
au_:function au_(d,e,f,g){var _=this
_.f=_.e=_.d=null
_.r=d
_.w=e
_.x=$
_.z=_.y=null
_.Q=!1
_.as=f
_.at=null
_.ax=!1
_.ay=$
_.ch=g
_.fx=_.fr=_.dy=_.dx=_.db=_.cy=_.cx=_.CW=null
_.k1=_.id=_.go=_.fy=!1
_.k2=!0
_.k3=!1
_.c=_.a=_.p2=_.p1=_.ok=_.k4=null},
dsl:function dsl(d){this.a=d},
dsm:function dsm(d){this.a=d},
dsn:function dsn(d){this.a=d},
dso:function dso(d){this.a=d},
dsk:function dsk(d){this.a=d},
ds6:function ds6(d){this.a=d},
drG:function drG(d,e){this.a=d
this.b=e},
drH:function drH(d){this.a=d},
drq:function drq(d,e){this.a=d
this.b=e},
drI:function drI(){},
drF:function drF(d,e){this.a=d
this.b=e},
drN:function drN(d,e){this.a=d
this.b=e},
drO:function drO(d,e){this.a=d
this.b=e},
drP:function drP(d,e){this.a=d
this.b=e},
drQ:function drQ(d){this.a=d},
drs:function drs(d,e){this.a=d
this.b=e},
drt:function drt(d){this.a=d},
dru:function dru(d){this.a=d},
drv:function drv(d){this.a=d},
drw:function drw(d){this.a=d},
drx:function drx(d,e){this.a=d
this.b=e},
dry:function dry(d,e){this.a=d
this.b=e},
drz:function drz(d,e){this.a=d
this.b=e},
drA:function drA(d,e){this.a=d
this.b=e},
drB:function drB(d,e){this.a=d
this.b=e},
drC:function drC(d){this.a=d},
drY:function drY(d){this.a=d},
drZ:function drZ(d){this.a=d},
ds_:function ds_(d){this.a=d},
ds0:function ds0(d){this.a=d},
ds1:function ds1(d){this.a=d},
ds2:function ds2(d){this.a=d},
ds3:function ds3(d,e){this.a=d
this.b=e},
ds4:function ds4(d,e){this.a=d
this.b=e},
ds5:function ds5(d){this.a=d},
ds9:function ds9(d){this.a=d},
dsa:function dsa(d){this.a=d},
dsb:function dsb(d){this.a=d},
dsc:function dsc(d){this.a=d},
dsd:function dsd(d){this.a=d},
dse:function dse(d,e,f){this.a=d
this.b=e
this.c=f},
dsf:function dsf(d){this.a=d},
dsg:function dsg(d,e){this.a=d
this.b=e},
dsh:function dsh(d){this.a=d},
drR:function drR(d){this.a=d},
drS:function drS(d){this.a=d},
drT:function drT(d){this.a=d},
drU:function drU(d){this.a=d},
drV:function drV(d){this.a=d},
drW:function drW(d){this.a=d},
drX:function drX(d){this.a=d},
drJ:function drJ(d){this.a=d},
drK:function drK(){},
drD:function drD(){},
drL:function drL(d){this.a=d},
drM:function drM(){},
drE:function drE(){},
dsi:function dsi(d,e){this.a=d
this.b=e},
dsj:function dsj(d){this.a=d},
dro:function dro(d,e){this.a=d
this.b=e},
drp:function drp(d){this.a=d},
drr:function drr(d,e,f){this.a=d
this.b=e
this.c=f},
ds7:function ds7(d){this.a=d},
ds8:function ds8(d,e){this.a=d
this.b=e},
aH0:function aH0(d,e,f,g,h,i,j,k,l,m){var _=this
_.c=d
_.d=e
_.e=f
_.f=g
_.r=h
_.w=i
_.x=j
_.y=k
_.z=l
_.a=m},
bDe:function bDe(d,e,f,g){var _=this
_.a=d
_.b=e
_.c=f
_.d=g},
alJ:function alJ(d,e,f){this.c=d
this.d=e
this.a=f},
aH4:function aH4(d){this.a=d},
eLg(d){var x
if(d==null||d.length===0)return null
x=A.ehS().i(0,d)
return(x==null?null:x.e===C.iS)===!1?x:null},
Dk(d,e,f,g){var x=null
return B.eDv(d,e,f,g)},
eDv(d,e,f,a0){var x=0,w=A.l(y.N),v,u=2,t=[],s,r,q,p,o,n,m,l,k,j,i,h,g
var $async$Dk=A.h(function(a1,a2){if(a1===1){t.push(a2)
x=u}for(;;)switch(x){case 0:i=null
h=$.acv.i(0,a0)
if(h!=null&&h.length!==0){v=h
x=1
break}u=4
k=i
x=7
return A.c((k==null?A.XH():k).$0(),$async$Dk)
case 7:s=a2
r=s.a.i(0,a0)
if(typeof r=="string"&&r.length!==0){$.acv.h(0,a0,r)
v=r
x=1
break}x=r!=null?8:9
break
case 8:x=10
return A.c(J.qn(s,a0),$async$Dk)
case 10:case 9:x=e!=null&&e!==a0?11:12
break
case 11:q=s.a.i(0,e)
x=typeof q=="string"&&q.length!==0?13:14
break
case 13:$.acv.h(0,a0,q)
x=15
return A.c(s.h9("String",a0,q),$async$Dk)
case 15:p=a2
x=p?16:17
break
case 16:x=18
return A.c(J.qn(s,e),$async$Dk)
case 18:case 17:v=q
x=1
break
case 14:x=q!=null?19:20
break
case 19:x=21
return A.c(J.qn(s,e),$async$Dk)
case 21:case 20:case 12:o=d.$0()
$.acv.h(0,a0,o)
x=22
return A.c(s.h9("String",a0,o),$async$Dk)
case 22:n=a2
if(!n){k=A.aB("Game access attempt id was not persisted.")
throw A.o(k)}v=o
x=1
break
u=2
x=6
break
case 4:u=3
g=t.pop()
m=A.u(g)
l=A.aO(g)
f.$2(m,l)
v=$.acv.cT(a0,d)
x=1
break
x=6
break
case 3:x=2
break
case 6:case 1:return A.j(v,w)
case 2:return A.i(t.at(-1),w)}})
return A.k($async$Dk,w)},
acw(d,e){var x=null
return B.eDu(d,e)},
eDu(d,e){var x=0,w=A.l(y.H),v=1,u=[],t,s,r,q,p,o,n,m,l,k
var $async$acw=A.h(function(f,g){if(f===1){u.push(g)
x=v}for(;;)switch(x){case 0:m=null
l=e.eL(0)
for(p=J.aY(l);p.G();)$.acv.M(0,p.gP())
v=3
p=m
x=6
return A.c((p==null?A.XH():p).$0(),$async$acw)
case 6:t=g
p=J.aY(l)
case 7:if(!p.G()){x=8
break}s=p.gP()
o=s
t.a.M(0,o)
x=9
return A.c($.XM().M(0,"flutter."+o),$async$acw)
case 9:x=7
break
case 8:v=1
x=5
break
case 3:v=2
k=u.pop()
r=A.u(k)
q=A.aO(k)
d.$2(r,q)
x=5
break
case 2:x=1
break
case 5:return A.j(null,w)
case 1:return A.i(u.at(-1),w)}})
return A.k($async$acw,w)}},D,E,F,G,M,N,O,P,Q,R,S,I
J=c[1]
A=c[0]
C=c[2]
K=c[307]
L=c[316]
H=c[478]
B=a.updateHolder(c[157],B)
D=c[780]
E=c[185]
F=c[781]
G=c[657]
M=c[743]
N=c[617]
O=c[364]
P=c[782]
Q=c[440]
R=c[484]
S=c[455]
I=c[550]
B.pR.prototype={
W(){return"GameAccessIssue."+this.b}}
B.Dn.prototype={
W(){return"GameAccessPrimaryAction."+this.b}}
B.aH_.prototype={
W(){return"GameAccessAttemptKind."+this.b}}
B.bDd.prototype={
gqM(){var x=this
if(x.b||x.c||!x.a)return D.Rc
if(x.f)return D.aPS
switch(x.r){case D.jk:return D.aPO
case D.td:return D.aPP
case D.te:case D.tf:return D.aPQ
case D.tg:case D.hb:return D.Rc
case D.th:case D.xs:case D.EP:case D.Rb:case D.jl:case D.xr:return D.ti
case D.is:return D.ti
case null:case void 0:if(x.e)return D.ti
return x.d?D.aPR:D.ti}}}
B.NC.prototype={
W(){return"_GameProblem."+this.b}}
B.aig.prototype={
O(){return new B.atK()},
e15(){return this.f.$0()},
e4F(){return this.r.$0()}}
B.atK.prototype={
gbLW(){var x=this,w=null,v=x.CW
if(v==null)if(x.ch==null){v=x.r
v=v==null?w:v.d
if(v==null){v=x.x
if(v==null)v=w
else{v=v.b
v=v==null?w:v.f}}v=B.dTO(v)}else v=w
return v},
gcbg(){var x,w=this.ch
if(w!=null)return w
x=this.r
if(x!=null)if(x.r)w=!x.x&&!x.y
else w=!0
else w=!1
if(!w){w=this.x
if(w==null)w=null
else{w=w.b
w=w==null?null:w.f}w=w!=null}else w=!0
return w?D.Lh:null},
ghK(){var x=this
return x.c!=null&&!x.at&&x.ax&&x.a.e.gN()&&x.a.e15()},
Y(){var x,w,v=this
v.a6()
x=$.al.RG$
v.ax=x==null||x===C.cy
w=A.iL(v.a.d.a.a,new B.dq_(v))
v.d!==$&&A.aL()
v.d=new E.afM(new A.Do(w))
v.a.e.a4(v.gclz())
$.al.bs$.push(v)
$.al.y2$.push(new B.dq0(v))},
tM(){var x=this.z
if(x!=null)x.a7()
this.y=this.z=null},
bPR(){var x,w,v=this.Q
this.Q=null
x=v==null
w=x?null:v.b
if(!x&&w!=null&&v.gfe())$.al.y2$.push(new B.dpS(v,w))},
clA(){var x=this
if(x.c==null||x.at||x.a.e.gN())return;++x.ay
x.bPR()
x.n(new B.dpI(x))},
oo(d){var x=this
if(x.c==null)return;++x.ay
if(d!==C.cy)x.bPR()
x.n(new B.dpZ(x,d))
if(x.ax&&x.ghK())x.tX(x.gbwr())},
q(){var x=this;++x.ay
x.bPR()
x.tM()
x.a.e.T(x.gclz())
$.al.iU(x)
x.a5()},
cbX(d){var x
this.CW=d instanceof A.hx?B.dTO(d.b):null
if(d instanceof E.pT)x=D.ahl
else if(d instanceof E.v9)x=D.ahj
else if(d instanceof E.acy)x=D.ahk
else x=d instanceof E.Dm||d instanceof E.a_x?D.Lh:D.ahi
this.ch=x},
tX(d){return this.dzH(d)},
dzH(d){var x=0,w=A.l(y.H),v,u=2,t=[],s=[],r=this,q,p,o,n
var $async$tX=A.h(function(e,f){if(e===1){t.push(f)
x=u}for(;;)switch(x){case 0:if(r.as||!r.ghK()){x=1
break}q=++r.ay
r.n(new B.dpT(r))
u=4
x=7
return A.c(d.$1(q),$async$tX)
case 7:s.push(6)
x=5
break
case 4:u=3
n=t.pop()
p=A.u(n)
if(r.ghK()&&J.p(q,r.ay))r.n(new B.dpU(r,p))
s.push(6)
x=5
break
case 3:s=[2]
case 5:u=2
if(r.c!=null&&J.p(q,r.ay))r.n(new B.dpV(r))
x=s.pop()
break
case 6:case 1:return A.j(v,w)
case 2:return A.i(t.at(-1),w)}})
return A.k($async$tX,w)},
dC8(){return this.tX(this.gbwr())},
vP(d){return this.dw5(d)},
dw5(d){var x=0,w=A.l(y.H),v=1,u=[],t=this,s,r,q,p,o,n,m,l,k,j,i,h,g
var $async$vP=A.h(function(e,f){if(e===1){u.push(f)
x=v}for(;;)switch(x){case 0:k={}
j=k.a=t.e
k.b=t.f
x=j==null?2:4
break
case 2:v=6
p=t.d
p===$&&A.e()
g=k
x=9
return A.c(p.pV(t.a.c),$async$vP)
case 9:g.b=f
v=1
x=8
break
case 6:v=5
i=u.pop()
if(!t.ghK()||d!==t.ay)A.U(C.ao)
x=8
break
case 5:x=1
break
case 8:if(!t.ghK()||d!==t.ay)A.U(C.ao)
p=k.b
n=t.d
m=t.a
x=p==null?10:12
break
case 10:n===$&&A.e()
p=m.c
n=n.a.a
l=n.c
if(!(l instanceof A.fM))A.U(C.x)
x=13
return A.c(E.bDz(n,l.b,new B.dpP(t),p),$async$vP)
case 13:j=f
x=11
break
case 12:n===$&&A.e()
m=m.c
p=p.b
n=n.a.a
l=n.c
if(!(l instanceof A.fM))A.U(C.x)
j=E.ecL(n,l.b,p,new B.dpQ(t),null,m)
case 11:k.a=j
if(!t.ghK()||d!==t.ay)A.U(C.ao)
if(j==null)throw A.o(new E.Dm())
p=j
x=3
break
case 4:p=j
case 3:x=14
return A.c(p.e7H(),$async$vP)
case 14:s=f
if(!t.ghK()||d!==t.ay)A.U(C.ao)
x=15
return A.c(p.cy5(),$async$vP)
case 15:r=f
if(!t.ghK()||d!==t.ay)A.U(C.ao)
k.c=k.d=null
v=17
g=k
x=20
return A.c(p.ra(),$async$vP)
case 20:g.d=f
v=1
x=19
break
case 17:v=16
h=u.pop()
q=A.u(h)
if(!t.ghK()||d!==t.ay)A.U(C.ao)
if(s==null&&r==null)throw h
k.c=q
x=19
break
case 16:x=1
break
case 19:if(!t.ghK()||d!==t.ay)A.U(C.ao)
t.n(new B.dpR(k,t,s,r))
return A.j(null,w)
case 1:return A.i(u.at(-1),w)}})
return A.k($async$vP,w)},
av2(d,e,f){return this.d1t(d,e,f)},
d1t(d,e,f){var x=0,w=A.l(y.y),v,u=2,t=[],s=[],r=this,q,p,o,n,m
var $async$av2=A.h(function(g,h){if(g===1){t.push(h)
x=u}for(;;)switch(x){case 0:if(!r.ghK()||d!==r.ay)A.U(C.ao)
n=r.c
n.toString
q=A.ac(n,!0)
p=A.cC()
n=r.c
n.toString
m=y.y
p.seS(A.CU(null,null,C.bi,!0,null,new B.dpD(r,e,f,q,p,d),n,!1,null,null,null,null,!0,m))
r.Q=p.an()
u=3
x=6
return A.c(q.aM(p.an(),m),$async$av2)
case 6:o=h
if(!r.ghK()||d!==r.ay)A.U(C.ao)
n=J.p(o,!0)
v=n
s=[1]
x=4
break
s.push(5)
x=4
break
case 3:s=[2]
case 4:u=2
n=r.Q
m=p.an()
if(n==null?m==null:n===m)r.Q=null
x=s.pop()
break
case 5:case 1:return A.j(v,w)
case 2:return A.i(t.at(-1),w)}})
return A.k($async$av2,w)},
cZj(){return this.tX(new B.dpA(this))},
cRK(){return this.tX(new B.dpv(this))},
duI(){return this.tX(new B.dpO(this))},
dC6(){return this.tX(new B.dpH(this))},
dC3(){return this.tX(new B.dpF(this))},
a0q(d){return this.doB(d)},
doB(d){var x=0,w=A.l(y.H),v,u=this,t
var $async$a0q=A.h(function(e,f){if(e===1)return A.i(f,w)
for(;;)switch(x){case 0:if(!u.ghK()||u.as){x=1
break}++u.ay
u.n(u.gc9c())
t=u.c
t.toString
x=3
return A.c(A.aK(t,!1).f.aM(d,y.X),$async$a0q)
case 3:x=u.ghK()?4:5
break
case 4:x=6
return A.c(u.tX(u.gbwr()),$async$a0q)
case 6:case 5:case 1:return A.j(v,w)}})
return A.k($async$a0q,w)},
dC4(d){var x
switch(this.gbLW()){case D.td:return d.gX4()
case D.te:return d.gWV()
case D.tf:return d.gX2()
case D.tg:return d.gWY()
case D.th:return d.gWU()
case D.xs:return d.gX_()
case D.hb:return d.gKu()
default:break}x=null
switch(this.gcbg()){case D.ahl:x=d.gadf()
break
case D.ahj:x=d.gUX()
break
case D.ahk:x=d.gUW()
break
case D.Li:x=d.gad9()
break
case D.Lh:x=d.gKu()
break
case D.ahi:x=d.gWS()
break
case null:case void 0:break}return x},
u(d){var x,w,v,u,t,s,r,q,p,o,n,m,l,k,j,i=this,h=null,g=A.f(d,C.c,y.J)
g.toString
x=i.f
w=x==null?h:x.gctM()
if(w==null)w=g.gamL()
if(i.at||!i.a.e.gN()){x=A.kP(h,h,h,!0,!0,h,h,1,h,h,h,!1,h,!1,h,h,h,h,!0,h,h,h,h,h,A.d(w,h,h,h,h,h,h,h,h,h),h,h,h,1,h,!0)
v=A.d(g.gX5(),h,h,h,h,h,h,C.az,h,h)
u=i.a.r
return A.bN(x,h,new A.dA(!0,!0,!0,!0,C.I,!1,A.aM(new A.J(C.aU,A.w(A.a([v,L.dy,A.c6(A.d(g.giO(),h,h,h,h,h,h,h,h,h),h,u,h)],y.p),C.l,h,C.e,C.H,0,C.j),h),h,h,h),h),h,h,h,h,h)}t=i.r
s=i.w
r=i.x
x=t==null
if((x?h:t.y)===!0)q=(x?h:t.r)===!0
else q=!1
p=i.gbLW()
o=i.dC4(g)
v=y.p
u=A.a([A.d(g.gKs(),h,h,h,h,h,h,h,h,h),C.Q],v)
if(!x)C.d.v(u,A.a([i.bQA(g.gX3(),t.b+" USDT"),i.bQA(g.gWZ(),t.a+" USDT")],v))
if(o!=null)u.push(new A.J(O.eJ,A.d(o,D.c2t,h,h,h,h,A.Y(h,h,A.t(d).ax.fy,h,h,h,h,h,h,h,h,h,h,h,h,h,h,!0,h,h,h,h,h,h,h,h),h,h,h),h))
if(i.as)u.push(D.bsg)
n=s==null
if(!n){m=A.d(g.gadb(),h,h,h,h,h,A.t(d).ok.w,h,h,h)
l=i.bQA(g.gu6(),s.a.c+" USDT")
k=s.b
j=k==null
if(!j)k=k.a==="ACTIVE"?g.gawW():g.gWW()
else k=s.c?g.gWX():g.gUX()
k=A.a([m,l,A.d(k,h,h,h,h,h,h,h,h,h),C.Q],v)
if(!j||s.c)k.push(i.Em("gameV2AcknowledgePurchase",g.gad5(),i.gcRJ()))
else k.push(i.Em("gameV2RetryPurchase",g.gade(),i.gc8j()))
u.push(A.dg(new A.J(C.C,A.w(k,C.a8,h,C.e,C.f,0,C.j),h),h,h,h,h,h,h,h))}if(n){m=(x?h:t.x)===!0
x=m}else x=!1
if(x)u.push(i.Em("gameV2Purchase",g.gX0(),i.gc8j()))
x=r==null
if(!x){m=r.b
l=m==null
k=A.a([A.d((l?h:F.jO.t(0,m.a))===!0?g.gad8():g.gUW(),h,h,h,h,h,h,h,h,h),C.Q],v)
if(i.y!=null&&q)k.push(i.Em("gameV2Open",g.gxf(),i.gdC5()))
j=!1
if(n)if(q)if((l?h:F.jO.t(0,m.a))!==!0)j=(l?h:m.f)==null
else j=!0
if(j){j=(l?h:F.jO.t(0,m.a))===!0?g.gUY():g.gUZ()
k.push(i.Em("gameV2Reissue",j,i.gcil()))}if((l?h:F.jO.t(0,m.a))!==!0)k.push(i.bKx("gameV2End",g.gad7(),i.gdC2(),!0))
u.push(A.dg(new A.J(C.C,A.w(k,C.a8,h,C.e,C.f,0,C.j),h),h,h,h,h,h,h,h))}if(n&&x&&q)u.push(i.Em("gameV2Prepare",g.gUY(),i.gcil()))
if(p===D.td)u.push(i.Em("gameV2BindTelegram",g.gRe(),new B.dpW(i)))
if(p===D.te||p===D.tf)u.push(i.Em("gameV2TopUp",g.gX1(),new B.dpX(i)))
u.push(i.bKx("gameV2CheckOriginal",g.gad6(),i.gdC7(),!0))
g=A.d(w,h,h,h,h,h,h,h,h,h)
return A.bN(A.kP(h,h,h,!0,!0,h,h,1,h,h,h,!1,h,!1,h,h,A.e06(h,new B.dpY(i)),h,!0,h,h,h,h,h,g,h,h,h,1,h,!0),h,new A.dA(!0,!1,!0,!0,C.I,!1,A.eN(A.a([A.aM(new A.ba(C.w0,A.w(u,C.a8,h,C.e,C.f,0,C.j),h),h,h,h)],v),h,D.c2u,P.Q1,h,h,C.y,!1),h),h,h,h,h,h)},
bQA(d,e){var x=null
return new A.J(Q.DL,A.bi(C.lf,A.a([A.d(d,x,x,x,x,x,x,x,x,x),A.d(e,x,x,x,x,x,x,x,x,x)],y.p),C.ac,x,4,16),x)},
bKx(d,e,f,g){var x,w=null,v=y.O
if(g){x=this.as?w:new B.dpw(f)
x=A.fl(A.d(e,w,w,w,w,w,w,C.az,w,w),new A.H(d,v),x,w)
v=x}else{x=this.as?w:new B.dpx(f)
x=A.c6(A.d(e,w,w,w,w,w,w,C.az,w,w),new A.H(d,v),x,w)
v=x}return new A.J(R.DI,v,w)},
Em(d,e,f){return this.bKx(d,e,f,!1)}}
B.bfm.prototype={}
B.aiH.prototype={
O(){return new B.bbc()}}
B.bbc.prototype={
Y(){var x,w,v,u=this
u.a6()
x="slot-game-frame-"+1000*Date.now()
u.d!==$&&A.aL()
u.d=x
w=b.G.document.createElement("iframe")
w.style.border="0"
w.style.width="100%"
w.style.height="100%"
w.style.display="block"
w.allow="autoplay; fullscreen; clipboard-read; clipboard-write"
u.e!==$&&A.aL()
u.e=w
v=u.a.d
if(v!=null)w.id=v
v=A.dR(new B.drm(u.a.e))
u.f=v
w.addEventListener("load",v)
w.src=u.a.c
$.ayY()
$.BY().a9S(x,new B.drn(u),!0)},
aQ(d){var x,w
this.aZ(d)
x=this.a.c
if(d.c!==x){w=this.e
w===$&&A.e()
w.src=x}},
q(){var x,w=this,v=w.f
if(v!=null){x=w.e
x===$&&A.e()
x.removeEventListener("load",v)}x=w.e
x===$&&A.e()
x.src="about:blank"
x.remove()
w.a5()},
u(d){var x=this.d
x===$&&A.e()
return new A.R4(x,null,null,C.zR,null)}}
B.Fa.prototype={
O(){var x=$.am()
return new B.au_(x.$1$0(y.w),x.$1$0(y.r),"agora-slot-"+1000*Date.now()+"-"+$.pA().mY(1073741824),x.$1$0(y.x))}}
B.au_.prototype={
gh7(){if(this.c!=null){var x=this.z
x=x==null?null:x.gN()
x=x!==!1}else x=!1
return x},
gEM(){var x,w=this,v=!1
if(!w.Q){x=w.y
x=x==null?null:x.gN()
if(x!==!1)if(w.gh7()){v=w.x
v===$&&A.e()
v=v.gN()}}return v},
ghy(){var x,w,v,u=this
if(u.ax)return!1
try{w=$.nS
if(w!=null)w.d_()
x=u.at
if(x!=null&&u.w.ms(x))return!0}catch(v){if(!(A.u(v) instanceof A.JE))throw v}u.ax=!0
u.CW=null
return!1},
gbwd(){var x,w=this.ay
if(w===$){x=$.am().$1$0(y.T)
this.ay!==$&&A.bf()
w=this.ay=new E.afM(x)}return w},
Y(){var x,w,v,u,t,s=this
s.a6()
x=$.am()
w=x.$1$0(y.A)
v=w.f==null
u=!v
if(u){x=A.j8(x.$1$0(y.E),s.w)
x.a4(s.gckj())
s.y=x}if(v)s.at=s.w.bTS()
x=u?w.dZ2(new B.dsl(s)):w
s.x!==$&&A.aL()
s.x=x
v=s.a
if(v.d!=null){if(x.f==null)s.a_5()
return}t=s.d=B.eLg(v.c)
if(t==null){s.k2=!1
s.ok=D.hb
return}if(!t.gbXO()){s.k2=!1
s.ok=D.hb
return}if(t.e!==C.iS){s.k2=!1
v=x.f!=null?s.as:null
s.p1=B.f2Z(s.gbQT(),v,new B.dsm(s))
x=x.f!=null?s.as:null
s.p2=B.f3_(s.gdhp(),x,new B.dsn(s))
$.al.y2$.push(new B.dso(s))
s.cy=s.atp()
return}},
b_(){var x,w,v=this
v.bB()
x=v.c
x.toString
v.z=A.cs(x,null,y.X)
x=v.y
if((x==null?null:x.gN())===!1)$.al.y2$.push(new B.dsk(v))
w=v.d
if(!v.k1&&w!=null&&w.e!==C.iS){v.k1=!0
v.f=v.c8e()}},
ckk(){var x=this,w=!0
if(x.c!=null)if(!x.Q){w=x.y
w=(w==null?null:w.gN())!==!1}if(w)return
B.eq7(A.a_(["type","HOST_RETIRED"],y.N,y.z),x.as)
x.n(new B.ds6(x))},
Zl(){var x=0,w=A.l(y.H),v,u=2,t=[],s=this,r,q,p,o,n,m,l,k,j,i,h,g
var $async$Zl=A.h(function(d,e){if(d===1){t.push(e)
x=u}for(;;)switch(x){case 0:j=s.x
j===$&&A.e()
x=j.f!=null?3:4
break
case 3:u=6
x=9
return A.c(s.arj(),$async$Zl)
case 9:u=2
x=8
break
case 6:u=5
i=t.pop()
x=8
break
case 5:x=2
break
case 8:x=1
break
case 4:u=11
if(!(s.gh7()&&s.ghy()))A.U(C.ao)
x=14
return A.c(s.w.iv(),$async$Zl)
case 14:r=e
if(!(s.gh7()&&s.ghy()))A.U(C.ao)
if(s.c!=null&&r!=null)try{if(!(s.gh7()&&s.ghy()))A.U(C.ao)
b.G.window.localStorage.setItem("_flutter_game_jwt",r)}catch(f){q=A.u(f)
$.iN().m(C.aK,"localStorage jwt write failed (private mode?)",q,null)}u=2
x=13
break
case 11:u=10
h=t.pop()
p=A.u(h)
if(!(s.gh7()&&s.ghy())){x=1
break}$.iN().m(C.t,"_fetchUserInfo: getValidToken failed",p,null)
x=13
break
case 10:x=2
break
case 13:u=16
if(!(s.gh7()&&s.ghy()))A.U(C.ao)
x=19
return A.c(s.r.ii(!0),$async$Zl)
case 19:o=e
if(!(s.gh7()&&s.ghy()))A.U(C.ao)
if(s.c!=null){j=o
k=j==null?null:j.f
n=k==null?0:k
s.n(new B.drG(s,n))
try{j=J.a7Y(n,4)
if(!(s.gh7()&&s.ghy()))A.U(C.ao)
b.G.window.localStorage.setItem("_flutter_game_balance",j)}catch(f){m=A.u(f)
$.iN().m(C.aK,"localStorage balance write failed",m,null)}}u=2
x=18
break
case 16:u=15
g=t.pop()
if(s.gh7()&&s.ghy())s.n(new B.drH(s))
x=18
break
case 15:x=2
break
case 18:case 1:return A.j(v,w)
case 2:return A.i(t.at(-1),w)}})
return A.k($async$Zl,w)},
vx(){return this.cWc()},
cWc(){var x=0,w=A.l(y.P),v,u=2,t=[],s=this,r,q,p,o,n,m,l,k,j,i,h,g,f,e,d,a0,a1,a2,a3,a4,a5,a6,a7
var $async$vx=A.h(function(a9,b0){if(a9===1){t.push(b0)
x=u}for(;;)switch(x){case 0:a2={}
a3=s.x
a3===$&&A.e()
x=a3.f!=null?3:4
break
case 3:x=5
return A.c(s.arj(),$async$vx)
case 5:h=b0
x=6
return A.c(s.Zz(),$async$vx)
case 6:g=b0
r=null
u=8
x=11
return A.c(a3.cIC(),$async$vx)
case 11:r=b0
u=2
x=10
break
case 8:u=7
a4=t.pop()
r=A.a_(["status","unavailable"],y.N,y.z)
x=10
break
case 7:x=2
break
case 10:if(!s.gEM())throw A.o(C.ao)
a2=A.mI(h.i(0,"balance"))
e=a2==null?null:a2
if(e==null)e=0
a2=A.q(y.N,y.z)
a2.h(0,"type","HOST_INIT")
a2.h(0,"authMode","v2-http-only")
a2.h(0,"hostAuthenticated",!0)
a2.h(0,"balance",e)
a2.h(0,"demoMode",e<0.25)
a3=h.i(0,"username")
a2.h(0,"username",a3==null?"":a3)
a2.h(0,"slotOperation",r)
if(g!=null)a2.h(0,"rtp",g)
v=a2
x=1
break
case 4:if(!(s.gh7()&&s.ghy()))A.U(C.ao)
a3=s.w
d=s.at
d.toString
q=a3.a4s(d)
e=s.CW
a2.a=e==null?0:e
p=""
x=q==null?12:13
break
case 12:u=15
x=18
return A.c(a3.iv(),$async$vx)
case 18:q=b0
if(!(s.gh7()&&s.ghy()))A.U(C.ao)
u=2
x=17
break
case 15:u=14
a5=t.pop()
o=A.u(a5)
if(!(s.gh7()&&s.ghy()))A.U(C.ao)
$.iN().m(C.t,"_buildHostInitPayload: getValidToken failed",o,null)
x=17
break
case 14:x=2
break
case 17:case 13:a3=q
if(a3!=null)try{a3=q
if(!(s.gh7()&&s.ghy()))A.U(C.ao)
b.G.window.localStorage.setItem("_flutter_game_jwt",a3)}catch(a8){n=A.u(a8)
$.iN().m(C.aK,"localStorage jwt write failed in shim",n,null)}x=s.CW==null?19:21
break
case 19:u=23
x=26
return A.c(s.r.Dr(),$async$vx)
case 26:m=b0
if(!(s.gh7()&&s.ghy()))A.U(C.ao)
a3=m
a0=a3==null?null:a3.b
p=a0==null?"":a0
a3=m
e=a3==null?null:a3.f
a2.a=e==null?0:e
if(s.c!=null)s.n(new B.drq(a2,s))
try{a3=C.k.Z(a2.a,4)
if(!(s.gh7()&&s.ghy()))A.U(C.ao)
b.G.window.localStorage.setItem("_flutter_game_balance",a3)}catch(a8){l=A.u(a8)
$.iN().m(C.aK,"localStorage balance write failed in shim",l,null)}u=2
x=25
break
case 23:u=22
a6=t.pop()
k=A.u(a6)
if(!(s.gh7()&&s.ghy()))A.U(C.ao)
$.iN().m(C.t,"_buildHostInitPayload: getProfile failed",k,null)
x=25
break
case 22:x=2
break
case 25:x=20
break
case 21:u=28
x=31
return A.c(s.r.Dr(),$async$vx)
case 31:j=b0
if(!(s.gh7()&&s.ghy()))A.U(C.ao)
a3=j
a0=a3==null?null:a3.b
p=a0==null?"":a0
u=2
x=30
break
case 28:u=27
a7=t.pop()
i=A.u(a7)
if(!(s.gh7()&&s.ghy()))A.U(C.ao)
$.iN().m(C.t,"_buildHostInitPayload: getProfile failed",i,null)
x=30
break
case 27:x=2
break
case 30:case 20:a3=a2.a
x=32
return A.c(s.Zz(),$async$vx)
case 32:g=b0
if(!(s.gh7()&&s.ghy()))A.U(C.ao)
d=A.q(y.N,y.z)
d.h(0,"type","HOST_INIT")
a1=q
d.h(0,"jwt",a1==null?"":a1)
d.h(0,"balance",a2.a)
d.h(0,"demoMode",a3<0.25)
d.h(0,"username",p)
if(g!=null)d.h(0,"rtp",g)
v=d
x=1
break
case 1:return A.j(v,w)
case 2:return A.i(t.at(-1),w)}})
return A.k($async$vx,w)},
Zz(){var x=0,w=A.l(y.h),v,u=this,t,s
var $async$Zz=A.h(function(d,e){if(d===1)return A.i(e,w)
for(;;)switch(x){case 0:s=u.cx
if(s!=null){v=s
x=1
break}t=u.cy
if(t==null)t=u.cy=u.atp()
v=t.tk(C.PG,new B.drI())
x=1
break
case 1:return A.j(v,w)}})
return A.k($async$Zz,w)},
arj(){var x=0,w=A.l(y.P),v,u=this,t,s,r
var $async$arj=A.h(function(d,e){if(d===1)return A.i(e,w)
for(;;)switch(x){case 0:if(!u.gEM())throw A.o(C.ao)
t=u.x
t===$&&A.e()
x=3
return A.c(t.jU(),$async$arj)
case 3:s=e
if(!u.gEM())throw A.o(C.ao)
r=y.P.a(s.i(0,"data"))
if(u.c!=null)u.n(new B.drF(u,r))
v=r
x=1
break
case 1:return A.j(v,w)}})
return A.k($async$arj,w)},
atp(){var x=0,w=A.l(y.h),v,u=2,t=[],s=[],r=this,q,p,o,n,m,l,k,j
var $async$atp=A.h(function(d,e){if(d===1){t.push(e)
x=u}for(;;)switch(x){case 0:k=r.d
if(k==null){v=null
x=1
break}u=4
m=r.x
m===$&&A.e()
x=7
return A.c(m.bpQ(k.a),$async$atp)
case 7:q=e
if(J.p(J.ax(q,"success"),!0)&&y.f.b(J.ax(q,"data"))){p=A.p1(y.f.a(J.ax(q,"data")),y.N,y.z)
r.cx=p
if(m.f==null)try{m=C.G.az(p,null)
if(!(r.gh7()&&r.ghy()))A.U(C.ao)
b.G.window.localStorage.setItem("_flutter_game_rtp",m)}catch(i){o=A.u(i)
$.iN().m(C.aK,"localStorage rtp write failed",o,null)}v=p
s=[1]
x=5
break}s.push(6)
x=5
break
case 4:u=3
j=t.pop()
n=A.u(j)
$.iN().m(C.t,"_getSlotRtpData failed",n,null)
s.push(6)
x=5
break
case 3:s=[2]
case 5:u=2
if(r.cx==null)r.cy=null
x=s.pop()
break
case 6:v=null
x=1
break
case 1:return A.j(v,w)
case 2:return A.i(t.at(-1),w)}})
return A.k($async$atp,w)},
a_5(){var x=0,w=A.l(y.H),v,u=2,t=[],s=this,r,q,p,o,n,m,l,k
var $async$a_5=A.h(function(d,e){if(d===1){t.push(e)
x=u}for(;;)switch(x){case 0:l=s.a.d
if(l==null){x=1
break}u=4
x=7
return A.c(s.gbwd().pV(l),$async$a_5)
case 7:r=e
if(s.c==null){x=1
break}if(r==null||!r.c){s.n(new B.drN(s,r))
x=1
break}s.n(new B.drO(s,r))
x=8
return A.c(s.tL(),$async$a_5)
case 8:u=2
x=6
break
case 4:u=3
k=t.pop()
m=A.u(k)
if(m instanceof A.hx){q=m
$.iN().m(C.t,"get product game descriptor failed: "+q.a+" "+q.b,null,null)
if(s.c==null){x=1
break}s.n(new B.drP(s,q))}else{p=m
o=A.aO(k)
m=$.iN()
m.m(C.t,"get product game descriptor failed",p,o)
if(s.c==null){x=1
break}s.n(new B.drQ(s))}x=6
break
case 3:x=2
break
case 6:case 1:return A.j(v,w)
case 2:return A.i(t.at(-1),w)}})
return A.k($async$a_5,w)},
tL(){var x=0,w=A.l(y.H),v,u=2,t=[],s=this,r,q,p,o,n,m,l,k,j,i,h,g,f,e,d,a0
var $async$tL=A.h(function(a1,a2){if(a1===1){t.push(a2)
x=u}for(;;)switch(x){case 0:f=s.d
e=s.e
d=s.a.d
if(f==null||e==null||d==null||f.e!==C.iS){if(s.c==null){x=1
break}s.n(new B.drs(s,f))
x=1
break}if(!f.gbXO()){if(s.c==null){x=1
break}s.n(new B.drt(s))
x=1
break}if(s.c!=null)s.n(new B.dru(s))
u=4
x=7
return A.c(s.w.iv(),$async$tL)
case 7:r=a2
if(r==null||r.length===0){if(s.c==null){x=1
break}s.n(new B.drv(s))
x=1
break}if(s.c==null){x=1
break}q=s.brw(r)
if(q==null){s.n(new B.drw(s))
x=1
break}k=s.fx
if(k!=null&&k!==q)s.dx=null
s.fx=q
k=s.gbwd().a
if(k.a.c instanceof A.fM)A.U(C.x)
x=8
return A.c(k.IO(d),$async$tL)
case 8:p=a2
if(s.c==null){x=1
break}if(p==null||p.a!==f.a||p.b==null||p.c==null){s.n(new B.drx(s,p))
x=1
break}s.db=p
x=p.c===!0?9:10
break
case 9:o=s.cfx(p.r)
if(p.b!==!0||o!=null){s.n(new B.dry(s,o))
x=1
break}if(p.w!=null){k=p.w
k.toString
j=k>0}else j=!1
n=j
s.n(new B.drz(s,n))
k=p.b
i=p.c
h=p.w
x=(n?null:D.is)==null&&k===!0&&i===!0&&h!=null&&h>0?11:12
break
case 11:x=13
return A.c(s.dF5(!0),$async$tL)
case 13:case 12:x=1
break
case 10:s.n(new B.drA(s,p))
u=2
x=6
break
case 4:u=3
a0=t.pop()
k=A.u(a0)
if(k instanceof A.hx){m=k
$.iN().m(C.t,"getMyAccess failed: "+m.a+" "+m.b,null,null)
if(s.c==null){x=1
break}s.n(new B.drB(s,m))}else{l=k
$.iN().m(C.t,"getMyAccess failed",l,null)
if(s.c==null){x=1
break}s.n(new B.drC(s))}x=6
break
case 3:x=2
break
case 6:case 1:return A.j(v,w)
case 2:return A.i(t.at(-1),w)}})
return A.k($async$tL,w)},
bPM(){var x,w=this
if(w.a.d!=null)x=w.e==null||w.d==null
else x=!1
if(x)return w.a_5()
return w.tL()},
vM(){var x=0,w=A.l(y.H),v,u=2,t=[],s=this,r,q,p,o,n,m,l,k,j,i,h,g,f,e
var $async$vM=A.h(function(d,a0){if(d===1){t.push(a0)
x=u}for(;;)switch(x){case 0:if(s.k2||s.k3){x=1
break}i=s.d
r=s.fx
h=i==null
if(h||i.e!==C.iS){if(s.c==null){x=1
break}if(h)s.n(new B.drY(s))
x=1
break}q=s.a.d
if(q!=null){h=s.e
h=h==null?null:h.b
h=h!==i.a}else h=!0
if(h){if(s.c==null){x=1
break}s.n(new B.drZ(s))
x=1
break}h=s.db
x=(h==null?null:h.b)!==!0?3:4
break
case 3:x=5
return A.c(s.tL(),$async$vM)
case 5:x=1
break
case 4:s.n(new B.ds_(s))
u=7
x=10
return A.c(s.w.iv(),$async$vM)
case 10:p=a0
if(p==null||p.length===0){if(s.c==null){x=1
break}s.n(new B.ds0(s))
x=1
break}if(s.c==null){x=1
break}o=s.brw(p)
if(o==null){s.n(new B.ds1(s))
x=1
break}x=r==null||r!==o?11:12
break
case 11:s.bQ0(o)
x=13
return A.c(s.tL(),$async$vM)
case 13:x=1
break
case 12:s.fx=o
x=14
return A.c(s.bOm(),$async$vM)
case 14:n=a0
if(s.c==null){x=1
break}h=s.gbwd().a
if(h.a.c instanceof A.fM)A.U(C.x)
x=15
return A.c(h.SB(q,new E.aH3(n)),$async$vM)
case 15:m=a0
if(s.c==null){x=1
break}h=m
x=(h==null?null:h.b)===C.Rg?16:17
break
case 16:x=18
return A.c(s.ar0(),$async$vM)
case 18:if(s.c==null){x=1
break}s.n(new B.ds2(s))
x=19
return A.c(s.tL(),$async$vM)
case 19:x=1
break
case 17:s.n(new B.ds3(s,m))
u=2
x=9
break
case 7:u=6
e=t.pop()
h=A.u(e)
x=h instanceof A.hx?20:22
break
case 20:l=h
$.iN().m(C.t,"purchase game access failed: "+l.a+" "+l.b,null,null)
k=s.buL(l,D.xr)
f=l.b.toUpperCase()
x=k===D.th||C.b.t(f,"ENTITLEMENT_NOT_FOUND")||C.b.t(f,"IDEMPOTENCY_CONFLICT")?23:24
break
case 23:x=25
return A.c(s.ar0(),$async$vM)
case 25:case 24:if(s.c==null){x=1
break}s.n(new B.ds4(s,k))
x=21
break
case 22:j=h
$.iN().m(C.t,"purchase game access failed",j,null)
if(s.c==null){x=1
break}s.n(new B.ds5(s))
case 21:x=9
break
case 6:x=2
break
case 9:case 1:return A.j(v,w)
case 2:return A.i(t.at(-1),w)}})
return A.k($async$vM,w)},
pg(d,e){return this.dF6(d,!0)},
dF5(d){return this.pg(!0,d)},
dF6(b9,c0){var x=0,w=A.l(y.H),v,u=2,t=[],s=this,r,q,p,o,n,m,l,k,j,i,h,g,f,e,d,a0,a1,a2,a3,a4,a5,a6,a7,a8,a9,b0,b1,b2,b3,b4,b5,b6,b7,b8
var $async$pg=A.h(function(c1,c2){if(c1===1){t.push(c2)
x=u}for(;;)switch(x){case 0:b6=s.d
if(s.c==null||b6==null){x=1
break}r=s.fx
b1=s.db
if(b6.e===C.iS){b2=b1==null
b3=!0
if((b2?null:b1.b)===!0)if((b2?null:b1.c)===!0)if((b2?null:b1.w)!=null){b2=b1.w
b2.toString
b2=b2<=0}else b2=b3
else b2=b3
else b2=b3}else b2=!1
if(b2){s.n(new B.ds9(s))
x=1
break}q=b1==null?null:b1.w
s.n(new B.dsa(s))
u=4
x=7
return A.c(s.w.iv(),$async$pg)
case 7:p=c2
if(s.c==null){x=1
break}o=p==null||p.length===0?null:s.brw(p)
if(o==null){s.n(new B.dsb(s))
x=1
break}x=r==null||r!==o?8:9
break
case 8:s.bQ0(o)
x=10
return A.c(s.tL(),$async$pg)
case 10:x=1
break
case 9:s.fx=o
b8=s.dx!=null
if(b8){x=11
break}else c2=b8
x=12
break
case 11:x=13
return A.c(s.Au(!0),$async$pg)
case 13:c2=!c2
case 12:if(c2){if(s.c==null){x=1
break}s.n(new B.dsc(s))
x=1
break}if(s.c==null){x=1
break}x=14
return A.c(s.bOn(),$async$pg)
case 14:n=c2
if(s.c==null){x=1
break}x=15
return A.c(s.ch.KD(b6.a,new B.aH4(n)),$async$pg)
case 15:m=c2
l=new A.aH(Date.now(),0,!1).a3()
k=m==null?null:E.epW(m.w)
j=m==null?null:E.dUQ(m.f)
i=m==null?null:E.dUQ(m.r)
h=m==null?null:E.dUQ(m.x)
b2=m
g=(b2==null?null:b2.e)===C.Ri
f=m!=null&&m.a>0
e=m!=null&&m.b>0&&m.b===q
d=m!=null&&m.c===b6.a
b2=m
b2=b2==null?null:b2.d
b3=n
a0=b2==null?b3==null:b2===b3
a1=j!=null&&Math.abs(j.a3().dt(l.a3()).a)<=3e8
b2=i
a2=(b2==null?null:b2.ia(l))===!0
b2=h
a3=(b2==null?null:b2.ia(l))===!0
a4=h!=null&&i!=null&&!h.ia(i)
a5=k!=null
a6=g&&f&&e&&d&&a0&&a1&&a2&&a3&&a4&&a5
x=!a6?16:17
break
case 16:a7=A.a([],y.s)
if(!g)J.c3(a7,"status")
if(!f)J.c3(a7,"session_id")
if(!e)J.c3(a7,"entitlement")
if(!d)J.c3(a7,"game_key")
if(!a0)J.c3(a7,"client_session")
if(!a1)J.c3(a7,"session_started_at")
if(!a2)J.c3(a7,"session_expiry")
if(!a3)J.c3(a7,"launch_expiry")
if(!a4)J.c3(a7,"launch_expiry_bound")
if(!a5)J.c3(a7,"launch_url_untrusted")
a8=a7
$.iN().m(C.t,"game session response rejected: "+J.bhk(a8,","),null,null)
x=g&&f&&d?18:19
break
case 18:x=20
return A.c(s.LB(b6.a,!0,m.a),$async$pg)
case 20:case 19:x=21
return A.c(s.YF(),$async$pg)
case 21:if(s.c==null){x=1
break}s.n(new B.dsd(s))
x=1
break
case 17:s.dx=m
x=s.c==null?22:23
break
case 22:x=24
return A.c(s.Au(!0),$async$pg)
case 24:x=1
break
case 23:x=b6.e===C.iS?25:26
break
case 25:s.n(new B.dse(s,k,h))
x=27
return A.c(s.AI(),$async$pg)
case 27:x=1
break
case 26:s.n(new B.dsf(s))
u=2
x=6
break
case 4:u=3
b7=t.pop()
a7=A.u(b7)
x=a7 instanceof A.hx?28:30
break
case 28:a9=a7
$.iN().m(C.t,"start game session failed: "+a9.a+" "+a9.b,null,null)
if(b9){b5=a9.b.toUpperCase()
a7=C.b.t(b5,"SESSION_ENDED")||C.b.t(b5,"SESSION_EXPIRED")||C.b.t(b5,"SESSION_IDENTITY_MISMATCH")}else a7=!1
x=a7?31:32
break
case 31:x=33
return A.c(s.YF(),$async$pg)
case 33:if(s.c==null){x=1
break}x=34
return A.c(s.pg(!1,!0),$async$pg)
case 34:x=1
break
case 32:if(s.c==null){x=1
break}s.n(new B.dsg(s,a9))
x=29
break
case 30:b0=a7
$.iN().m(C.t,"start game session failed",b0,null)
if(s.c==null){x=1
break}s.n(new B.dsh(s))
case 29:x=6
break
case 3:x=2
break
case 6:case 1:return A.j(v,w)
case 2:return A.i(t.at(-1),w)}})
return A.k($async$pg,w)},
AI(){var x=0,w=A.l(y.H),v,u=2,t=[],s=this,r,q,p,o,n,m,l,k,j,i,h,g,f,e
var $async$AI=A.h(function(d,a0){if(d===1){t.push(a0)
x=u}for(;;)switch(x){case 0:if(s.id){x=1
break}r=s.dy
k=s.fr
if(r==null||k==null){x=1
break}s.n(new B.drR(s))
x=!k.ia(new A.aH(Date.now(),0,!1).a3())?3:4
break
case 3:x=5
return A.c(s.Au(!0),$async$AI)
case 5:if(s.c==null){x=1
break}s.n(new B.drS(s))
x=1
break
case 4:j=s.fx
q=null
u=7
x=10
return A.c(s.w.iv(),$async$AI)
case 10:q=a0
u=2
x=9
break
case 7:u=6
f=t.pop()
p=A.u(f)
o=A.aO(f)
h=$.iN()
h.m(C.t,"external game auth refresh failed",p,o)
if(s.c==null){x=1
break}s.n(new B.drT(s))
x=1
break
x=9
break
case 6:x=2
break
case 9:if(s.c==null){x=1
break}g=q==null||q.length===0?null:s.brw(q)
if(g==null){s.n(new B.drU(s))
x=1
break}x=j==null||j!==g?11:12
break
case 11:s.bQ0(g)
x=13
return A.c(s.tL(),$async$AI)
case 13:x=1
break
case 12:u=15
s.n(new B.drV(s))
x=18
return A.c(A.uw(r,C.lK,"_self"),$async$AI)
case 18:n=a0
if(s.c==null){x=1
break}if(n){s.n(new B.drW(s))
x=1
break}u=2
x=17
break
case 15:u=14
e=t.pop()
m=A.u(e)
l=A.aO(e)
h=$.iN()
h.m(C.t,"external game launch failed",m,l)
x=17
break
case 14:x=2
break
case 17:x=19
return A.c(s.Au(!0),$async$AI)
case 19:if(s.c==null){x=1
break}s.n(new B.drX(s))
case 1:return A.j(v,w)
case 2:return A.i(t.at(-1),w)}})
return A.k($async$AI,w)},
Au(d){return this.d6F(!0)},
d6F(d){var x=0,w=A.l(y.y),v,u=2,t=[],s=[],r=this,q,p,o,n,m,l,k
var $async$Au=A.h(function(e,f){if(e===1){t.push(f)
x=u}for(;;)switch(x){case 0:k=r.k4
if(k!=null){v=k
x=1
break}p=r.d
o=r.dx
n=o==null?null:o.a
if(p==null||n==null){v=!0
x=1
break}q=r.LB(p.a,!0,n)
r.k4=q
u=3
x=6
return A.c(q,$async$Au)
case 6:m=f
v=m
s=[1]
x=4
break
s.push(5)
x=4
break
case 3:s=[2]
case 4:u=2
m=r.k4
l=q
if(m==null?l==null:m===l)r.k4=null
x=s.pop()
break
case 5:case 1:return A.j(v,w)
case 2:return A.i(t.at(-1),w)}})
return A.k($async$Au,w)},
LB(d,e,f){return this.d6M(d,!0,f)},
d6M(d,e,f){var x=0,w=A.l(y.y),v,u=2,t=[],s=this,r,q,p,o,n,m,l,k
var $async$LB=A.h(function(g,h){if(g===1){t.push(h)
x=u}for(;;)switch(x){case 0:p=!1
o=2
n=0
m=s.ch
l=y.H
case 3:if(!(n<o&&!p)){x=4
break}u=6
x=9
return A.c(m.PC(d,f),$async$LB)
case 9:p=!0
u=2
x=8
break
case 6:u=5
k=t.pop()
r=A.u(k)
$.iN().m(C.aK,"end game session failed",r,null)
x=n+1<o?10:11
break
case 10:x=12
return A.c(A.eM(C.Dx,null,l),$async$LB)
case 12:case 11:x=8
break
case 5:x=2
break
case 8:++n
x=3
break
case 4:x=p?13:14
break
case 13:m=s.dx
if((m==null?null:m.a)===f)s.dx=null
s.fr=s.dy=null
x=15
return A.c(s.YF(),$async$LB)
case 15:case 14:v=p
x=1
break
case 1:return A.j(v,w)
case 2:return A.i(t.at(-1),w)}})
return A.k($async$LB,w)},
bOm(){var x=0,w=A.l(y.N),v,u=this,t
var $async$bOm=A.h(function(d,e){if(d===1)return A.i(e,w)
for(;;)switch(x){case 0:t=u.gciO()
v=B.Dk(new B.drJ(u),u.gcfI(),new B.drK(),t)
x=1
break
case 1:return A.j(v,w)}})
return A.k($async$bOm,w)},
ar0(){var x=0,w=A.l(y.H),v=this
var $async$ar0=A.h(function(d,e){if(d===1)return A.i(e,w)
for(;;)switch(x){case 0:x=2
return A.c(B.acw(new B.drD(),A.dK([v.gciO(),v.gcfI()],y.N)),$async$ar0)
case 2:return A.j(null,w)}})
return A.k($async$ar0,w)},
bOn(){var x=0,w=A.l(y.N),v,u=this
var $async$bOn=A.h(function(d,e){if(d===1)return A.i(e,w)
for(;;)switch(x){case 0:v=B.Dk(new B.drL(u),null,new B.drM(),u.gclx())
x=1
break
case 1:return A.j(v,w)}})
return A.k($async$bOn,w)},
YF(){var x=0,w=A.l(y.H),v=this
var $async$YF=A.h(function(d,e){if(d===1)return A.i(e,w)
for(;;)switch(x){case 0:x=2
return A.c(B.acw(new B.drE(),A.dK([v.gclx()],y.N)),$async$YF)
case 2:return A.j(null,w)}})
return A.k($async$YF,w)},
brw(d){var x=A.bHC(d),w=x==null?null:C.b.F(x)
return w==null||w.length===0?null:w},
bQ0(d){var x=this
x.fx=d
x.fr=x.dy=x.dx=x.db=null
x.k3=x.k2=x.id=x.go=x.fy=!1
x.ok=null},
gciO(){var x=this.a.d
x=A.b(x==null?"unknown":x)
return B.e6e(D.Ra,this.fx,"product-"+x)},
gcfI(){var x=this.d
x=x==null?null:x.a
if(x==null)x=this.a.c
if(x==null)x="unknown"
return B.e6e(D.Ra,this.fx,x)},
gclx(){var x=this.d
x=x==null?null:x.a
if(x==null)x=this.a.c
if(x==null)x="unknown"
return B.e6e(D.aPN,this.fx,x)},
cgN(d){var x,w=Date.now(),v=C.h.iZ($.pA().mY(4294967296),16),u=this.d
u=u==null?null:u.a
x=u==null?this.a.c:u
if(x==null){u=this.a.d
x="product-"+A.b(u==null?"unknown":u)}return d+"-"+x+"-"+1000*w+"-"+v},
cfx(d){var x=B.dTO(d)
if(x!=null)return x
return d==null||C.b.F(d).length===0?null:D.jl},
buL(d,e){var x,w=d.a
if(w===401)return D.jk
x=B.dTO(d.b)
if(x!=null)return x
if(w===404)return D.hb
return e},
dnX(d,e){switch(e){case D.jk:return d.gamJ()
case D.td:return d.gX4()
case D.te:return d.gWV()
case D.tf:return d.gX2()
case D.tg:return d.gWY()
case D.th:return d.gWU()
case D.xs:return d.gX_()
case D.hb:return d.gKu()
case D.EP:return d.gWW()
case D.Rb:return d.gamM()
case D.jl:return d.gWS()
case D.xr:return d.gWX()
case D.is:return d.gamN()
case null:case void 0:return null}},
bug(d){return this.dhq(d)},
dhq(d){var x=0,w=A.l(y.h),v,u=this,t,s,r
var $async$bug=A.h(function(e,f){if(e===1)return A.i(f,w)
for(;;)switch(x){case 0:r=u.x
r===$&&A.e()
if(r.f!=null)t=u.gEM()
else t=u.gh7()&&u.ghy()
if(!t){v=null
x=1
break}x=3
return A.c(u.AD(d),$async$bug)
case 3:s=f
if(r.f!=null)r=u.gEM()
else r=u.gh7()&&u.ghy()
if(!r){v=null
x=1
break}v=s
x=1
break
case 1:return A.j(v,w)}})
return A.k($async$bug,w)},
AD(d){return this.dcF(d)},
dcF(c0){var x=0,w=A.l(y.h),v,u=2,t=[],s=this,r,q,p,o,n,m,l,k,j,i,h,g,f,e,d,a0,a1,a2,a3,a4,a5,a6,a7,a8,a9,b0,b1,b2,b3,b4,b5,b6,b7,b8,b9
var $async$AD=A.h(function(c1,c2){if(c1===1){t.push(c2)
x=u}for(;;)switch(x){case 0:b3=c0.i(0,"type")
b4=b3==null?null:J.as(b3)
if(b4==null){v=null
x=1
break}if(b4==="GO_BACK"){s.avs()
v=null
x=1
break}r=s.d
if(r==null){v=null
x=1
break}case 3:switch(b4){case"GAME_READY":x=5
break
case"SPIN_RECOVERY_REQUEST":x=6
break
case"SPIN_RETRY_REQUEST":x=7
break
case"SPIN_ACK_REQUEST":x=8
break
case"GO_DEPOSIT":x=9
break
case"GO_WITHDRAW":x=10
break
case"GO_TRANSACTIONS":x=11
break
case"SPIN_REQUEST":x=12
break
case"BALANCE_REQUEST":x=13
break
case"RTP_REQUEST":x=14
break
case"TRANSACTION_REQUEST":x=15
break
default:x=16
break}break
case 5:v=s.vx()
x=1
break
case 6:case 7:case 8:k=s.x
k===$&&A.e()
if(k.f==null){v=null
x=1
break}u=18
x=b4==="SPIN_ACK_REQUEST"?21:22
break
case 21:x=23
return A.c(k.awT(A.bb(c0.i(0,"operationId"))),$async$AD)
case 23:p=A.a_(["type","SPIN_ACK_RESULT"],y.N,y.z)
v=p
x=1
break
case 22:x=24
return A.c(k.Kv(b4==="SPIN_RETRY_REQUEST"?A.bb(c0.i(0,"operationId")):null),$async$AD)
case 24:q=c2
p=A.q(y.N,y.z)
J.dy(p,"type","SPIN_RECOVERY_RESULT")
J.fw(p,q)
v=p
x=1
break
u=2
x=20
break
case 18:u=17
b5=t.pop()
v=A.a_(["type",b4==="SPIN_ACK_REQUEST"?"SPIN_ACK_ERROR":"SPIN_RECOVERY_ERROR","message","\u65cb\u8f49\u7d50\u679c\u5c1a\u672a\u78ba\u8a8d\uff0c\u8acb\u7a0d\u5f8c\u91cd\u65b0\u67e5\u8a62\u3002"],y.N,y.z)
x=1
break
x=20
break
case 17:x=2
break
case 20:x=4
break
case 9:p=s.c
if(p!=null)A.aK(p,!1).f.aM(G.oX,y.X)
v=null
x=1
break
case 10:p=s.c
if(p!=null)A.aK(p,!1).f.aM(M.B9,y.X)
v=null
x=1
break
case 11:p=s.c
if(p!=null)A.aK(p,!1).f.aM(N.qJ,y.X)
v=null
x=1
break
case 12:u=26
p=s.x
p===$&&A.e()
if(p.f!=null)a5=A.a7I(c0.i(0,"betIndex"),4)
else{b3=A.mI(c0.i(0,"betIndex"))
a5=b3==null?null:C.k.dd(b3)}o=a5
a6=A.mI(c0.i(0,"betAmount"))
n=a6==null?null:a6
if(o==null||n==null){p=A.a_(["type","SPIN_ERROR","message","betIndex and betAmount are required"],y.N,y.z)
v=p
x=1
break}b3=r.a
a7=A.b6(c0.i(0,"mode"))
if(a7==null)a7="REAL"
a8=A.b6(c0.i(0,"clientSeed"))
if(c0.i(0,"nonce")==null)a9=null
else a9=p.f!=null?""+A.a7I(c0.i(0,"nonce"),9007199254740991):J.as(c0.i(0,"nonce"))
x=29
return A.c(p.DW(n,o,A.b6(c0.i(0,"clientRoundId")),a8,b3,a7,a9),$async$AD)
case 29:m=c2
l=J.ax(m,"data")
if(J.p(J.ax(m,"success"),!0)&&y.P.b(l)){k=A.q(y.N,y.z)
J.dy(k,"type","SPIN_RESULT")
J.fw(k,l)
v=k
x=1
break}p=J.ax(m,"message")
p=A.a_(["type","SPIN_ERROR","message",J.as(p==null?"spin failed":p)],y.N,y.z)
v=p
x=1
break
u=2
x=28
break
case 26:u=25
b6=t.pop()
j=A.u(b6)
p=s.x
p===$&&A.e()
v=A.a_(["type","SPIN_ERROR","message",p.f!=null?"\u65cb\u8f49\u7d50\u679c\u5c1a\u672a\u78ba\u8a8d\uff0c\u8acb\u5148\u67e5\u8a62\u4e0a\u4e00\u5c40\u3002":J.as(j)],y.N,y.z)
x=1
break
x=28
break
case 25:x=2
break
case 28:x=4
break
case 13:u=31
p=s.x
p===$&&A.e()
x=34
return A.c(p.jU(),$async$AD)
case 34:i=c2
if(J.p(J.ax(i,"success"),!0)){p=y.h
h=p.a(J.ax(i,"data"))
i=h
p=p.a(i==null?null:J.ax(i,"userInfo"))
b0=p==null?h:p
g=b0==null?A.q(y.N,y.z):b0
p=A.mI(J.ax(g,"balance"))
if(p==null)p=null
p=A.a_(["type","BALANCE_RESULT","balance",p==null?0:p],y.N,y.z)
v=p
x=1
break}p=J.ax(i,"message")
p=A.a_(["type","BALANCE_ERROR","message",J.as(p==null?"getCurrentUser failed":p)],y.N,y.z)
v=p
x=1
break
u=2
x=33
break
case 31:u=30
b7=t.pop()
f=A.u(b7)
p=A.a_(["type","BALANCE_ERROR","message",J.as(f)],y.N,y.z)
v=p
x=1
break
x=33
break
case 30:x=2
break
case 33:x=4
break
case 14:u=36
x=39
return A.c(s.Zz(),$async$AD)
case 39:e=c2
if(e!=null){p=A.a_(["type","RTP_RESULT","data",e],y.N,y.z)
v=p
x=1
break}p=A.a_(["type","RTP_ERROR","message","getRtpTable failed"],y.N,y.z)
v=p
x=1
break
u=2
x=38
break
case 36:u=35
b8=t.pop()
d=A.u(b8)
p=A.a_(["type","RTP_ERROR","message",J.as(d)],y.N,y.z)
v=p
x=1
break
x=38
break
case 35:x=2
break
case 38:x=4
break
case 15:u=41
p=A.mI(c0.i(0,"page"))
b1=p==null?null:C.k.dd(p)
a0=b1==null?1:b1
p=A.mI(c0.i(0,"size"))
b2=p==null?null:C.k.dd(p)
a1=b2==null?10:b2
p=s.x
p===$&&A.e()
x=44
return A.c(p.adz(a0,a1),$async$AD)
case 44:a2=c2
if(J.p(J.ax(a2,"success"),!0)){p=A.a_(["type","TRANSACTION_RESULT","data",J.ax(a2,"data")],y.N,y.z)
v=p
x=1
break}p=J.ax(a2,"message")
p=A.a_(["type","TRANSACTION_ERROR","message",J.as(p==null?"getTransactions failed":p)],y.N,y.z)
v=p
x=1
break
u=2
x=43
break
case 41:u=40
b9=t.pop()
a3=A.u(b9)
p=A.a_(["type","TRANSACTION_ERROR","message",J.as(a3)],y.N,y.z)
v=p
x=1
break
x=43
break
case 40:x=2
break
case 43:x=4
break
case 16:v=null
x=1
break
case 4:case 1:return A.j(v,w)
case 2:return A.i(t.at(-1),w)}})
return A.k($async$AD,w)},
q(){var x=this,w=x.y
if(w!=null)w.T(x.gckj())
w=x.y
if(w!=null)w.q()
w=x.p1
if(w!=null)w.$0()
w=x.p2
if(w!=null)w.$0()
if(!x.go)x.Au(!0)
x.a5()},
u(d){var x,w,v,u,t=this,s=null,r=A.f(d,C.c,y.J)
r.toString
if(t.Q){x=t.d
x=x==null?s:x.b
return A.bN(A.kP(s,s,s,!0,!0,s,s,1,s,s,s,!1,s,!1,s,s,s,s,!0,s,s,s,s,s,A.d(x==null?"":x,s,s,s,s,s,s,s,s,s),s,s,s,1,s,!0),s,new A.dA(!0,!0,!0,!0,C.I,!1,A.aM(A.b4(A.w(A.a([A.d(r.gX5(),s,s,s,s,s,s,C.az,s,s),C.a7,A.c6(A.d(r.gyR(),s,s,s,s,s,s,s,s,s),D.c5_,new B.dsi(t,d),s)],y.p),C.l,s,C.e,C.H,0,C.j),C.q,s,C.w,s,s,C.aU,s,s,C.y),s,s,s),s),s,s,s,s,s)}w=t.f
x=t.a.d
if(x!=null){v=t.x
v===$&&A.e()
v=v.f!=null}else v=!1
if(v){r=t.gbwd()
v=t.y
v.toString
return new B.aig(x,r,v,new B.dsj(t),t.gdoF(),s)}x=y.p
v=A.a([],x)
u=w==null
if(!u)C.d.v(v,A.a([w,A.ez(0,A.ie(C.bF,s,C.w,!1,s,s,s,s,s,s,s,s,s,s,s,s,s,s,s,s,s,s,s,t.gbQT(),s,s,s,s,s,s,!1,C.cc),108,s,0,s,s,75)],x))
else v.push(t.cUu(d))
if(u)v.push(new A.dA(!0,!0,!0,!0,C.I,!1,new A.c8(C.hB,s,s,A.aR(s,s,s,s,D.aUh,s,s,t.gbQT(),s,s,s,s,r.giO(),s),s),s))
return A.bN(s,D.ayw,new A.cW(C.aT,s,C.aP,C.q,v,s),s,s,s,s,s)},
cUu(a1){var x,w,v,u,t,s,r,q,p,o,n,m,l,k,j,i,h,g,f,e=this,d=null,a0=A.f(a1,C.c,y.J)
a0.toString
x=e.d
w=e.db
v=e.e
u=w==null
t=(u?d:w.c)===!0
if(e.a.d!=null)if(e.ok==null){s=!0
if(!e.k2)if(!e.id)if(!e.fy)r=t&&e.dy==null
else r=s
else r=s
else r=s
s=r}else s=!1
else s=!1
if(s){u=e.fy?a0.gKt():a0.gWT()
if(e.fy){a0=a0.gKt()
r=A.t(a1).ok.y
a0=new A.J(C.aU,A.d(a0,d,d,d,d,d,r==null?d:r.a0(C.M.B(0.78)),C.az,d,d),d)}else a0=D.bIG
return A.aM(A.Q(d,d,d,a0,!1,d,d,d,!1,d,!1,d,d,d,d,d,d,d,d,d,d,d,u,!0,d,d,d,d,d,d,d,d,d,d,d,d,d,d,d,d,d,d,d,d,d,d,d,d,d,d,d,d,d,C.p,d),d,d,d)}if((u?d:w.f)==null)q=d
else{r=w.f
p=w.d
if(p==null)p=v==null?d:v.d
if(p==null)p=""
q=C.b.F(A.b(r)+" "+p)}o=u?d:w.e
if(o==null)o=v==null?d:v.e
r=u?d:w.d
if(r==null){r=v==null?d:v.d
n=r}else n=r
if(n==null)n=""
m=o==null?d:C.b.F(A.b(o)+" "+n)
if((v==null?d:v.c)===!0)r=(x==null?d:x.gbXO())===!0
else r=!1
p=e.k2
l=e.k3
k=u?d:w.b
u=u?d:w.c
j=e.dy==null
i=e.ok
h=new B.bDd(r,p,l,k===!0,u===!0,!j,i)
g=e.dnX(a0,i)
if(e.fy)f=a0.gKt()
else f=j?d:a0.gamF()
u=x==null?d:x.b
a0=u==null?a0.gamK():u
u=g==null
r=u?f:g
return new B.aH0(a0,h,q,m,r,!u,!t,new B.dro(e,h),new B.drp(e),d)},
dgi(d){var x,w=this
switch(d.a){case 1:x=w.c
x.toString
A.aK(x,!1).f.aM(C.cR,y.X)
return
case 2:w.atQ()
return
case 3:x=w.c
x.toString
A.aK(x,!1).f.aM(G.oX,y.X)
return
case 4:w.vM()
return
case 5:w.AI()
return
case 6:w.bPM()
return
case 0:return}},
atQ(){var x=0,w=A.l(y.H),v,u=this,t
var $async$atQ=A.h(function(d,e){if(d===1)return A.i(e,w)
for(;;)switch(x){case 0:t=u.c
t.toString
x=3
return A.c(A.aK(t,!1).f.aM(C.oz,y.X),$async$atQ)
case 3:if(u.c==null){x=1
break}x=4
return A.c(u.bPM(),$async$atQ)
case 4:case 1:return A.j(v,w)}})
return A.k($async$atQ,w)},
avs(){var x=0,w=A.l(y.H),v,u=this
var $async$avs=A.h(function(d,e){if(d===1)return A.i(e,w)
for(;;)switch(x){case 0:if(u.c==null){x=1
break}x=3
return A.c(u.a_r(),$async$avs)
case 3:case 1:return A.j(v,w)}})
return A.k($async$avs,w)},
a_r(){var x=0,w=A.l(y.H),v,u=this,t
var $async$a_r=A.h(function(d,e){if(d===1)return A.i(e,w)
for(;;)switch(x){case 0:t=u.c
if(t==null){x=1
break}x=!u.go?3:4
break
case 3:x=5
return A.c(u.Au(!0),$async$a_r)
case 5:t=u.c
if(t==null){x=1
break}case 4:x=6
return A.c(A.ac(t,!1).tb(),$async$a_r)
case 6:if(!e&&u.c!=null){t=u.c
t.toString
A.aK(t,!1).f.ie("/home",y.X)}case 1:return A.j(v,w)}})
return A.k($async$a_r,w)},
c8e(){var x,w=this,v=w.d,u=v==null,t=u?null:v.d
if(u||t==null||t.length===0)return C.a9
u=b.G.window.navigator.userAgent
x=$.euw()
if(x.b.test(u)){u=w.x
u===$&&A.e()
u=u.f==null}else u=!1
if(u){$.al.y2$.push(new B.drr(w,v,t))
return C.AB}u=w.ccN(t,Date.now())
x=w.x
x===$&&A.e()
x=x.f!=null?w.as:null
return new B.aiH(u,x,w.gdBS(),null)},
ccN(d,e){var x,w="/games/"+d,v=C.b.t(w,"?")?"&":"?",u=this.x
u===$&&A.e()
x=u.f!=null?"&v2host=1":""
return w+v+"flutter=1"+x+"&_ts="+e},
dBT(){new B.ds7(this).$0()}}
B.aH0.prototype={
u(d){var x=A.f(d,C.c,y.J)
x.toString
return new A.dA(!0,!0,!0,!0,C.I,!1,A.cZ(new B.bDe(this,x,A.t(d),this.d8L(x))),null)},
d8L(d){switch(this.d.gqM().a){case 1:return d.gamI()
case 2:return d.gRe()
case 3:return d.gX1()
case 4:return d.gX0()
case 5:return d.gxf()
case 6:return d.gamH()
case 0:return null}}}
B.alJ.prototype={
u(d){var x=null,w=A.t(d).ok.z,v=w==null,u=v?x:w.a0(C.M.B(0.58))
u=A.O(A.d(this.c,x,x,x,x,x,u,x,x,x),1,x)
v=v?x:w.aX(C.M,C.S)
return new A.J(S.eL,A.z(A.a([u,C.ah,new A.e8(1,C.b6,A.d(this.d,x,x,x,x,x,v,C.jP,x,x),x)],y.p),C.m,x,C.e,C.f,0,x,x),x)}}
B.aH4.prototype={
p(d,e){var x
if(e==null)return!1
if(this!==e)x=e instanceof B.aH4&&e.a===this.a
else x=!0
return x},
gj(d){var x=C.b.gj(this.a)
return x},
l(d){return"GameSessionStartRequest[clientSessionId="+this.a+"]"},
A(){var x=A.q(y.N,y.z)
x.h(0,"clientSessionId",this.a)
return x}}
var z=a.updateTypes(["B<~>()","~()","B<~>(y)","B<a2<n,@>?>(a2<n,@>)"])
B.bDu.prototype={
$1(d){return C.b.ck(C.h.iZ(d,16),2,"0")},
$S:42}
B.dq_.prototype={
$0(){return this.a.ghK()},
$S:1}
B.dq0.prototype={
$1(d){var x=this.a
if(x.ghK())x.tX(x.gbwr())
else x.clA()},
$S:2}
B.dpS.prototype={
$1(d){var x=this.a
if(x.gfe()&&this.b.c!=null)this.b.ho(x)},
$S:2}
B.dpI.prototype={
$0(){var x=this.a
x.at=!0
x.as=!1
x.tM()
x.e=x.x=x.w=x.r=null},
$S:0}
B.dpZ.prototype={
$0(){var x=this.a
x.ax=this.b===C.cy
x.as=!1
x.tM()},
$S:0}
B.dpT.prototype={
$0(){var x=this.a
x.as=!0
x.CW=x.ch=null},
$S:0}
B.dpU.prototype={
$0(){return this.a.cbX(this.b)},
$S:0}
B.dpV.prototype={
$0(){return this.a.as=!1},
$S:0}
B.dpP.prototype={
$0(){return this.a.ghK()},
$S:1}
B.dpQ.prototype={
$0(){return this.a.ghK()},
$S:1}
B.dpR.prototype={
$0(){var x,w,v,u,t=this,s=null,r=t.b,q=t.a
r.e=q.a
r.f=q.b
x=r.r=q.d
r.w=t.c
w=r.x=t.d
v=x==null
u=!0
if((v?s:x.r)===!0)if((v?s:x.y)===!0){if(w==null)x=s
else{x=w.b
x=x==null?s:F.jO.t(0,x.a)}if(x!==!0){x=r.x
w=x==null
if(w)v=s
else{v=x.b
v=v==null?s:v.b}if(v!==!0){if(w)x=s
else{x=x.b
x=x==null?s:x.f}x=x!=null}else x=u}else x=u}else x=u
else x=u
if(x)r.tM()
q=q.c
if(q!=null)r.cbX(q)},
$S:0}
B.dpD.prototype={
$1(d){var x,w,v,u=this,t=null,s=A.f(d,C.c,y.J)
s.toString
x=A.d(u.b,t,t,t,t,t,t,t,t,t)
w=A.d(u.c,t,t,t,t,t,t,t,t,t)
v=u.d
return A.bg(A.a([A.aG(A.d(s.gcr(),t,t,t,t,t,t,t,t,t),t,t,t,new B.dpB(v),t,t),A.c6(A.d(s.gjD(),t,t,t,t,t,t,t,t,t),D.c2s,new B.dpC(u.a,u.e,u.f,v),t)],y.p),t,t,w,t,t,!1,t,x)},
$S:6}
B.dpB.prototype={
$0(){return this.a.af(!1)},
$S:0}
B.dpC.prototype={
$0(){var x=this,w=x.a
if(w.a.e.gN()&&w.ax&&x.b.an().gN()&&x.c===w.ay)x.d.af(!0)},
$S:0}
B.dpA.prototype={
$1(d){return this.cBw(d)},
cBw(d){var x=0,w=A.l(y.H),v,u=2,t=[],s=this,r,q,p,o,n,m,l,k,j,i,h,g,f,e
var $async$$1=A.h(function(a0,a1){if(a0===1){t.push(a1)
x=u}for(;;)switch(x){case 0:h=s.a
g=h.e
f=h.r
if(g!=null)m=h.w==null&&f==null
else m=!0
if(m)throw A.o(new E.a_x())
m=h.w
l=m==null?null:m.a
if(l==null){m=B.ecN()
k=h.a.c
j=g.e
l=E.ecI(f.a,f.z,j,m,k)}r=l
m=h.c
m.toString
m=A.f(m,C.c,y.J)
x=3
return A.c(h.av2(d,m.gOp(),m.ada(r.c+" USDT",r.e)),$async$$1)
case 3:if(!a1){x=1
break}if(!h.ghK()||d!==h.ay)A.U(C.ao)
u=5
x=8
return A.c(g.c_y(r),$async$$1)
case 8:q=a1
if(!h.ghK()||d!==h.ay)A.U(C.ao)
h.n(new B.dpy(h,q))
u=2
x=7
break
case 5:u=4
e=t.pop()
p=A.u(e)
o=A.aO(e)
if(!h.ghK()||d!==h.ay)A.U(C.ao)
x=9
return A.c(g.e6k(),$async$$1)
case 9:n=a1
if(!h.ghK()||d!==h.ay)A.U(C.ao)
h.n(new B.dpz(h,n))
A.zG(p,o)
x=7
break
case 4:x=2
break
case 7:case 1:return A.j(v,w)
case 2:return A.i(t.at(-1),w)}})
return A.k($async$$1,w)},
$S:67}
B.dpy.prototype={
$0(){var x=this.a
x.w=this.b
x.tM()},
$S:0}
B.dpz.prototype={
$0(){var x=this.a
x.w=this.b
x.tM()},
$S:0}
B.dpv.prototype={
$1(d){return this.cBv(d)},
cBv(d){var x=0,w=A.l(y.H),v,u=this,t,s,r
var $async$$1=A.h(function(e,f){if(e===1)return A.i(f,w)
for(;;)switch(x){case 0:t=u.a
s=t.e
r=t.w
if(s==null||r==null){x=1
break}x=3
return A.c(s.dMO(r.a),$async$$1)
case 3:if(!t.ghK()||d!==t.ay)A.U(C.ao)
if(!t.ghK()||d!==t.ay)A.U(C.ao)
t.n(new B.dpu(t))
x=4
return A.c(t.vP(d),$async$$1)
case 4:case 1:return A.j(v,w)}})
return A.k($async$$1,w)},
$S:67}
B.dpu.prototype={
$0(){return this.a.w=null},
$S:0}
B.dpO.prototype={
$1(d){return this.cBz(d)},
cBz(d){var x=0,w=A.l(y.H),v,u=this,t,s,r,q,p,o,n,m,l,k
var $async$$1=A.h(function(e,f){if(e===1)return A.i(f,w)
for(;;)switch(x){case 0:l=u.a
k=l.e
if(k==null)throw A.o(new E.Dm())
t=l.c
t.toString
t=A.f(t,C.c,y.J)
t.toString
x=3
return A.c(k.cy5(),$async$$1)
case 3:s=f
if(!l.ghK()||d!==l.ay)A.U(C.ao)
l.n(new B.dpK(l,s))
r=s==null
if(!r){q=s.b
p=(q==null?null:F.jO.t(0,q.a))!==!0}else p=!1
x=p?4:5
break
case 4:x=6
return A.c(l.av2(d,t.gUZ(),t.gadc()),$async$$1)
case 6:if(!f){x=1
break}case 5:if(r)t=null
else{t=s.b
t=t==null?null:F.jO.t(0,t.a)}x=t===!0?7:8
break
case 7:x=9
return A.c(k.dMN(s.a),$async$$1)
case 9:if(!l.ghK()||d!==l.ay)A.U(C.ao)
case 8:if(p)o=s.a
else{t=B.ecN()
r=l.a.c
q=k.e
t=E.e6f(t)
r=E.wm(r)
o=new E.acx(t,E.dOg(q),r)}if(!l.ghK()||d!==l.ay)A.U(C.ao)
l.n(new B.dpL(l,o))
x=10
return A.c(k.e1d(o,p),$async$$1)
case 10:n=f
if(!l.ghK()||d!==l.ay)A.U(C.ao)
l.n(new B.dpM(l,n))
t=l.z
if(t!=null)t.a7()
m=n.b.dt(new A.aH(Date.now(),0,!1).a3())
t=m.a<0?C.b_:m
l.z=A.du(t,new B.dpN(l,n))
case 1:return A.j(v,w)}})
return A.k($async$$1,w)},
$S:67}
B.dpK.prototype={
$0(){this.a.x=this.b},
$S:0}
B.dpL.prototype={
$0(){var x=this.a
x.tM()
x.x=new E.M9(this.b,null)},
$S:0}
B.dpM.prototype={
$0(){return this.a.y=this.b},
$S:0}
B.dpN.prototype={
$0(){var x=this.a
if(x.ghK()&&x.y===this.b)x.n(new B.dpJ(x))},
$S:0}
B.dpJ.prototype={
$0(){var x=this.a
x.tM()
x.ch=D.Li},
$S:0}
B.dpH.prototype={
$1(d){return this.cBy(d)},
cBy(d){var x=0,w=A.l(y.H),v,u=this,t,s,r,q,p,o,n
var $async$$1=A.h(function(e,f){if(e===1)return A.i(f,w)
for(;;)switch(x){case 0:p=u.a
o=p.e
n=p.y
if(o==null||n==null)throw A.o(new E.Dm())
x=3
return A.c(p.vP(d),$async$$1)
case 3:if(!p.ghK()||d!==p.ay)A.U(C.ao)
t=p.x
s=t==null?null:t.b
if(p.y!==n||s==null||s.a!=="ACTIVE"||s.b||s.f!=null||!s.c.ia(new A.aH(Date.now(),0,!1).a3())||!n.b.ia(new A.aH(Date.now(),0,!1).a3())){if(!p.ghK()||d!==p.ay)A.U(C.ao)
p.n(new B.dpG(p,t))
x=1
break}if(!p.ghK()||d!==p.ay)A.U(C.ao)
p.n(p.gc9c())
p.a.toString
r=A.uw(n.a,C.lK,"_self")
x=4
return A.c(r,$async$$1)
case 4:q=f
if(!p.ghK()||d!==p.ay)A.U(C.ao)
if(!q)throw A.o(new E.v9())
x=5
return A.c(p.vP(d),$async$$1)
case 5:case 1:return A.j(v,w)}})
return A.k($async$$1,w)},
$S:67}
B.dpG.prototype={
$0(){var x=this.a
x.tM()
x.x=this.b
if(x.gbLW()==null&&x.gcbg()==null)x.ch=D.Li},
$S:0}
B.dpF.prototype={
$1(d){return this.cBx(d)},
cBx(d){var x=0,w=A.l(y.H),v,u=this,t,s,r,q
var $async$$1=A.h(function(e,f){if(e===1)return A.i(f,w)
for(;;)switch(x){case 0:s=u.a
r=s.e
q=s.x
if(r==null||q==null){x=1
break}x=3
return A.c(r.dXA(q.a),$async$$1)
case 3:t=f
if(!s.ghK()||d!==s.ay)A.U(C.ao)
s.n(new B.dpE(s,q,t))
case 1:return A.j(v,w)}})
return A.k($async$$1,w)},
$S:67}
B.dpE.prototype={
$0(){var x=this.a
x.tM()
x.x=new E.M9(this.b.a,this.c)},
$S:0}
B.dpW.prototype={
$0(){return this.a.a0q(C.oz)},
$S:3}
B.dpX.prototype={
$0(){return this.a.a0q(G.oX)},
$S:3}
B.dpY.prototype={
$0(){var x=this.a;++x.ay
x.tM()
x.a.e4F()},
$S:0}
B.dpw.prototype={
$0(){this.a.$0()
return null},
$S:0}
B.dpx.prototype={
$0(){this.a.$0()
return null},
$S:0}
B.dUi.prototype={
$1(d){var x,w=this,v=A.iz(d,"MessageEvent")
if(!v)return
if(!J.p(d.origin,w.a))return
v=w.b.$0()
if(J.p(v,!1)||!B.e5j(d,w.c))return
x=A.GJ(d.data)
if(y.f.b(x)&&J.p(x.i(0,"action"),"slotGameGoBack"))w.d.$0()},
$S:10}
B.dUh.prototype={
$0(){return b.G.window.removeEventListener("message",this.a)},
$S:0}
B.dUj.prototype={
$0(){if(this.a.a){var x=this.b.$0()
if(x==null)x=!0}else x=!1
return x},
$S:1}
B.dUl.prototype={
$1(d){var x,w,v,u,t,s,r=this,q=A.iz(d,"MessageEvent")
if(!q)return
q=r.a
if(!J.p(d.origin,q))return
x=r.b
if(!x.$0()||!B.e5j(d,r.c))return
w=A.GJ(d.data)
if(!y.f.b(w))return
v=A.q(y.N,y.z)
for(u=w.gei(),u=u.gap(u);u.G();){t=u.gP()
s=t.a
if(typeof s=="string")v.h(0,s,t.b)}if(!v.ao("type"))return
new B.dUm(r.d,v,x,d,r.c,q).$0()},
$S:10}
B.dUm.prototype={
$0(){var x=0,w=A.l(y.a),v,u=2,t=[],s=this,r,q,p,o,n,m,l,k,j,i
var $async$$0=A.h(function(d,e){if(d===1){t.push(e)
x=u}for(;;)switch(x){case 0:u=4
m=s.b
l=s.a.$1(m)
x=7
return A.c(y.u.b(l)?l:A.fX(l,y.h),$async$$0)
case 7:r=e
if(r!=null&&s.c.$0()&&B.e5j(s.d,s.e)){q=m.i(0,"requestId")
p=A.ho(r,y.N,y.z)
if(typeof q=="string"&&q.length!==0&&q.length<=128)J.dy(p,"requestId",q)
o=A.bK(p)
p=s.e
if(p!=null){B.dPg(o,s.f,p)
x=1
break}n=s.d.source
p=n!=null&&n!=null&&A.iz(n,"Object")
k=s.f
if(p){A.DD(n,"postMessage",o,k,y.X)
B.dPg(o,k,null)}else{B.dPg(o,k,null)
b.G.window.postMessage(o,k)}}u=2
x=6
break
case 4:u=3
i=t.pop()
x=6
break
case 3:x=2
break
case 6:case 1:return A.j(v,w)
case 2:return A.i(t.at(-1),w)}})
return A.k($async$$0,w)},
$S:52}
B.dUk.prototype={
$0(){this.a.a=!1
b.G.window.removeEventListener("message",this.b)},
$S:0}
B.drm.prototype={
$1(d){return this.a.$0()},
$S:10}
B.drn.prototype={
$1(d){var x=this.a.e
x===$&&A.e()
return x},
$S:621}
B.dsl.prototype={
$0(){return this.a.gh7()},
$S:1}
B.dsm.prototype={
$0(){return this.a.gh7()},
$S:1}
B.dsn.prototype={
$0(){var x=this.a,w=x.x
w===$&&A.e()
if(w.f!=null)x=x.gEM()
else x=x.gh7()&&x.ghy()
return x},
$S:1}
B.dso.prototype={
$1(d){var x=this.a,w=x.x
w===$&&A.e()
if(w.f!=null)w=x.gEM()
else w=x.gh7()&&x.ghy()
if(w)x.Zl()},
$S:2}
B.dsk.prototype={
$1(d){return this.a.ckk()},
$S:2}
B.ds6.prototype={
$0(){var x=this.a
x.Q=!0
x.f=x.CW=null},
$S:0}
B.drG.prototype={
$0(){return this.a.CW=this.b},
$S:0}
B.drH.prototype={
$0(){return this.a.CW=0},
$S:0}
B.drq.prototype={
$0(){return this.b.CW=this.a.a},
$S:0}
B.drI.prototype={
$0(){return null},
$S:16}
B.drF.prototype={
$0(){var x=A.mI(this.b.i(0,"balance"))
if(x==null)x=null
return this.a.CW=x},
$S:0}
B.drN.prototype={
$0(){var x=this.a
x.k2=!1
x.e=this.b
x.d=null
x.ok=D.hb},
$S:0}
B.drO.prototype={
$0(){var x=this.a,w=x.e=this.b
x.d=new A.AQ(w.b,w.gctM(),"Telegram Mini App",null,C.iS,4279724935,"\ud83c\udfae",null,!1)
x.k2=!0
x.ok=null},
$S:0}
B.drP.prototype={
$0(){var x=this.a
x.k2=!1
x.d=x.e=null
x.ok=x.buL(this.b,D.jl)},
$S:0}
B.drQ.prototype={
$0(){var x=this.a
x.k2=!1
x.d=x.e=null
x.ok=D.jl},
$S:0}
B.drs.prototype={
$0(){var x=this.a
x.k2=!1
if(this.b==null)x.ok=D.hb},
$S:0}
B.drt.prototype={
$0(){var x=this.a
x.k2=!1
x.db=null
x.ok=D.hb},
$S:0}
B.dru.prototype={
$0(){var x=this.a
x.k2=!0
x.fr=x.dy=x.ok=null
x.id=x.go=x.fy=!1},
$S:0}
B.drv.prototype={
$0(){var x=this.a
x.k2=!1
x.ok=D.jk},
$S:0}
B.drw.prototype={
$0(){var x=this.a
x.k2=!1
x.ok=D.jk},
$S:0}
B.drx.prototype={
$0(){var x=this.a
x.k2=!1
x.db=null
x.ok=this.b==null?D.jl:D.hb},
$S:0}
B.dry.prototype={
$0(){var x,w=this.a
w.k2=!1
x=this.b
w.ok=x==null?D.jl:x},
$S:0}
B.drz.prototype={
$0(){var x=this.a
x.k2=!1
x.ok=this.b?null:D.is},
$S:0}
B.drA.prototype={
$0(){var x,w,v=this.a
v.k2=!1
x=this.b
w=v.cfx(x.r)
if(w==null)x=x.b===!0?null:D.jl
else x=w
v.ok=x},
$S:0}
B.drB.prototype={
$0(){var x=this.a
x.k2=!1
x.ok=x.buL(this.b,D.jl)},
$S:0}
B.drC.prototype={
$0(){var x=this.a
x.k2=!1
x.ok=D.jl},
$S:0}
B.drY.prototype={
$0(){return this.a.ok=D.hb},
$S:0}
B.drZ.prototype={
$0(){return this.a.ok=D.hb},
$S:0}
B.ds_.prototype={
$0(){var x=this.a
x.k3=!0
x.ok=null},
$S:0}
B.ds0.prototype={
$0(){var x=this.a
x.k3=!1
x.ok=D.jk},
$S:0}
B.ds1.prototype={
$0(){var x=this.a
x.k3=!1
x.ok=D.jk},
$S:0}
B.ds2.prototype={
$0(){return this.a.k3=!1},
$S:0}
B.ds3.prototype={
$0(){var x,w=this.a
w.k3=!1
x=this.b
w.ok=(x==null?null:x.b)===C.Rh?D.tg:D.EP},
$S:0}
B.ds4.prototype={
$0(){var x=this.a
x.k3=!1
x.ok=this.b},
$S:0}
B.ds5.prototype={
$0(){var x=this.a
x.k3=!1
x.ok=D.xr},
$S:0}
B.ds9.prototype={
$0(){var x=this.a
x.k3=x.k2=!1
x.fr=x.dy=null
x.ok=D.is},
$S:0}
B.dsa.prototype={
$0(){var x=this.a
x.k2=!0
x.k3=!1
x.fr=x.dy=x.ok=null},
$S:0}
B.dsb.prototype={
$0(){var x=this.a
x.k2=!1
x.ok=D.jk},
$S:0}
B.dsc.prototype={
$0(){var x=this.a
x.k2=!1
x.ok=D.is},
$S:0}
B.dsd.prototype={
$0(){var x=this.a
x.k2=!1
x.fr=x.dy=x.dx=null
x.ok=D.is},
$S:0}
B.dse.prototype={
$0(){var x=this.a
x.dy=this.b
x.fr=this.c
x.k2=x.go=x.fy=!1},
$S:0}
B.dsf.prototype={
$0(){var x=this.a
x.f=x.c8e()
x.k2=!1},
$S:0}
B.dsg.prototype={
$0(){var x=this.a
x.k2=!1
x.ok=x.buL(this.b,D.is)},
$S:0}
B.dsh.prototype={
$0(){var x=this.a
x.k2=!1
x.ok=D.is},
$S:0}
B.drR.prototype={
$0(){return this.a.id=!0},
$S:0}
B.drS.prototype={
$0(){var x=this.a
x.fr=x.dy=null
x.id=x.go=x.fy=!1
x.ok=D.is},
$S:0}
B.drT.prototype={
$0(){var x=this.a
x.fr=x.dy=null
x.id=x.go=x.fy=!1
x.ok=D.jk},
$S:0}
B.drU.prototype={
$0(){var x=this.a
x.fr=x.dy=null
x.id=x.go=x.fy=!1
x.ok=D.jk},
$S:0}
B.drV.prototype={
$0(){var x=this.a
x.fr=x.dy=null
x.go=!0},
$S:0}
B.drW.prototype={
$0(){var x=this.a
x.fy=!0
x.id=!1},
$S:0}
B.drX.prototype={
$0(){var x=this.a
x.fr=x.dy=null
x.id=x.go=x.fy=!1
x.ok=D.is},
$S:0}
B.drJ.prototype={
$0(){return this.a.cgN("game-access")},
$S:27}
B.drK.prototype={
$2(d,e){return $.iN().m(C.t,"game access purchase attempt persistence unavailable",d,e)},
$S:40}
B.drD.prototype={
$2(d,e){return $.iN().m(C.t,"game access purchase attempt cleanup unavailable",d,e)},
$S:40}
B.drL.prototype={
$0(){return this.a.cgN("game-session")},
$S:27}
B.drM.prototype={
$2(d,e){return $.iN().m(C.t,"game session attempt persistence unavailable",d,e)},
$S:40}
B.drE.prototype={
$2(d,e){return $.iN().m(C.t,"game session attempt cleanup unavailable",d,e)},
$S:40}
B.dsi.prototype={
$0(){if(this.a.gh7())A.aK(this.b,!1).f.gkX().hV(0,A.a([A.ip(null,null)],y.Q))},
$S:0}
B.dsj.prototype={
$0(){return this.a.gh7()},
$S:1}
B.dro.prototype={
$0(){return this.a.dgi(this.b.gqM())},
$S:0}
B.drp.prototype={
$0(){this.a.bPM()
return null},
$S:0}
B.drr.prototype={
$1(d){return this.cBA(d)},
cBA(a0){var x=0,w=A.l(y.H),v,u=2,t=[],s=this,r,q,p,o,n,m,l,k,j,i,h,g,f,e,d
var $async$$1=A.h(function(a1,a2){if(a1===1){t.push(a2)
x=u}for(;;)switch(x){case 0:g=s.a
if(!(g.gh7()&&g.ghy())){x=1
break}u=4
x=7
return A.c(g.w.iv(),$async$$1)
case 7:l=a2
r=l==null?"":l
if(!(g.gh7()&&g.ghy()))A.U(C.ao)
k=g.CW
j=k==null
q=j?0:k
x=j?8:9
break
case 8:u=11
x=14
return A.c(g.r.ii(!0),$async$$1)
case 14:p=a2
if(!(g.gh7()&&g.ghy()))A.U(C.ao)
j=p
k=j==null?null:j.f
q=k==null?0:k
u=4
x=13
break
case 11:u=10
f=t.pop()
o=A.u(f)
if(!(g.gh7()&&g.ghy()))A.U(C.ao)
$.iN().m(C.t,"mobile fallback getProfile failed",o,null)
x=13
break
case 10:x=4
break
case 13:case 9:if(!(g.gh7()&&g.ghy()))A.U(C.ao)
j=b.G
j.window.localStorage.setItem("_flutter_game_jwt",r)
h=J.a7Y(q,4)
if(!(g.gh7()&&g.ghy()))A.U(C.ao)
j.window.localStorage.setItem("_flutter_game_balance",h)
h=g.x
h===$&&A.e()
h=h.brB()
if(!(g.gh7()&&g.ghy()))A.U(C.ao)
j.window.localStorage.setItem("_flutter_game_api_base",h)
if(!(g.gh7()&&g.ghy()))A.U(C.ao)
j.window.localStorage.setItem("_flutter_game_id",s.b.a)
u=16
x=19
return A.c(g.Zz(),$async$$1)
case 19:u=4
x=18
break
case 16:u=15
e=t.pop()
n=A.u(e)
$.iN().m(C.aK,"RTP prefetch failed",n,null)
x=18
break
case 15:x=4
break
case 18:u=2
x=6
break
case 4:u=3
d=t.pop()
m=A.u(d)
if(!(g.gh7()&&g.ghy())){x=1
break}$.iN().m(C.t,"mobile postFrame slot game prep failed",m,null)
x=6
break
case 3:x=2
break
case 6:if(g.c!=null)j=!(g.gh7()&&g.ghy())
else j=!0
if(j){x=1
break}j=g.c
j.toString
x=20
return A.c(A.ac(j,!1).tb(),$async$$1)
case 20:if(!g.ghy()){x=1
break}g=g.ccN(s.c,Date.now())
b.G.window.location.assign(g)
case 1:return A.j(v,w)
case 2:return A.i(t.at(-1),w)}})
return A.k($async$$1,w)},
$S:596}
B.ds7.prototype={
$0(){var x=0,w=A.l(y.a),v=1,u=[],t=this,s,r,q,p,o,n
var $async$$0=A.h(function(d,e){if(d===1){u.push(e)
x=v}for(;;)switch(x){case 0:v=3
p=t.a
x=6
return A.c(p.vx(),$async$$0)
case 6:s=e
r=new B.ds8(p,s)
r.$0()
p=y.H
x=7
return A.c(A.eM(D.aKA,null,p),$async$$0)
case 7:r.$0()
x=8
return A.c(A.eM(D.aKi,null,p),$async$$0)
case 8:r.$0()
v=1
x=5
break
case 3:v=2
n=u.pop()
q=A.u(n)
$.iN().m(C.aK,"Game host initialization unavailable: "+J.ab(q).l(0),null,null)
x=5
break
case 2:x=1
break
case 5:return A.j(null,w)
case 1:return A.i(u.at(-1),w)}})
return A.k($async$$0,w)},
$S:52}
B.ds8.prototype={
$0(){var x,w=this.a,v=w.x
v===$&&A.e()
if(v.f!=null)x=w.gEM()
else x=w.gh7()&&w.ghy()
if(!x)return
w=v.f!=null?w.as:null
B.eq7(this.b,w)},
$S:0}
B.bDe.prototype={
$2(d,e){var x,w,v,u,t,s,r,q,p,o,n,m,l=this,k=null,j=e.d,i=j<1/0?C.k.dh(j-88,0,1/0):0
j=l.b
x=l.a
w=x.c
v=j.amD(w)
u=A.G(8)
t=A.aN(C.M.B(0.12),C.u,1)
s=l.c.ok
r=s.f
q=y.p
r=A.a([A.d(w,k,k,k,k,k,r==null?k:r.aX(C.M,C.F),C.az,k,k)],q)
if(x.x){w=j.gKs()
p=s.z
w=A.a([H.dY,A.d(w,k,k,k,k,k,p==null?k:p.a0(C.M.B(0.72)),C.az,k,k)],q)
p=x.e
o=p==null
if(!o||x.f!=null){n=j.gX3()
if(o)p="-"
o=j.gWZ()
m=x.f
if(m==null)m="-"
C.d.v(w,A.a([I.Jp,new B.alJ(n,p,k),new B.alJ(o,m,k)],q))}C.d.v(r,w)}w=x.r
if(w!=null){s=s.z
if(s==null)s=k
else s=s.a0(x.w?D.ax9:D.axX)
C.d.v(r,A.a([I.Jp,A.Q(k,k,k,A.d(w,k,k,k,k,k,s,C.az,k,k),!1,k,k,k,!1,k,!1,k,k,k,k,k,k,k,k,k,k,D.c3i,w,!0,k,k,k,k,k,k,k,k,k,k,k,k,k,k,k,k,k,k,k,k,k,k,k,k,k,k,k,k,k,C.p,k)],q))}w=x.d
s=!w.b
if(!s||w.c||l.d!=null){p=!s||w.c?k:x.y
if(!s||w.c)o=A.bi(C.le,A.a([C.mp,A.d(w.c?j.gamE():j.gWT(),k,k,k,k,k,k,C.az,k,k)],q),C.bx,k,6,10)
else{o=l.d
o.toString
o=A.d(o,k,k,k,k,k,k,C.az,k,k)}C.d.v(r,A.a([D.bII,A.c6(o,D.bZW,p,k)],q))}if(w.a)w=!(!s||w.c)&&!w.f&&w.gqM()!==D.ti
else w=!1
if(w)C.d.v(r,A.a([H.dY,A.aG(A.d(j.gamG(),k,k,k,k,k,k,C.az,k,k),D.c_i,k,k,x.z,k,k)],q))
return A.b4(new A.ba(new A.ay(0,1/0,i,1/0),A.aM(A.Q(k,k,k,new A.ba(K.Na,new A.cb(new A.R(D.auk,k,t,u,k,k,C.r),C.at,new A.J(C.aU,A.w(r,C.a8,k,C.e,C.H,0,C.j),k),k),k),!0,k,k,k,!1,k,!1,k,k,k,k,k,k,k,k,k,k,D.c6Z,v,k,k,k,k,k,k,k,k,k,k,k,k,k,k,k,k,k,k,k,k,k,k,k,k,k,k,k,k,k,k,C.p,k),k,k,k),k),C.q,k,C.w,k,k,D.aM_,k,k,C.y)},
$S:102};(function installTearOffs(){var x=a._instance_0u,w=a._instance_1u
var v
x(v=B.atK.prototype,"gc9c","tM",1)
x(v,"gclz","clA",1)
x(v,"gdC7","dC8",0)
w(v,"gbwr","vP",2)
x(v,"gc8j","cZj",0)
x(v,"gcRJ","cRK",0)
x(v,"gcil","duI",0)
x(v,"gdC5","dC6",0)
x(v,"gdC2","dC3",0)
x(v=B.au_.prototype,"gckj","ckk",1)
w(v,"gdhp","bug",3)
x(v,"gbQT","avs",0)
x(v,"gdoF","a_r",0)
x(v,"gdBS","dBT",1)})();(function inheritance(){var x=a.mixin,w=a.inheritMany,v=a.inherit
w(A.bu,[B.bDu,B.dq0,B.dpS,B.dpD,B.dpA,B.dpv,B.dpO,B.dpH,B.dpF,B.dUi,B.dUl,B.drm,B.drn,B.dso,B.dsk,B.drr])
w(A.eB,[B.pR,B.Dn,B.aH_,B.NC])
w(A.A,[B.bDd,B.aH4])
w(A.L,[B.aig,B.aiH,B.Fa])
w(A.S,[B.bfm,B.bbc,B.au_])
v(B.atK,B.bfm)
w(A.bt,[B.dq_,B.dpI,B.dpZ,B.dpT,B.dpU,B.dpV,B.dpP,B.dpQ,B.dpR,B.dpB,B.dpC,B.dpy,B.dpz,B.dpu,B.dpK,B.dpL,B.dpM,B.dpN,B.dpJ,B.dpG,B.dpE,B.dpW,B.dpX,B.dpY,B.dpw,B.dpx,B.dUh,B.dUj,B.dUm,B.dUk,B.dsl,B.dsm,B.dsn,B.ds6,B.drG,B.drH,B.drq,B.drI,B.drF,B.drN,B.drO,B.drP,B.drQ,B.drs,B.drt,B.dru,B.drv,B.drw,B.drx,B.dry,B.drz,B.drA,B.drB,B.drC,B.drY,B.drZ,B.ds_,B.ds0,B.ds1,B.ds2,B.ds3,B.ds4,B.ds5,B.ds9,B.dsa,B.dsb,B.dsc,B.dsd,B.dse,B.dsf,B.dsg,B.dsh,B.drR,B.drS,B.drT,B.drU,B.drV,B.drW,B.drX,B.drJ,B.drL,B.dsi,B.dsj,B.dro,B.drp,B.ds7,B.ds8])
w(A.c9,[B.drK,B.drD,B.drM,B.drE,B.bDe])
w(A.x,[B.aH0,B.alJ])
x(B.bfm,A.eu)})()
A.b0(b.typeUniverse,JSON.parse('{"aig":{"L":[],"m":[]},"atK":{"S":["aig"],"eu":[]},"aiH":{"L":[],"m":[]},"bbc":{"S":["aiH"]},"Fa":{"L":[],"m":[]},"au_":{"S":["Fa"]},"aH0":{"x":[],"m":[]},"alJ":{"x":[],"m":[]}}'))
var y=(function rtii(){var x=A.C
return{J:x("bw"),u:x("B<a2<n,@>?>"),T:x("Do"),w:x("lM"),Q:x("v<bV<A?>>"),s:x("v<n>"),p:x("v<m>"),P:x("a2<n,@>"),f:x("a2<@,@>"),a:x("b8"),A:x("Mk"),N:x("n"),x:x("UQ"),r:x("fu"),E:x("ec"),O:x("H<n>"),y:x("F"),z:x("@"),S:x("y"),h:x("a2<n,@>?"),X:x("A?"),H:x("~")}})();(function constants(){D.auk=new A.a3(1,0.08235294117647059,0.08235294117647059,0.15294117647058825,C.A)
D.ax9=new A.a3(1,1,0.7686274509803922,0.7686274509803922,C.A)
D.axX=new A.a3(1,0.7215686274509804,0.9490196078431372,0.8156862745098039,C.A)
D.ayw=new A.a3(1,0.0196078431372549,0.00784313725490196,0.09411764705882353,C.A)
D.aKi=new A.bG(175e4)
D.aKA=new A.bG(75e4)
D.aM_=new A.ar(20,64,20,24)
D.Ra=new B.aH_(0,"purchase")
D.aPN=new B.aH_(1,"session")
D.jk=new B.pR(0,"signInRequired")
D.td=new B.pR(1,"telegramAccountNotLinked")
D.jl=new B.pR(10,"requestFailed")
D.xr=new B.pR(11,"purchaseFailed")
D.is=new B.pR(12,"sessionFailed")
D.te=new B.pR(2,"insufficientBalance")
D.tf=new B.pR(3,"walletInactive")
D.tg=new B.pR(4,"refundPending")
D.th=new B.pR(5,"accessExpired")
D.xs=new B.pR(6,"accessRequired")
D.hb=new B.pR(7,"gameUnavailable")
D.EP=new B.pR(8,"accessNotActive")
D.Rb=new B.pR(9,"sessionDenied")
D.Rc=new B.Dn(0,"none")
D.aPO=new B.Dn(1,"signIn")
D.aPP=new B.Dn(2,"bindTelegram")
D.aPQ=new B.Dn(3,"topUp")
D.aPR=new B.Dn(4,"purchase")
D.aPS=new B.Dn(5,"openGame")
D.ti=new B.Dn(6,"retry")
D.aUh=new A.at(C.kr,null,C.M,null,null)
D.bsg=new A.J(C.X,C.bV,null)
D.atu=new A.o2(2.5,null,null,null,null,null,null,null,null,null)
D.bIG=new A.ad(28,28,D.atu,null)
D.bII=new A.ad(null,22,null,null)
D.bZW=new A.H("slot-game-access-primary",y.O)
D.c_i=new A.H("slot-game-access-refresh",y.O)
D.c2s=new A.H("gameV2Confirm",y.O)
D.c2t=new A.H("gameV2Message",y.O)
D.c2u=new A.H("gameV2Page",y.O)
D.c3i=new A.H("slot-game-access-message",y.O)
D.c5_=new A.H("retiredSlotHome",y.O)
D.c6Z=new A.H("slot-game-access-gate",y.O)
D.ahi=new B.NC(0,"request")
D.ahj=new B.NC(1,"pending")
D.ahk=new B.NC(2,"launchPending")
D.ahl=new B.NC(3,"storage")
D.Lh=new B.NC(4,"unavailable")
D.Li=new B.NC(5,"expired")})();(function staticFields(){$.acv=function(){var x=y.N
return A.q(x,x)}()})();(function lazyInitializers(){var x=a.lazyFinal
x($,"fcJ","euw",()=>A.az("Mobi|Android|iPhone|iPad|iPod",!1,!1,!1,!1))
x($,"fdT","iN",()=>A.b7("SlotGamePage"))})()};
(a=>{a["QiElsHVCTzp0VGEcf4Uif9k5GtE="]=a.current})($__dart_deferred_initializers__);