((a,b)=>{a[b]=a[b]||{}})(self,"$__dart_deferred_initializers__")
$__dart_deferred_initializers__.current=function(a,b,c,$){var A,B
A=c[0]
B=c[509]
var z=a.updateTypes([]);(function constants(){B.xA=new A.a0(57857,"MaterialIcons",!1)})()};
(a=>{a["NoxtpMhmtmLLcpbwvAsxx51ec+A="]=a.current})($__dart_deferred_initializers__);