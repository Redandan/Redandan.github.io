((a,b)=>{a[b]=a[b]||{}})(self,"$__dart_deferred_initializers__")
$__dart_deferred_initializers__.current=function(a,b,c,$){var A,B,C
A=c[0]
B=c[2]
C=c[630]
var z=a.updateTypes([]);(function constants(){C.Ji=new A.ag(!0,null,null,null,null,null,13,B.B,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null)})()};
(a=>{a["/xxJkKyKwaRjHvENVsKE/dmBiFQ="]=a.current})($__dart_deferred_initializers__);