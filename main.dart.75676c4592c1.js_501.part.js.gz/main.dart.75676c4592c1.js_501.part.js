((a,b)=>{a[b]=a[b]||{}})(self,"$__dart_deferred_initializers__")
$__dart_deferred_initializers__.current=function(a,b,c,$){var A,C,E,F,G,H,I,K,L,M,N,O,P,B={
eHW(){return new B.S2(null)},
epb(d){var x=A.f(d,C.c,y.F)
return A.a([new B.nS(K.lF,x.gb0l(),x.gb0k(),D.bc1),new B.nS(C.c_,x.gb0B(),x.gb0A(),D.bf5),new B.nS(C.y7,x.gb0n(),x.gb0m(),D.b8z),new B.nS(C.pv,x.gb0j(),x.gb0i(),D.b85),new B.nS(C.c0,x.gb0z(),x.gb0y(),D.b9S),new B.nS(C.lC,x.gb0F(),x.gb0E(),D.bdm),new B.nS(N.iw,x.gb0s(),x.gb0r(),D.b_e)],y.n)},
epL(d){var x=A.f(d,C.c,y.F)
return A.a([new B.nS(D.aSl,x.gaEV(),x.gaEU(),D.bfK),new B.nS(C.SH,x.gaF0(),x.gaF_(),D.bfY),new B.nS(Q.FK,x.gaET(),x.gaES(),D.bex),new B.nS(C.da,x.gb0u(),x.gb0t(),D.b8y),new B.nS(R.FS,x.gaEX(),x.gaEW(),D.be8),new B.nS(E.T8,x.gaER(),x.gaEQ(),D.b2F),new B.nS(D.aU6,x.gaEZ(),x.gaEY(),D.b_S)],y.n)},
S2:function S2(d){this.a=d},
bNm:function bNm(d,e){this.a=d
this.b=e},
bNn:function bNn(d){this.a=d},
bNo:function bNo(d){this.a=d},
nS:function nS(d,e,f,g){var _=this
_.a=d
_.b=e
_.c=f
_.d=g},
avq:function avq(d,e,f,g,h,i){var _=this
_.c=d
_.d=e
_.e=f
_.f=g
_.r=h
_.a=i},
bcZ:function bcZ(d,e){this.c=d
this.a=e},
bd_:function bd_(d,e){this.c=d
this.a=e},
dEE:function dEE(){}},D,Q,R
A=c[0]
C=c[2]
E=c[602]
F=c[599]
G=c[596]
H=c[585]
I=c[597]
K=c[407]
L=c[280]
M=c[483]
N=c[472]
O=c[271]
P=c[584]
B=a.updateHolder(c[43],B)
D=c[598]
Q=c[600]
R=c[601]
B.S2.prototype={
bsU(d){return this.d3m(d)},
d3m(d){var x=0,w=A.l(y.v),v,u=this,t
var $async$bsU=A.h(function(e,f){if(e===1)return A.i(f,w)
for(;;)switch(x){case 0:t=A.f(d,C.c,y.F)
t.toString
x=3
return A.c(A.j7(new A.iy(u.cZY(d))),$async$bsU)
case 3:if(d.e==null){x=1
break}A.a7(d,t.gb0p(),C.Z,null)
case 1:return A.j(v,w)}})
return A.k($async$bsU,w)},
cZY(d){var x,w,v,u,t,s=A.f(d,C.c,y.F)
s.toString
x=A.P(B.epb(d),y.E)
C.d.v(x,B.epL(d))
w=s.ga7A()+"\n"+(s.ga7z()+"\n")+"\n"
for(v=x.length,u=0;u<x.length;x.length===v||(0,A.a6)(x),++u){t=x[u]
w=w+(t.b+":\n")+(C.d.b6(t.d,", ")+"\n")+"\n"}s=w+"\n"+(s.ga2h()+"\n")+("- "+s.ga2f()+"\n")+("- "+s.ga2e()+"\n")+("- "+s.ga2i()+"\n")+("- "+s.ga2g()+"\n")+("- "+s.ga2j()+"\n")+"\n"+(s.gaEA()+"\n")+("- "+s.gaEv()+"\n")+("- "+s.gaEw()+"\n")+("- "+s.gaEx()+"\n")+("- "+s.gaEz()+"\n")+("- "+s.gaEy()+"\n")
return C.b.F(s.charCodeAt(0)==0?s:s)},
u(d){var x=null,w=A.f(d,C.c,y.F),v=w.ga7A(),u=w.ga7z(),t=y.u
return O.LZ(A.a([A.bJ(H.Gl,x,A.d(w.gb0q(),x,x,x,x,x,x,x,x,x),new B.bNm(this,d),x),A.cf(I.TZ,x,A.d(w.gb0o(),x,x,x,x,x,x,x,x,x),new B.bNn(d),x)],t),A.a([new B.avq(w.gb0w(),w.gb0v(),C.js,B.epb(d),x,x),C.a7,new B.avq(w.gb0D(),w.gb0C(),C.fd,B.epL(d),new A.c9(C.bX,x,x,A.ei(D.aUJ,x,A.d(w.gb0x(),x,x,x,x,x,x,x,x,x),new B.bNo(d),x),x),x)],t),P.Sv,x,x,u,v)}}
B.nS.prototype={}
B.avq.prototype={
u(d){var x,w,v,u=this,t=y.u,s=A.a([],t)
for(x=u.f,w=0;w<7;++w){v=A.a([new B.bcZ(x[w],null)],t)
if(w!==6)v.push(C.v)
C.d.v(s,v)}x=u.r
if(x!=null)C.d.v(s,A.a([C.n,x],t))
return new L.iX(u.c,A.w(s,C.m,null,C.e,C.f,0,C.j),u.e,u.d,null)}}
B.bcZ.prototype={
u(d){var x,w,v,u,t,s,r,q,p,o=null,n=A.t(d),m=n.ax,l=m.p2
if(l==null)l=m.k2
x=A.G(8)
w=m.ry
if(w==null){w=m.E
if(w==null)w=m.k3}w=A.aN(w.B(0.14),C.u,1)
v=m.y
u=v.B(0.1)
t=A.G(8)
s=this.c
t=A.W(o,A.U(s.a,v,o,o,20),C.o,o,o,new A.R(u,o,o,t,o,o,C.r),o,o,o,o,C.as,o,o,o)
u=n.ok
v=u.x
v=v==null?o:v.av(C.F)
v=A.d(s.b,o,o,o,o,o,v,o,o,o)
u=u.Q
if(u==null)m=o
else{r=m.rx
m=u.dr(r==null?m.k3:r,1.4)}m=A.d(s.c,o,o,o,o,o,m,o,o,o)
u=y.u
r=A.a([],u)
for(s=s.d,q=s.length,p=0;p<q;++p)r.push(new B.bd_(s[p],o))
return new A.cb(new A.R(l,o,w,x,o,o,C.r),C.au,new A.J(C.C,A.z(A.a([t,C.aj,A.N(A.w(A.a([v,C.P,m,C.v,A.bi(C.a0,r,C.ac,o,8,8)],u),C.m,o,C.e,C.f,0,C.j),1,o)],u),C.m,o,C.e,C.f,0,o,o),o),o)}}
B.bd_.prototype={
gdpg(){return A.oL(this.c,A.az("(?<=[a-z])(?=[A-Z])",!0,!1,!1,!1),new B.dEE(),null)},
u(d){var x,w,v,u=null,t=A.t(d),s=t.ax,r=s.RG
if(r==null)r=s.k2
x=A.G(8)
w=s.to
if(w==null){w=s.E
s=w==null?s.k3:w}else s=w
s=A.aN(s,C.u,1)
w=this.gdpg()
v=t.ok.at
return A.hE(new A.ba(D.amw,new A.cb(new A.R(r,u,s,x,u,u,C.r),C.au,new A.J(M.lw,A.d(w,u,u,u,u,!0,v==null?u:v.dU6("monospace"),u,u,u),u),u),u),u,this.c,u,u,u)}}
var z=a.updateTypes([])
B.bNm.prototype={
$0(){return this.a.bsU(this.b)},
$S:0}
B.bNn.prototype={
$0(){return A.aJ(this.a,!1).f.aK(G.CC,y.q)},
$S:0}
B.bNo.prototype={
$0(){return A.aJ(this.a,!1).f.aK(F.oE,y.q)},
$S:0}
B.dEE.prototype={
$1(d){return"\u200b"},
$S:57};(function inheritance(){var x=a.inheritMany,w=a.inherit
x(A.x,[B.S2,B.avq,B.bcZ,B.bd_])
x(A.bu,[B.bNm,B.bNn,B.bNo])
w(B.nS,A.A)
w(B.dEE,A.bt)})()
A.b0(b.typeUniverse,JSON.parse('{"S2":{"x":[],"m":[]},"avq":{"x":[],"m":[]},"bcZ":{"x":[],"m":[]},"bd_":{"x":[],"m":[]}}'))
var y={F:A.C("bv"),x:A.C("v<n>"),u:A.C("v<m>"),n:A.C("v<nS>"),E:A.C("nS"),q:A.C("A?"),v:A.C("~")};(function constants(){var x=a.makeConstList
D.amw=new A.ay(0,280,0,1/0)
D.aSl=new A.a0(60989,"MaterialIcons",!1)
D.aU6=new A.a0(984740,"MaterialIcons",!1)
D.aSP=new A.a0(62018,"MaterialIcons",!0)
D.aUJ=new A.at(D.aSP,18,null,null,null)
D.b_e=x(["searchOpenDemands","getOpenDemand","createDemand","joinDemand","listMyDemands","getMyDemand","cancelDemandInterest","addDemandMissingRequirement","selectDemandOffer"],y.x)
D.b_S=x(["searchOpenDemandsForSeller","submitDemandOffer","listDemandMissingRequirementsForSeller","reviseDemandOffer"],y.x)
D.b2F=x(["listMyCreatorContents","draftMyCreatorContent","publishMyCreatorContent","archiveMyCreatorContent"],y.x)
D.b85=x(["listMyAddresses","getMyDefaultAddress"],y.x)
D.b8y=x(["getMySellerFulfillmentCapabilities","previewShipMyOrder","requestShipMyOrderLogistics","requestShipMyOrderPlatform"],y.x)
D.b8z=x(["listMyCart","getMyCartSummary","addToCart","updateCartItem","removeCartItem"],y.x)
D.b9S=x(["listMyOrders","getMyOrderDetail","listMyBuyerOrders"],y.x)
D.bc1=x(["getMyMcpCapabilities"],y.x)
D.bdm=x(["listMyWalletTransactions"],y.x)
D.be8=x(["listMyReceivedReviews","getMyReviewStats","replyToMyReview","batchReplyMyReviews"],y.x)
D.bex=x(["getMyStoreAnalytics","getMySellerDashboard","getMySellerTrustScore","listMySellerOrders","getMySellerOrderStats"],y.x)
D.bf5=x(["searchProducts","getProductDetail"],y.x)
D.bfK=x(["listMyProducts","getMyProductInventoryStats","getMyProductImportGuide","previewMyProductImport","requestBatchCreateMyProducts","previewMyProductUpdate","requestUpdateMyProduct","setMyProductStock","bulkSetMyProductStatus","listMyLowStockProducts","listMyOutOfStockProducts"],y.x)
D.bfY=x(["getMyStore","getMyStoreHome","getMyStorefrontHomeAuthoringGuide","validateMyStorefrontHomeDraft","getMyStorefrontHome","saveMyStorefrontHomeDraft","previewMyStoreHome","previewMyStorefrontHome","submitMyStorefrontHomeReview","disableMyStorefrontHome","previewMyStoreUpdate","createMyStore","requestUpdateMyStoreProfile","requestUpdateMyStoreShippingConfig","requestUpdateMyStoreReturnPolicy"],y.x)})()};
(a=>{a["TF05G37mh94v2BX43n0uo/kcbbo="]=a.current})($__dart_deferred_initializers__);