((a,b)=>{a[b]=a[b]||{}})(self,"$__dart_deferred_initializers__")
$__dart_deferred_initializers__.current=function(a,b,c,$){var A,B
A=c[0]
B=c[654]
var z=a.updateTypes([]);(function constants(){B.xA=new A.a0(58003,"MaterialIcons",!1)})()};
(a=>{a["muKw4adT+bmvVIbREmUHqM31JbE="]=a.current})($__dart_deferred_initializers__);