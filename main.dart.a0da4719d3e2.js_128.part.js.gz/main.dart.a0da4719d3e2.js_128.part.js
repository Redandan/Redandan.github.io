((a,b)=>{a[b]=a[b]||{}})(self,"$__dart_deferred_initializers__")
$__dart_deferred_initializers__.current=function(a,b,c,$){var A,B,C
A=c[0]
B=c[2]
C=c[325]
var z=a.updateTypes([]);(function constants(){C.bK=new A.ab(16,16,B.ku,null)})()};
(a=>{a["PxzG/4aafPCmfGnVemheuYJWFmc="]=a.current})($__dart_deferred_initializers__);