((a,b)=>{a[b]=a[b]||{}})(self,"$__dart_deferred_initializers__")
$__dart_deferred_initializers__.current=function(a,b,c,$){var B,A,C={
ejE(d,e,f,g,h,i,j){return new C.aTK(h,f,d,i,g,e,j)},
aTK:function aTK(d,e,f,g,h,i,j){var _=this
_.a=d
_.b=e
_.c=f
_.d=g
_.e=h
_.f=i
_.r=j}},D
B=c[0]
A=c[2]
C=a.updateHolder(c[171],C)
D=c[792]
C.aTK.prototype={
p(d,e){var x,w=this
if(e==null)return!1
if(w!==e){x=!1
if(e instanceof C.aTK)if(e.a===w.a)if(e.b===w.b)if(e.c===w.c)if(e.d===w.d)if(e.e===w.e)if(e.f===w.f)if(e.r===w.r)x=A.U.ar(D.u0,D.u0)}else x=!0
return x},
gj(d){var x=this,w=A.b.gj(x.a),v=A.b.gj(x.b),u=A.b.gj(x.c),t=A.b.gj(x.d),s=A.b.gj(x.e),r=A.b.gj(x.f),q=A.b.gj(x.r),p=B.a8(D.u0)
return w+v+u+t+s+r+q+p},
l(d){var x=this
return"StoreCreateParam[name="+x.a+", description="+x.b+", address="+x.c+", phone="+x.d+", email="+x.e+", businessHours="+x.f+", timeZone="+x.r+", logoUrl=null, logoDescription=null, coverImageUrl=null, coverDescription=null, supportedShippingCompanies="+B.b(D.u0)+", defaultShippingFee=null, freeShippingThreshold=null, shippingDescription=null, shippingPreparationHours=null, estimatedDeliveryDays=null, supportsScheduledShipping=null, shippingDateRange=null]"},
A(){var x=this,w=null,v=B.q(y.g,y.b)
v.h(0,"name",x.a)
v.h(0,"description",x.b)
v.h(0,"address",x.c)
v.h(0,"phone",x.d)
v.h(0,"email",x.e)
v.h(0,"businessHours",x.f)
v.h(0,"timeZone",x.r)
v.h(0,"logoUrl",w)
v.h(0,"logoDescription",w)
v.h(0,"coverImageUrl",w)
v.h(0,"coverDescription",w)
v.h(0,"supportedShippingCompanies",D.u0)
v.h(0,"defaultShippingFee",w)
v.h(0,"freeShippingThreshold",w)
v.h(0,"shippingDescription",w)
v.h(0,"shippingPreparationHours",w)
v.h(0,"estimatedDeliveryDays",w)
v.h(0,"supportsScheduledShipping",w)
v.h(0,"shippingDateRange",w)
return v}}
var z=a.updateTypes([]);(function inheritance(){var x=a.inherit
x(C.aTK,B.A)})()
var y={g:B.C("n"),b:B.C("@")};(function constants(){var x=a.makeConstList
D.u0=x([],B.C("v<fdm>"))})()};
(a=>{a["tUPtrIb2Rx+TbeUY8Qsd54HIHTI="]=a.current})($__dart_deferred_initializers__);