((a,b)=>{a[b]=a[b]||{}})(self,"$__dart_deferred_initializers__")
$__dart_deferred_initializers__.current=function(a,b,c,$){var A,B
A=c[0]
B=c[373]
var z=a.updateTypes([]);(function constants(){B.eM=new A.a0(58289,"MaterialIcons",!1)})()};
(a=>{a["bj3/7xTb95Nm/GbUaFLpc4Cf32A="]=a.current})($__dart_deferred_initializers__);