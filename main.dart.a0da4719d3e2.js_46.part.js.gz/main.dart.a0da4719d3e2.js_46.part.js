((a,b)=>{a[b]=a[b]||{}})(self,"$__dart_deferred_initializers__")
$__dart_deferred_initializers__.current=function(a,b,c,$){var J,A,C,B={
vK(d,e,f){return new B.Ci(e,d,f,null)},
Ci:function Ci(d,e,f,g){var _=this
_.c=d
_.d=e
_.e=f
_.a=g},
an_:function an_(){var _=this
_.e=_.d=null
_.f=$
_.r=null
_.x=_.w=0
_.c=_.a=null},
d12:function d12(){},
d13:function d13(d){this.a=d},
d14:function d14(d,e,f){this.a=d
this.b=e
this.c=f},
d15:function d15(d){this.a=d},
dYr(d){var x,w,v,u,t,s,r,q,p,o
if(d.length===0)return d
x=A.a([],y.l)
for(w=A.dXU(d,0,y.u),v=J.aZ(w.a),u=w.b,w=new A.VV(v,u,A.C(w).m("VV<1>")),t=y.e;w.F();){s=w.c
s=s>=0?new A.bb(u+s,v.gR()):A.aA(A.eu())
r=s.a
q=null
p=s.b
q=p
o=r
s=q.a
x.push(new A.m_(q,new A.W(s==null?o:s,t)))}return x}}
J=c[1]
A=c[0]
C=c[2]
B=a.updateHolder(c[267],B)
B.Ci.prototype={
O(){return new B.an_()}}
B.an_.prototype={
gEF(){var x=this.d
return(x==null?null:x.gf3())!=null},
akf(){var x=this,w=x.a.c,v=x.d
if(w===v)return
if(x.gEF())v.gf3().Z(x.gEY())
x.d=w
v=w.gf3()
v.cc()
v.bP$.L(0,x.gEY())},
bhX(d){++this.w
this.e.boX(d);--this.w},
af7(d,e,f){return this.cvc(d,e,f)},
cvc(d,e,f){var x=0,w=A.l(y.v),v=this
var $async$af7=A.h(function(g,h){if(g===1)return A.i(h,w)
for(;;)switch(x){case 0:++v.w
x=2
return A.c(v.e.zI(d,e,f),$async$af7)
case 2:--v.w
return A.j(null,w)}})
return A.k($async$af7,w)},
Y(){this.a5()
this.bkV()},
b8(){var x,w,v=this
v.bG()
v.akf()
x=v.r=v.d.d
w=v.e
if(w==null){v.a.toString
v.e=A.Oh(x,1)}else w.boX(x)},
aK(d){var x,w=this
w.b1(d)
if(w.a.c!==d.c){w.akf()
x=w.d.d
w.r=x
w.bhX(x)}x=w.a
if(x.d!==d.d&&w.w===0)w.bkV()},
q(){var x,w=this
if(w.gEF())w.d.gf3().Z(w.gEY())
w.d=null
x=w.e
if(x!=null)x.q()
w.a6()},
bkV(){var x=this.a.d,w=A.V(x).m("F<1,m>")
x=A.U(new A.F(x,new B.d12(),w),w.m("ak.E"))
this.f=B.dYr(x)},
byw(){var x,w=this
if(w.x>0||w.d.f===0)return
x=w.d.d
if(x!==w.r){w.r=x
w.diI()}},
diI(){var x,w,v,u=this
if(u.c!=null){x=y.x.a(C.e.gcp(u.e.f)).grn()
w=u.r
w.toString
w=x===w
x=w}else x=!0
if(x)return
x=u.r
x.toString
w=u.d
v=w.e
w=w.b
if(Math.abs(x-v)===1)u.blI(w)
else u.blJ(w)},
blI(d){return this.diH(d)},
diH(d){var x=0,w=A.l(y.v),v,u=this,t
var $async$blI=A.h(function(e,f){if(e===1)return A.i(f,w)
for(;;)switch(x){case 0:t=u.r
x=d.a===0?3:5
break
case 3:t.toString
u.bhX(t)
x=4
break
case 5:t.toString
x=6
return A.c(u.af7(t,C.c8,d),$async$blI)
case 6:case 4:if(u.c!=null)u.p(new B.d13(u))
v=A.eh(null,y.v)
x=1
break
case 1:return A.j(v,w)}})
return A.k($async$blI,w)},
blJ(d){return this.diJ(d)},
diJ(d){var x=0,w=A.l(y.v),v=this,u,t,s
var $async$blJ=A.h(function(e,f){if(e===1)return A.i(f,w)
for(;;)switch(x){case 0:t=v.d.e
s=v.r
s.toString
u=s>t?s-1:s+1
v.p(new B.d14(v,u,t))
v.bhX(u)
s=v.r
x=d.a===0?2:4
break
case 2:s.toString
v.bhX(s)
x=3
break
case 4:s.toString
x=5
return A.c(v.af7(s,C.c8,d),$async$blJ)
case 5:case 3:if(v.c!=null)v.p(new B.d15(v))
return A.j(null,w)}})
return A.k($async$blJ,w)},
c3H(){var x,w=this.d
w.toString
x=y.x.a(C.e.gcp(this.e.f)).grn()
x.toString
w.se6(A.ah(x-this.d.d,-1,1))},
deh(d){var x,w,v=this
if(v.w>0||v.x>0)return!1
if(d.jF$!==0)return!1
if(!v.gEF())return!1;++v.x
x=y.x.a(C.e.gcp(v.e.f)).grn()
x.toString
if(d instanceof A.od&&v.d.f===0){w=v.d
if(Math.abs(x-w.d)>1){w.bvW(C.k.aT(x))
v.r=v.d.d}v.c3H()}else if(d instanceof A.r3){w=v.d
w.toString
w.bvW(C.k.aT(x))
x=v.d
v.r=x.d
if(x.f===0)v.c3H()}--v.x
return!1},
u(d){var x,w=this,v=w.a,u=w.e
v=v.e
v=v==null?new A.Oi(C.Fr.nW(C.nM)):new A.Oi(C.Fr.nW(v))
x=w.f
x===$&&A.f()
return new A.fi(w.gdeg(),A.dpn(x,C.t,u,C.x,null,null,v),null,y.f)}}
var z=a.updateTypes(["~()","K(lK)"])
B.d12.prototype={
$1(d){var x=null
return A.P(x,x,x,d,!1,x,x,x,!1,x,!1,x,x,x,x,x,x,x,x,x,x,x,x,x,x,x,x,x,x,x,x,x,x,x,x,x,x,x,x,x,x,x,C.bti,x,x,x,x,x,x,x,x,x,x,C.p,x)},
$S:1762}
B.d13.prototype={
$0(){this.a.bkV()},
$S:0}
B.d14.prototype={
$0(){var x,w,v=this.a,u=v.f
u===$&&A.f()
u=A.U(u,y.u)
u.$flags=1
v=v.f=u
u=this.b
x=v[u]
w=this.c
v[u]=v[w]
v[w]=x},
$S:0}
B.d15.prototype={
$0(){this.a.bkV()},
$S:0};(function installTearOffs(){var x=a._instance_0u,w=a._instance_1u
var v
x(v=B.an_.prototype,"gEY","byw",0)
w(v,"gdeg","deh",1)})();(function inheritance(){var x=a.inherit,w=a.inheritMany
x(B.Ci,A.J)
x(B.an_,A.R)
x(B.d12,A.by)
w(A.bw,[B.d13,B.d14,B.d15])})()
A.aV(b.typeUniverse,JSON.parse('{"Ci":{"J":[],"m":[]},"an_":{"R":["Ci"]}}'))
var y={l:A.A("w<m>"),f:A.A("fi<lK>"),e:A.A("W<G>"),u:A.A("m"),x:A.A("w9"),v:A.A("~")}};
(a=>{a["X58rMm9cYdN+qzUd3UKn46GTK6I="]=a.current})($__dart_deferred_initializers__);