((a,b)=>{a[b]=a[b]||{}})(self,"$__dart_deferred_initializers__")
$__dart_deferred_initializers__.current=function(a,b,c,$){var J,B,A,C={
ecW(d,e,f,g,h,i,j){return new C.aFL(f,h,i,e,d,g,j)},
aFL:function aFL(d,e,f,g,h,i,j){var _=this
_.a=d
_.b=e
_.c=f
_.d=g
_.w=h
_.x=i
_.y=j},
D5:function D5(d){this.a=d}},D
J=c[1]
B=c[0]
A=c[2]
C=a.updateHolder(c[166],C)
D=c[632]
C.aFL.prototype={
p(d,e){var x,w=this
if(e==null)return!1
if(w!==e){x=!1
if(e instanceof C.aFL)if(e.a===w.a)if(e.b===w.b)if(J.p(e.c,w.c))if(J.p(e.d,w.d))if(e.w==w.w)x=e.y==w.y}else x=!0
return x},
gj(d){var x,w,v,u=this,t=A.h.gj(u.a),s=A.h.gj(u.b),r=u.c
r=r==null?0:B.Y(r.a,r.b,A.a,A.a,A.a,A.a,A.a,A.a,A.a,A.a,A.a,A.a,A.a,A.a,A.a,A.a,A.a,A.a,A.a,A.a)
x=u.d
x=x==null?0:B.Y(x.a,x.b,A.a,A.a,A.a,A.a,A.a,A.a,A.a,A.a,A.a,A.a,A.a,A.a,A.a,A.a,A.a,A.a,A.a,A.a)
w=u.w
w=w==null?0:A.h.gj(w)
v=u.y
v=v==null?0:B.a7(v)
return t+s+r+x+w+v},
l(d){var x=this
return"DisputeSearchParam[page="+x.a+", size="+x.b+", startDate="+B.b(x.c)+", endDate="+B.b(x.d)+", keyword=null, sortBy=null, sortDirection=null, buyerId="+B.b(x.w)+", sellerId="+B.b(x.x)+", status="+B.b(x.y)+"]"},
A(){var x,w=this,v=null,u="startDate",t=B.q(y.g,y.b)
t.h(0,"page",w.a)
t.h(0,"size",w.b)
x=w.c
if(x!=null)t.h(0,u,x.a3().a_())
else t.h(0,u,v)
x=w.d
if(x!=null)t.h(0,"endDate",x.a3().a_())
else t.h(0,"endDate",v)
t.h(0,"keyword",v)
t.h(0,"sortBy",v)
t.h(0,"sortDirection",v)
x=w.w
if(x!=null)t.h(0,"buyerId",x)
else t.h(0,"buyerId",v)
t.h(0,"sellerId",v)
x=w.y
if(x!=null)t.h(0,"status",x)
else t.h(0,"status",v)
return t}}
C.D5.prototype={
l(d){return this.a},
A(){return this.a}}
var z=a.updateTypes([]);(function inheritance(){var x=a.inheritMany
x(B.A,[C.aFL,C.D5])})()
var y={g:B.C("n"),b:B.C("@")};(function constants(){D.PD=new C.D5("PENDING")})()};
(a=>{a["67sh+so92GAz1GESwwbeZihj+Oc="]=a.current})($__dart_deferred_initializers__);