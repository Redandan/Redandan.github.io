((a,b)=>{a[b]=a[b]||{}})(self,"$__dart_deferred_initializers__")
$__dart_deferred_initializers__.current=function(a,b,c,$){var A,C,B={
bg_(d,e){return B.eWq(d,!1)},
eWq(d,e){var x=0,w=A.l(y.g),v,u=2,t=[],s,r,q,p,o,n,m
var $async$bg_=A.h(function(f,g){if(f===1){t.push(g)
x=u}for(;;)switch(x){case 0:if(!d.gN()){v=null
x=1
break}s=$.am().$1$0(y.l)
u=4
x=7
return A.c(s.ih(!1),$async$bg_)
case 7:r=g
o=d.gN()?r:null
v=o
x=1
break
u=2
x=6
break
case 4:u=3
m=t.pop()
q=A.u(m)
if(!d.gN()){v=null
x=1
break}x=A.BQ(q)?8:9
break
case 8:x=10
return A.c(A.ui(null,null,!1),$async$bg_)
case 10:p=g
if(p){v=null
x=1
break}case 9:throw m
x=6
break
case 3:x=2
break
case 6:case 1:return A.j(v,w)
case 2:return A.i(t.at(-1),w)}})
return A.k($async$bg_,w)},
dT4:function dT4(){}}
A=c[0]
C=c[257]
B=a.updateHolder(c[204],B)
var z=a.updateTypes([])
B.dT4.prototype={
$1(d){return this.cBB(d)},
cBB(d){var x=0,w=A.l(y.g),v
var $async$$1=A.h(function(e,f){if(e===1)return A.i(f,w)
for(;;)switch(x){case 0:v=B.bg_(d.hc($.a7T(),y.o),!1)
x=1
break
case 1:return A.j(v,w)}})
return A.k($async$$1,w)},
$S:1558};(function inheritance(){var x=a.inherit
x(B.dT4,A.bu)})()
var y={l:A.C("lM"),o:A.C("qZ"),g:A.C("jO?")};(function lazyInitializers(){var x=a.lazyFinal
x($,"fgG","XR",()=>C.e10(new B.dT4(),y.g))})()};
(a=>{a["if3d8uBqXJCn5yM+mBL5yZve8lg="]=a.current})($__dart_deferred_initializers__);