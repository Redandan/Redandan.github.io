((a,b)=>{a[b]=a[b]||{}})(self,"$__dart_deferred_initializers__")
$__dart_deferred_initializers__.current=function(a,b,c,$){var A,B
A=c[0]
B=c[487]
var z=a.updateTypes([]);(function constants(){B.DH=new A.ar(0,12,0,0)})()};
(a=>{a["5d4gwhImdHYuJTPSKYr9XyJRzEs="]=a.current})($__dart_deferred_initializers__);