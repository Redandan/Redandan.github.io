((a,b)=>{a[b]=a[b]||{}})(self,"$__dart_deferred_initializers__")
$__dart_deferred_initializers__.current=function(a,b,c,$){var A,C,B={Sf:function Sf(d,e){this.a=d
this.b=e}}
A=c[0]
C=c[2]
B=a.updateHolder(c[243],B)
B.Sf.prototype={
p(d,e){var x
if(e==null)return!1
if(this!==e)x=e instanceof B.Sf&&e.a===this.a&&e.b===this.b
else x=!0
return x},
gj(d){var x=C.b.gj(this.a),w=C.b.gj(this.b)
return x+w},
l(d){return"OrderCancelParam[orderId="+this.a+", reason="+this.b+"]"},
A(){var x=A.q(y.g,y.b)
x.h(0,"orderId",this.a)
x.h(0,"reason",this.b)
return x}}
var z=a.updateTypes([]);(function inheritance(){var x=a.inherit
x(B.Sf,A.A)})()
var y={g:A.B("n"),b:A.B("@")}};
(a=>{a["T9OrNWTclXNK3JSvdKSY1pV4ieM="]=a.current})($__dart_deferred_initializers__);