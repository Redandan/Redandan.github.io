((a,b)=>{a[b]=a[b]||{}})(self,"$__dart_deferred_initializers__")
$__dart_deferred_initializers__.current=function(a,b,c,$){var A,C,B={R_:function R_(d,e){this.a=d
this.b=e}}
A=c[0]
C=c[2]
B=a.updateHolder(c[243],B)
B.R_.prototype={
p(d,e){var x
if(e==null)return!1
if(this!==e)x=e instanceof B.R_&&e.a===this.a&&e.b===this.b
else x=!0
return x},
gj(d){var x=C.c.gj(this.a),w=C.c.gj(this.b)
return x+w},
l(d){return"OrderCancelParam[orderId="+this.a+", reason="+this.b+"]"},
v(){var x=A.r(y.g,y.b)
x.h(0,"orderId",this.a)
x.h(0,"reason",this.b)
return x}}
var z=a.updateTypes([]);(function inheritance(){var x=a.inherit
x(B.R_,A.A)})()
var y={g:A.F("n"),b:A.F("@")}};
(a=>{a["1DjcBTNvYuwo5yRRqKhQWcddDAM="]=a.current})($__dart_deferred_initializers__);