((a,b)=>{a[b]=a[b]||{}})(self,"$__dart_deferred_initializers__")
$__dart_deferred_initializers__.current=function(a,b,c,$){var A,B,C
A=c[0]
B=c[2]
C=c[337]
var z=a.updateTypes([]);(function constants(){C.fe=new A.as(B.tl,null,null,null,null)})()};
(a=>{a["G1aoxpQqfhOqWJ6ujFX4u6bfeS0="]=a.current})($__dart_deferred_initializers__);