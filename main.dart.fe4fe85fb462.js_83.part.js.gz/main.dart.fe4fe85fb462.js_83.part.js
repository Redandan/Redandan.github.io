((a,b)=>{a[b]=a[b]||{}})(self,"$__dart_deferred_initializers__")
$__dart_deferred_initializers__.current=function(a,b,c,$){var B,C,A={aFm:function aFm(d,e,f,g,h,i){var _=this
_.a=d
_.b=e
_.c=f
_.d=g
_.e=h
_.f=i}},D
B=c[0]
C=c[2]
A=a.updateHolder(c[245],A)
D=c[659]
A.aFm.prototype={}
var z=a.updateTypes([]);(function inheritance(){var y=a.inherit
y(A.aFm,B.bU)})()
B.b0(b.typeUniverse,JSON.parse('{"aFm":{"bU":["~"]}}'));(function constants(){D.p_=new A.aFm("DepositRoute",null,C.ae,C.ae,null,"")})()};
(a=>{a["W/rqmFirPhXDEmGYpJ+VsjLpcgs="]=a.current})($__dart_deferred_initializers__);