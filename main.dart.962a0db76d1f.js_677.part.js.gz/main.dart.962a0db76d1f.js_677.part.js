((a,b)=>{a[b]=a[b]||{}})(self,"$__dart_deferred_initializers__")
$__dart_deferred_initializers__.current=function(a,b,c,$){var A,B
A=c[0]
B=c[715]
var z=a.updateTypes([]);(function constants(){B.RJ=new A.a0(58058,"MaterialIcons",!1)})()};
(a=>{a["h518tp4T3Doziv9RwUSSSCsjoHE="]=a.current})($__dart_deferred_initializers__);