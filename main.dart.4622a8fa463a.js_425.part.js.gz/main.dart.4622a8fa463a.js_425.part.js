((a,b)=>{a[b]=a[b]||{}})(self,"$__dart_deferred_initializers__")
$__dart_deferred_initializers__.current=function(a,b,c,$){var A,B
A=c[0]
B=c[577]
var z=a.updateTypes([]);(function constants(){B.xP=new A.a0(58950,"MaterialIcons",!1)})()};
(a=>{a["bL64SlfdYLaFHGG7xm75YzsH6y0="]=a.current})($__dart_deferred_initializers__);