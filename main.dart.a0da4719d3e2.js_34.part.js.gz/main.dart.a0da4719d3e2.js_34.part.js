((a,b)=>{a[b]=a[b]||{}})(self,"$__dart_deferred_initializers__")
$__dart_deferred_initializers__.current=function(a,b,c,$){var A,B
A=c[0]
B=c[292]
var z=a.updateTypes([]);(function constants(){B.a9v=new A.ac(120,40)})()};
(a=>{a["HQ7HtcYxc669WGd3kAgsr17cjIQ="]=a.current})($__dart_deferred_initializers__);