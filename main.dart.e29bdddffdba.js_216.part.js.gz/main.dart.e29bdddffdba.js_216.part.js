((a,b)=>{a[b]=a[b]||{}})(self,"$__dart_deferred_initializers__")
$__dart_deferred_initializers__.current=function(a,b,c,$){var B,C,A={a4Z:function a4Z(d){this.a=d},aTU:function aTU(d){this.a=d}},D
B=c[0]
C=c[2]
A=a.updateHolder(c[212],A)
D=c[724]
A.a4Z.prototype={}
A.aTU.prototype={
p(d,e){var x
if(e==null)return!1
if(this!==e)x=e instanceof A.aTU&&e.a===this.a
else x=!0
return x},
gj(d){var x=C.b.gj(this.a)
return x},
l(d){return"StorefrontHomeDraftRequest[html="+this.a+"]"},
A(){var x=B.q(y.g,y.b)
x.h(0,"html",this.a)
return x}}
var z=a.updateTypes([]);(function inheritance(){var x=a.inheritMany
x(B.A,[A.a4Z,A.aTU])})()
var y={g:B.C("n"),b:B.C("@")};(function constants(){D.FX=new B.a0(983092,"MaterialIcons",!0)})()};
(a=>{a["7PhUQUaKOurXIo4BAOUtcGRr2to="]=a.current})($__dart_deferred_initializers__);