((a,b)=>{a[b]=a[b]||{}})(self,"$__dart_deferred_initializers__")
$__dart_deferred_initializers__.current=function(a,b,c,$){var A,B
A=c[0]
B=c[356]
var z=a.updateTypes([]);(function constants(){B.Sl=new A.a0(61058,"MaterialIcons",!1)})()};
(a=>{a["CQCZ/Vp3zVseXKPxd7cE2mO4A80="]=a.current})($__dart_deferred_initializers__);