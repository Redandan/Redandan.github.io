((a,b)=>{a[b]=a[b]||{}})(self,"$__dart_deferred_initializers__")
$__dart_deferred_initializers__.current=function(a,b,c,$){var B,C,A={aUs:function aUs(d,e,f,g,h,i){var _=this
_.a=d
_.b=e
_.c=f
_.d=g
_.e=h
_.f=i}},D
B=c[0]
C=c[2]
A=a.updateHolder(c[251],A)
D=c[619]
A.aUs.prototype={}
var z=a.updateTypes([]);(function inheritance(){var y=a.inherit
y(A.aUs,B.bV)})()
B.b_(b.typeUniverse,JSON.parse('{"aUs":{"bV":["~"]}}'));(function constants(){D.qH=new A.aUs("TransactionHistoryRoute",null,C.af,C.af,null,"")})()};
(a=>{a["/zvrEznnySUa8zJo0kU2ae6Dgpc="]=a.current})($__dart_deferred_initializers__);