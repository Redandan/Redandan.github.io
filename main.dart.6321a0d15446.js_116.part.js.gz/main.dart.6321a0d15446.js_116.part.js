((a,b)=>{a[b]=a[b]||{}})(self,"$__dart_deferred_initializers__")
$__dart_deferred_initializers__.current=function(a,b,c,$){var A,B
A=c[0]
B=c[504]
var z=a.updateTypes([]);(function constants(){B.cX=new A.a0(57882,"MaterialIcons",!1)})()};
(a=>{a["Vo0q3EDJQMpBvmI2ziW6SdT0sVY="]=a.current})($__dart_deferred_initializers__);