((a,b)=>{a[b]=a[b]||{}})(self,"$__dart_deferred_initializers__")
$__dart_deferred_initializers__.current=function(a,b,c,$){var A,B,C={
IU(d,e,f,g,h,i,j,k,l,m,n){return new C.QG(d,h,i,k,j,l,e,n,m,f,g)},
cGC:function cGC(d,e){this.a=d
this.b=e},
QG:function QG(d,e,f,g,h,i,j,k,l,m,n){var _=this
_.c=d
_.d=e
_.e=f
_.r=g
_.w=h
_.ax=i
_.dy=j
_.fx=k
_.k3=l
_.k4=m
_.a=n},
cTd:function cTd(d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,a0,a1,a2,a3,a4,a5){var _=this
_.fr=d
_.fx=e
_.fy=f
_.go=g
_.k1=_.id=$
_.a=h
_.b=i
_.c=j
_.d=k
_.e=l
_.f=m
_.r=n
_.w=o
_.x=p
_.y=q
_.z=r
_.Q=s
_.as=t
_.at=u
_.ax=v
_.ay=w
_.ch=x
_.CW=a0
_.cx=a1
_.cy=a2
_.db=a3
_.dx=a4
_.dy=a5},
cTe:function cTe(d){this.a=d}},D
A=c[0]
B=c[2]
C=a.updateHolder(c[244],C)
D=c[813]
C.cGC.prototype={
W(){return"_ChipVariant."+this.b}}
C.QG.prototype={
u(d){var x,w=this,v=null
A.t(d)
x=w.r
A.t(d)
return A.aP8(!1,w.c,B.h7,v,w.dy,w.k4,v,B.o,v,new C.cTd(d,!0,x,D.mB,v,v,v,v,v,v,v,v,v,!0,v,v,v,v,B.o1,v,v,v,v,v,v,v,v),v,B.pw,v,v,v,v,v,v,!0,w.d,v,w.e,v,v,v,v,w.w,v,v,x,w.ax,v,v,v,w.k3,v,v,!0,v,w.fx)}}
C.cTd.prototype={
glo(){var x,w=this,v=w.id
if(v===$){x=A.t(w.fr)
w.id!==$&&A.bf()
v=w.id=x.ax}return v},
gfB(){if(this.go===D.mB)var x=0
else x=this.fx?1:0
return x},
gSo(){return 1},
gjr(){var x,w,v,u=this,t=u.k1
if(t===$){x=A.t(u.fr)
u.k1!==$&&A.bf()
t=u.k1=x.ok}x=t.as
if(x==null)x=null
else{if(u.fx)if(u.fy){w=u.glo()
v=w.as
w=v==null?w.z:v}else{w=u.glo()
v=w.rx
w=v==null?w.k3:v}else w=u.glo().k3
w=x.a0(w)
x=w}return x},
gey(){return new A.bX(new C.cTe(this),y.d)},
gcM(){if(this.go===D.mB)var x=B.a4
else{x=this.glo().x1
if(x==null)x=B.V}return x},
gdk(){return B.a4},
gBx(){var x,w,v=this
if(v.fx)if(v.fy){x=v.glo()
w=x.as
x=w==null?x.z:w}else x=v.glo().b
else x=v.glo().k3
return x},
gBM(){var x,w,v=this
if(v.fx)if(v.fy){x=v.glo()
w=x.as
x=w==null?x.z:w}else{x=v.glo()
w=x.rx
x=w==null?x.k3:w}else x=v.glo().k3
return x},
ghw(){var x,w,v=this
if(v.go===D.mB&&!v.fy)if(v.fx){x=v.glo()
w=x.to
if(w==null){w=x.E
x=w==null?x.k3:w}else x=w
x=new A.aV(x,1,B.u,-1)}else{x=v.glo().k3
x=new A.aV(A.bj(31,x.K()>>>16&255,x.K()>>>8&255,x.K()&255),1,B.u,-1)}else x=B.oG
return x},
gi1(){var x,w,v=this,u=null
if(v.fx)if(v.fy){x=v.glo()
w=x.as
x=w==null?x.z:w}else x=v.glo().b
else x=v.glo().k3
return new A.eX(18,u,u,u,u,x,u,u,u)},
geb(){return B.ar},
gpE(){var x=this.gjr(),w=x==null?null:x.r
if(w==null)w=14
x=A.cP(this.fr,B.b9)
x=x==null?null:x.gcZ()
x=A.tr(B.d7,B.fb,A.an((x==null?B.aZ:x).bw(w)/14-1,0,1))
x.toString
return x}}
var z=a.updateTypes([])
C.cTe.prototype={
$1(d){var x,w,v=this
if(d.t(0,B.an)&&d.t(0,B.al)){x=v.a
if(x.go===D.mB){x=x.glo().k3
x=A.bj(31,x.K()>>>16&255,x.K()>>>8&255,x.K()&255)}else{x=x.glo().k3
x=A.bj(31,x.K()>>>16&255,x.K()>>>8&255,x.K()&255)}return x}if(d.t(0,B.al)){x=v.a
if(x.go===D.mB)x=null
else{x=x.glo().k3
x=A.bj(31,x.K()>>>16&255,x.K()>>>8&255,x.K()&255)}return x}if(d.t(0,B.an)){x=v.a
if(x.go===D.mB){x=x.glo()
w=x.Q
x=w==null?x.y:w}else{x=x.glo()
w=x.Q
x=w==null?x.y:w}return x}x=v.a
if(x.go===D.mB)x=null
else{x=x.glo()
w=x.p3
x=w==null?x.k2:w}return x},
$S:29};(function inheritance(){var x=a.inherit
x(C.cGC,A.eB)
x(C.QG,A.x)
x(C.cTd,A.I2)
x(C.cTe,A.bu)})()
A.b0(b.typeUniverse,JSON.parse('{"QG":{"x":[],"m":[]}}'))
var y={d:A.C("bX<a3?>")};(function constants(){D.mB=new C.cGC(0,"flat")})()};
(a=>{a["vVtNc3/zMq+L7teN0fVJE2gDWqs="]=a.current})($__dart_deferred_initializers__);