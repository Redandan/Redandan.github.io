((a,b)=>{a[b]=a[b]||{}})(self,"$__dart_deferred_initializers__")
$__dart_deferred_initializers__.current=function(a,b,c,$){var A,B
A=c[0]
B=c[440]
var z=a.updateTypes([]);(function constants(){B.y5=new A.a0(984284,"MaterialIcons",!1)})()};
(a=>{a["Df8sRYGdngszbDMhmCyzFEG1Wks="]=a.current})($__dart_deferred_initializers__);