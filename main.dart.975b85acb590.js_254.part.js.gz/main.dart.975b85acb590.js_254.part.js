((a,b)=>{a[b]=a[b]||{}})(self,"$__dart_deferred_initializers__")
$__dart_deferred_initializers__.current=function(a,b,c,$){var J,A,B,C={DM:function DM(d,e){this.a=d
this.b=e}}
J=c[1]
A=c[0]
B=c[2]
C=a.updateHolder(c[236],C)
C.DM.prototype={
wB(d){return new A.dt(this,y.d)},
yZ(d,e){return A.S_(null,this.lJ(d,e),"MemoryImage("+("<optimized out>#"+A.d9(d.a))+")",null,d.b)},
wu(d,e){return A.S_(null,this.lJ(d,e),"MemoryImage("+("<optimized out>#"+A.d9(d.a))+")",null,d.b)},
lJ(d,e){return this.dl5(d,e)},
dl5(d,e){var x=0,w=A.l(y.c),v,u=this,t
var $async$lJ=A.h(function(f,g){if(f===1)return A.i(g,w)
for(;;)switch(x){case 0:t=e
x=3
return A.c(A.Dx(u.a),$async$lJ)
case 3:v=t.$1(g)
x=1
break
case 1:return A.j(v,w)}})
return A.k($async$lJ,w)},
p(d,e){if(e==null)return!1
if(J.ab(e)!==A.aq(this))return!1
return e instanceof C.DM&&e.a===this.a&&e.b===this.b},
gj(d){return A.Y(A.a8(this.a),this.b,B.a,B.a,B.a,B.a,B.a,B.a,B.a,B.a,B.a,B.a,B.a,B.a,B.a,B.a,B.a,B.a,B.a,B.a)},
l(d){return"MemoryImage("+("<optimized out>#"+A.d9(this.a))+", scale: "+B.h.Z(this.b,1)+")"}}
var z=a.updateTypes([]);(function inheritance(){var x=a.inherit
x(C.DM,A.iP)})()
A.b_(b.typeUniverse,JSON.parse('{"DM":{"iP":["DM"],"iP.T":"DM"}}'))
var y={c:A.C("j4"),d:A.C("dt<DM>")}};
(a=>{a["eAw2At/+RywBPLJRr/CdAndcQXU="]=a.current})($__dart_deferred_initializers__);