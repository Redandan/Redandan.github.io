((a,b)=>{a[b]=a[b]||{}})(self,"$__dart_deferred_initializers__")
$__dart_deferred_initializers__.current=function(a,b,c,$){var J,A,B,H,I,K,L,M,C={azi:function azi(d,e,f,g,h,i){var _=this
_.a=d
_.b=e
_.c=f
_.d=g
_.e=h
_.f=i},a2W:function a2W(d){this.a=d},aJm:function aJm(){var _=this
_.e=_.d=$
_.c=_.a=null},c5Y:function c5Y(d){this.a=d},c5T:function c5T(d,e,f){this.a=d
this.b=e
this.c=f},c5U:function c5U(d,e){this.a=d
this.b=e},c5V:function c5V(d,e){this.a=d
this.b=e},c5W:function c5W(d,e){this.a=d
this.b=e},c5X:function c5X(d,e,f){this.a=d
this.b=e
this.c=f},aVo:function aVo(d,e,f,g,h){var _=this
_.c=d
_.d=e
_.e=f
_.f=g
_.a=h},aQA:function aQA(d,e,f,g){var _=this
_.c=d
_.d=e
_.e=f
_.a=g},aO0:function aO0(d){this.a=d},a_1:function a_1(d,e,f){this.a=d
this.b=e
this.c=f},aJ5:function aJ5(d,e){this.c=d
this.a=e},aVE:function aVE(d){this.a=d},alR:function alR(d,e,f){this.a=d
this.b=e
this.c=f},aVD:function aVD(d,e){this.c=d
this.a=e},aVM:function aVM(d){this.a=d},alu:function alu(d,e,f,g){var _=this
_.c=d
_.d=e
_.e=f
_.a=g},
dRZ(){return new C.L2(null)},
L2:function L2(d){this.a=d}},D,F,N,E,O,P,Q,G,R,S,T
J=c[1]
A=c[0]
B=c[2]
H=c[528]
I=c[280]
K=c[570]
L=c[313]
M=c[283]
C=a.updateHolder(c[14],C)
D=c[654]
F=c[567]
N=c[582]
E=c[655]
O=c[653]
P=c[571]
Q=c[583]
G=c[573]
R=c[565]
S=c[438]
T=c[393]
C.azi.prototype={}
C.a2W.prototype={
O(){return new C.aJm()}}
C.aJm.prototype={
Y(){var w,v,u=this
u.a5()
w=$.av()
v=x.E
w=w.bk(v)?w.$1$0(v):null
u.d!==$&&A.b5()
u.d=w
u.e=u.bi3()},
bi3(){var w=0,v=A.l(x.w),u,t=2,s=[],r=this,q,p,o,n,m,l,k,j
var $async$bi3=A.h(function(d,e){if(d===1){s.push(e)
w=t}for(;;)switch(w){case 0:t=4
n=r.d
n===$&&A.f()
n=n==null?null:n.zX()
w=7
return A.c(x.e.b(n)?n:A.h6(n,x.c),$async$bi3)
case 7:q=e
n=q
m=null
if(!(n==null)){n=n.r
if(!(n==null)){n=n.b
n=n==null?null:B.c.G(n)
m=n}}p=m
n=p
if((n==null?null:J.aD(n)!==0)===!0){n=p
n.toString
u=n
w=1
break}n=q
if(n==null)l=null
else{n=n.b
l=n==null?null:B.c.G(n)}o=l
n=o
if((n==null?null:J.aD(n)!==0)===!0){n=o
n.toString
u=n
w=1
break}t=2
w=6
break
case 4:t=3
j=s.pop()
w=6
break
case 3:w=2
break
case 6:u=y.d
w=1
break
case 1:return A.j(u,v)
case 2:return A.i(s.at(-1),v)}})
return A.k($async$bi3,v)},
bfP(d,e){return this.cEi(d,e)},
cEi(d,e){var w=0,v=A.l(x.v),u,t
var $async$bfP=A.h(function(f,g){if(f===1)return A.i(g,v)
for(;;)switch(w){case 0:t=A.e(d,B.b,x.F)
w=3
return A.c(A.i9(new A.hG(t.gasd()+"\n"+e+"\n\n"+t.gasf()+"\n\n"+t.gase())),$async$bfP)
case 3:if(d.e==null){w=1
break}A.a7(d,t.gash(),B.X,null)
case 1:return A.j(u,v)}})
return A.k($async$bfP,v)},
bfK(d,e){return this.cE8(d,e)},
cE8(d,e){var w=0,v=A.l(x.v),u,t
var $async$bfK=A.h(function(f,g){if(f===1)return A.i(g,v)
for(;;)switch(w){case 0:t=A.e(d,B.b,x.F)
t.toString
w=3
return A.c(A.i9(new A.hG(e)),$async$bfK)
case 3:if(d.e==null){w=1
break}A.a7(d,t.gas2(),B.X,null)
case 1:return A.j(u,v)}})
return A.k($async$bfK,v)},
u(d){var w=null,v=A.dy(w,w,!0,d,w,w,w,A.e(d,B.b,x.F).gTD()),u=this.e
u===$&&A.f()
return A.bQ(v,w,A.awI(new C.c5Y(this),u,x.w),w,w,w,w,w)}}
C.aVo.prototype={
u(d){var w,v,u,t,s,r,q=this,p=null,o=A.q(d),n=A.e(d,B.b,x.F)
n.toString
w=o.ax
v=w.b
u=v.v(0.12)
t=A.B(8)
t=A.S(p,A.N(O.Pj,v,p,p,p),B.o,p,p,new A.O(u,p,p,t,p,p,B.r),p,48,p,p,p,p,p,48)
u=n.gTD()
v=o.ok
s=v.r
u=A.d(u,p,p,p,p,p,s==null?p:s.aj(B.A),p,p,p)
s=n.gasq()
v=v.z
if(v==null)w=p
else{r=w.rx
w=v.dZ(r==null?w.k3:r,1.45)}v=x.u
return A.b8(p,p,A.v(A.a([A.y(A.a([t,B.ad,A.Q(A.v(A.a([u,B.O,A.d(s,p,p,p,p,p,w,p,p,p)],v),B.m,p,B.d,B.h,0,B.j),1,p)],v),B.m,p,B.d,B.h,0,p,p),B.n,A.bo(B.a1,A.a([A.bF(P.DW,p,A.d(n.gas5(),p,p,p,p,p,p,p,p,p),q.c,p),A.ca(Q.Qv,p,A.d(n.gas0(),p,p,p,p,p,p,p,p,p),q.e,p),A.ca(D.aMj,p,A.d(n.gasc(),p,p,p,p,p,p,p,p,p),q.f,p),M.e7(D.aNl,p,A.d(n.gasD(),p,p,p,p,p,p,p,p,p),q.d,p)],v),B.a9,p,8,8)],v),B.m,p,B.d,B.h,0,B.j),p,B.a6,p,B.b4,!1,p)}}
C.aQA.prototype={
u(d){var w,v,u,t,s,r,q,p,o,n=null,m=A.q(d),l=A.e(d,B.b,x.F)
l.toString
w=x.u
v=A.a([],w)
if(this.d)B.e.A(v,A.a([K.kQ,B.n],w))
u=m.ax
t=A.N(G.mq,u.b,n,n,n)
s=l.gas3()
r=m.ok
q=r.w
s=A.d(s,n,n,n,n,n,q==null?n:q.aj(B.A),n,n,n)
q=l.gas1()
r=r.z
p=r==null
if(p)o=n
else{o=u.rx
o=r.dZ(o==null?u.k3:o,1.45)}v.push(A.y(A.a([t,B.B,A.Q(A.v(A.a([s,B.O,A.d(q,n,n,n,n,n,o,n,n,n)],w),B.m,n,B.d,B.h,0,B.j),1,n)],w),B.m,n,B.d,B.h,0,n,n))
v.push(B.n)
o=u.RG
t=(o==null?u.k2:o).v(0.45)
s=A.B(8)
q=u.to
if(q==null){q=u.E
if(q==null)q=u.k3}q=A.aE(q.v(0.7),B.u,1)
u=p?n:r.bEB(u.k3,"monospace")
v.push(new A.bZ(new A.O(t,n,q,s,n,n,B.r),B.aq,new A.I(B.c9,A.y(A.a([A.Q(I.m6(this.c,n,u,n),1,n),B.B,A.aK(n,n,n,n,n,D.aLd,n,n,this.e,n,n,n,n,l.gas4(),n)],w),B.l,n,B.d,B.h,0,n,n),n),n))
return A.b8(n,n,A.v(v,B.m,n,B.d,B.h,0,B.j),n,B.a6,n,B.b4,!1,n)}}
C.aO0.prototype={
u(d){var w,v,u,t,s=null,r=A.q(d),q=A.e(d,B.b,x.F),p=[new C.a_1(R.wd,q.garX(),q.gTw()),new C.a_1(S.iK,q.garZ(),q.gTA()),new C.a_1(D.aKV,q.garY(),q.gTy()),new C.a_1(H.jH,q.gas_(),q.gTB())],o=q.gTz()
q=q.gTx()
w=r.ok.z
if(w==null)w=s
else{v=r.ax
u=v.rx
w=w.dZ(u==null?v.k3:u,1.45)}v=x.u
w=A.a([A.d(q,s,s,s,s,s,w,s,s,s),B.n],v)
for(t=0;t<4;++t){q=A.a([new C.aJ5(p[t],s)],v)
if(t!==3)q.push(B.w)
B.e.A(w,q)}return new C.alu(F.Pf,o,A.v(w,B.m,s,B.d,B.h,0,B.j),s)}}
C.a_1.prototype={}
C.aJ5.prototype={
u(d){var w,v,u,t,s,r,q,p=null,o=A.q(d),n=o.ax,m=n.RG
m=(m==null?n.k2:m).v(0.45)
w=A.B(8)
v=n.to
if(v==null){v=n.E
if(v==null)v=n.k3}v=A.aE(v.v(0.72),B.u,1)
u=this.c
t=A.N(u.a,n.b,p,p,20)
s=o.ok
r=s.x
r=r==null?p:r.aH(n.k3,B.A)
r=A.d(u.b,p,p,p,p,p,r,p,p,p)
s=s.z
if(s==null)n=p
else{q=n.rx
n=s.dZ(q==null?n.k3:q,1.45)}s=x.u
return new A.bZ(new A.O(m,p,v,w,p,p,B.r),B.aq,new A.I(B.F,A.y(A.a([t,B.B,A.Q(A.v(A.a([r,B.O,A.d(u.c,p,p,p,p,p,n,p,p,p)],s),B.m,p,B.d,B.h,0,B.j),1,p)],s),B.m,p,B.d,B.h,0,p,p),p),p)}}
C.aVE.prototype={
u(d){var w,v,u,t,s=A.e(d,B.b,x.F),r=[new C.alR(G.mq,s.gasl(),s.gask()),new C.alR(D.aKU,s.gasn(),s.gasm()),new C.alR(B.oi,s.gasp(),s.gaso())]
s=s.gasg()
w=x.u
v=A.a([],w)
for(u=0;u<3;++u){t=A.a([new C.aVD(r[u],null)],w)
if(u!==2)t.push(B.w)
B.e.A(v,t)}return new C.alu(E.P4,s,A.v(v,B.l,null,B.d,B.h,0,B.j),null)}}
C.alR.prototype={}
C.aVD.prototype={
u(d){var w,v=null,u=A.q(d),t=u.ax,s=t.b,r=s.v(0.1),q=A.B(8),p=this.c
q=A.S(v,A.N(p.a,s,v,v,20),B.o,v,v,new A.O(r,v,v,q,v,v,B.r),v,36,v,v,v,v,v,36)
r=u.ok
s=r.x
s=s==null?v:s.aj(B.A)
s=A.d(p.b,v,v,v,v,v,s,v,v,v)
r=r.z
if(r==null)t=v
else{w=t.rx
t=r.dZ(w==null?t.k3:w,1.45)}r=x.u
return A.y(A.a([q,B.ad,A.Q(A.v(A.a([s,B.O,A.d(p.c,v,v,v,v,v,t,v,v,v)],r),B.m,v,B.d,B.h,0,B.j),1,v)],r),B.m,v,B.d,B.h,0,v,v)}}
C.aVM.prototype={
u(d){var w,v,u,t,s,r,q,p,o=null,n=A.q(d),m=A.e(d,B.b,x.F)
m.toString
w=n.ax
v=w.b
u=v.v(0.08)
t=A.B(8)
s=A.aE(v.v(0.16),B.u,1)
v=A.N(T.kM,v,o,o,22)
r=m.gasj()
q=n.ok.z
p=q==null
r=A.eK(o,o,o,o,o,o,o,o,o,p?o:q.aj(B.A),r)
m=m.gasi()
if(p)w=o
else{p=w.rx
w=q.dZ(p==null?w.k3:p,1.45)}return new A.bZ(new A.O(u,o,s,t,o,o,B.r),B.aq,new A.I(B.F,A.y(A.a([v,B.B,A.Q(A.dqi(A.eK(A.a([r,A.eK(o,o,o,o,o,o,o,o,o,w,m)],x.d),o,o,o,o,o,o,o,o,o,o),o,o),1,o)],x.u),B.m,o,B.d,B.h,0,o,o),o),o)}}
C.alu.prototype={
u(d){var w,v=null,u=A.q(d),t=A.N(this.c,u.ax.b,v,v,v),s=u.ok.w
s=s==null?v:s.aj(B.A)
w=x.u
return A.b8(v,v,A.v(A.a([A.y(A.a([t,B.B,A.Q(A.d(this.d,v,v,v,v,v,s,v,v,v),1,v)],w),B.m,v,B.d,B.h,0,v,v),B.n,this.e],w),B.m,v,B.d,B.h,0,B.j),v,B.a6,v,B.b4,!1,v)}}
C.L2.prototype={
u(d){return D.af5}}
var z=a.updateTypes([])
C.c5Y.prototype={
$2(d,e){var w,v,u=null,t=e.b
if(t==null)t=y.d
w=A.cU(d,16,16,!0,16)
v=this.a
return A.b2(A.aH(new A.ba(L.bz,A.v(A.a([new C.aVo(new C.c5T(v,d,t),new C.c5U(v,d),new C.c5V(v,d),new C.c5W(v,d),u),B.n,D.bYt,B.n,new C.aQA(t,e.a===B.qs,new C.c5X(v,d,t),u),B.n,D.bVX,B.n,D.bYE],x.u),B.aj,u,B.d,B.h,0,B.j),u),u,u,u),B.t,u,B.x,u,u,w,u,u,B.y)},
$S:1551}
C.c5T.prototype={
$0(){return this.a.bfP(this.b,this.c)},
$S:0}
C.c5U.prototype={
$0(){A.aL(this.b,!1).f.aG(D.bcu,x.q)
return null},
$S:0}
C.c5V.prototype={
$0(){A.aL(this.b,!1).f.aG(N.Ai,x.q)
return null},
$S:0}
C.c5W.prototype={
$0(){var w=this.b,v=x.q
if(A.aC(w,B.ak,x.x).w.a.a>=1100)A.aL(w,!1).f.aG(E.FI,v)
else A.aL(w,!1).f.aG(E.a6Q,v)
return null},
$S:0}
C.c5X.prototype={
$0(){return this.a.bfK(this.b,this.c)},
$S:0};(function inheritance(){var w=a.inherit,v=a.inheritMany
w(C.azi,A.bS)
w(C.a2W,A.J)
w(C.aJm,A.R)
w(C.c5Y,A.c0)
v(A.bw,[C.c5T,C.c5U,C.c5V,C.c5W,C.c5X])
v(A.x,[C.aVo,C.aQA,C.aO0,C.aJ5,C.aVE,C.aVD,C.aVM,C.alu,C.L2])
v(A.G,[C.a_1,C.alR])})()
A.aV(b.typeUniverse,JSON.parse('{"azi":{"bS":["~"]},"a2W":{"J":[],"m":[]},"aJm":{"R":["a2W"]},"aVo":{"x":[],"m":[]},"aQA":{"x":[],"m":[]},"aO0":{"x":[],"m":[]},"aJ5":{"x":[],"m":[]},"aVE":{"x":[],"m":[]},"aVD":{"x":[],"m":[]},"aVM":{"x":[],"m":[]},"alu":{"x":[],"m":[]},"L2":{"x":[],"m":[]}}'))
var y={d:"https://agoramarketapi.purrtechllc.com/api/mcp/user/v6"}
var x=(function rtii(){var w=A.A
return{F:w("bv"),e:w("T<xB?>"),d:w("w<iY>"),u:w("w<m>"),E:w("Gm"),x:w("dG"),w:w("o"),c:w("xB?"),q:w("G?"),v:w("~")}})();(function constants(){D.af5=new C.a2W(null)
D.aKU=new A.X(984528,"MaterialIcons",!1)
D.aKV=new A.X(984544,"MaterialIcons",!1)
D.aLd=new A.aq(F.P6,20,null,null,null)
D.aKH=new A.X(983658,"MaterialIcons",!1)
D.aMj=new A.aq(D.aKH,18,null,null,null)
D.aK5=new A.X(62616,"MaterialIcons",!0)
D.aNl=new A.aq(D.aK5,18,null,null,null)
D.bcu=new C.azi("McpToolsCatalogRoute",null,B.ac,B.ac,null,"")
D.bVX=new C.aO0(null)
D.bYt=new C.aVE(null)
D.bYE=new C.aVM(null)})()};
(a=>{a["nU5M188R5ZPuYVZPSpEY1ixY5Oo="]=a.current})($__dart_deferred_initializers__);