((a,b)=>{a[b]=a[b]||{}})(self,"$__dart_deferred_initializers__")
$__dart_deferred_initializers__.current=function(a,b,c,$){var A,B
A=c[0]
B=c[514]
var z=a.updateTypes([]);(function constants(){B.xM=new A.a0(58913,"MaterialIcons",!1)})()};
(a=>{a["Q078vU9z3UP6CG42dcQnoSjbjvM="]=a.current})($__dart_deferred_initializers__);