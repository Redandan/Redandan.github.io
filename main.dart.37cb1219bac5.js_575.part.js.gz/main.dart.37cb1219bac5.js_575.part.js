((a,b)=>{a[b]=a[b]||{}})(self,"$__dart_deferred_initializers__")
$__dart_deferred_initializers__.current=function(a,b,c,$){var B,A,C
B=c[0]
A=c[2]
C=c[768]
var z=a.updateTypes([]);(function constants(){C.af4=new B.ag(!0,A.G,null,null,null,null,12,A.a6,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null)})()};
(a=>{a["PxVhZKD241HYsE0NJWNDSBOTmMI="]=a.current})($__dart_deferred_initializers__);