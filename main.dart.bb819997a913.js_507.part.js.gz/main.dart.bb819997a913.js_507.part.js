((a,b)=>{a[b]=a[b]||{}})(self,"$__dart_deferred_initializers__")
$__dart_deferred_initializers__.current=function(a,b,c,$){var A,C,B={b0w:function b0w(d){this.a=d},
ec8(d,e,f,g,h){return new B.aI6(e,f,h,d,g)},
aI6:function aI6(d,e,f,g,h){var _=this
_.a=d
_.b=e
_.y=f
_.z=g
_.Q=h}}
A=c[0]
C=c[2]
B=a.updateHolder(c[165],B)
B.b0w.prototype={}
B.aI6.prototype={
p(d,e){var x,w=this
if(e==null)return!1
if(w!==e){x=!1
if(e instanceof B.aI6)if(e.a===w.a)if(e.b===w.b)if(e.y==w.y)if(e.z==w.z)x=e.Q==w.Q}else x=!0
return x},
gj(d){var x,w,v=this,u=C.h.gj(v.a),t=C.h.gj(v.b),s=v.y
s=s==null?0:C.b.gj(s)
x=v.z
x=x==null?0:A.a8(x)
w=v.Q
w=w==null?0:A.a8(w)
return u+t+s+x+w},
l(d){var x=this
return"IssueSearchParam[page="+x.a+", size="+x.b+", startDate=null, endDate=null, keyword=null, sortBy=null, sortDirection=null, issueId=null, userId=null, username="+A.b(x.y)+", issueType="+A.b(x.z)+", status="+A.b(x.Q)+", operatorId=null, operatorName=null]"},
A(){var x,w=this,v=null,u="username",t="issueType",s=A.q(y.g,y.b)
s.h(0,"page",w.a)
s.h(0,"size",w.b)
s.h(0,"startDate",v)
s.h(0,"endDate",v)
s.h(0,"keyword",v)
s.h(0,"sortBy",v)
s.h(0,"sortDirection",v)
s.h(0,"issueId",v)
s.h(0,"userId",v)
x=w.y
if(x!=null)s.h(0,u,x)
else s.h(0,u,v)
x=w.z
if(x!=null)s.h(0,t,x)
else s.h(0,t,v)
x=w.Q
if(x!=null)s.h(0,"status",x)
else s.h(0,"status",v)
s.h(0,"operatorId",v)
s.h(0,"operatorName",v)
return s}}
var z=a.updateTypes([]);(function inheritance(){var x=a.inheritMany
x(A.A,[B.b0w,B.aI6])})()
var y={g:A.C("n"),b:A.C("@")}};
(a=>{a["BfAoqPOyJqh/NpwFGR53WjskMI0="]=a.current})($__dart_deferred_initializers__);