((a,b)=>{a[b]=a[b]||{}})(self,"$__dart_deferred_initializers__")
$__dart_deferred_initializers__.current=function(a,b,c,$){var C,A={lG:function lG(d){this.a=d}},B
C=c[0]
A=a.updateHolder(c[157],A)
B=c[682]
A.lG.prototype={
l(d){return this.a},
B(){return this.a}}
var z=a.updateTypes([]);(function inheritance(){var y=a.inherit
y(A.lG,C.G)})();(function constants(){var y=a.makeConstList
B.Ej=y(["HOME_DELIVERY","SEVEN_ELEVEN","FAMILY_MART","HILIFE","OK_MART"],C.A("w<o>"))
B.a6V=new A.lG("FAMILY_MART")
B.a6W=new A.lG("HILIFE")
B.a6X=new A.lG("HOME_DELIVERY")
B.a6Y=new A.lG("OK_MART")
B.a6Z=new A.lG("SEVEN_ELEVEN")})()};
(a=>{a["nH4+qG0XgeHb9wZeWDKVIxtY+Vs="]=a.current})($__dart_deferred_initializers__);