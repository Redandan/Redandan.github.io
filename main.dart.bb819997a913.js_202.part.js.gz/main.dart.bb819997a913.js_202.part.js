((a,b)=>{a[b]=a[b]||{}})(self,"$__dart_deferred_initializers__")
$__dart_deferred_initializers__.current=function(a,b,c,$){var A,B
A=c[0]
B=c[617]
var z=a.updateTypes([]);(function constants(){B.qs=new A.aX(20,20,10,null,null)})()};
(a=>{a["uXTnizEC9Q01ysYhqVov8eY7xjI="]=a.current})($__dart_deferred_initializers__);