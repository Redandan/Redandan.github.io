((a,b)=>{a[b]=a[b]||{}})(self,"$__dart_deferred_initializers__")
$__dart_deferred_initializers__.current=function(a,b,c,$){var A,B,G,H,E,I,K,C={
exR(){return new C.GZ(null)},
GZ:function GZ(d){this.a=d},
alH:function alH(){var _=this
_.e=_.d=""
_.c=_.a=null},
coc:function coc(d,e){this.a=d
this.b=e},
cod:function cod(d){this.a=d},
co9:function co9(d){this.a=d},
cob:function cob(d,e,f){this.a=d
this.b=e
this.c=f},
coa:function coa(d){this.a=d}},D,L,F
A=c[0]
B=c[2]
G=c[319]
H=c[317]
E=c[278]
I=c[269]
K=c[318]
C=a.updateHolder(c[5],C)
D=c[315]
L=c[320]
F=c[316]
C.GZ.prototype={
O(){return new C.alH()}}
C.alH.prototype={
Y(){this.a6()
this.bv7()},
bv7(){var x=0,w=A.l(y.f),v,u=2,t=[],s=this,r,q,p
var $async$bv7=A.h(function(d,e){if(d===1){t.push(e)
x=u}for(;;)switch(x){case 0:u=4
r=$.Ox()
x=!r.c?7:8
break
case 7:x=9
return A.c(r.cG(),$async$bv7)
case 9:case 8:if(s.c==null){x=1
break}s.n(new C.coc(s,r))
u=2
x=6
break
case 4:u=3
p=t.pop()
if(s.c==null){x=1
break}s.n(new C.cod(s))
x=6
break
case 3:x=2
break
case 6:case 1:return A.j(v,w)
case 2:return A.i(t.at(-1),w)}})
return A.k($async$bv7,w)},
asY(){var x=0,w=A.l(y.f)
var $async$asY=A.h(function(d,e){if(d===1)return A.i(e,w)
for(;;)switch(x){case 0:x=2
return A.c(A.uw(A.e4("/official.html",0,null),B.yn,null),$async$asY)
case 2:return A.j(null,w)}})
return A.k($async$asY,w)},
cUD(){return A.acS("web/icons/new_favicon/web-app-manifest-512x512.png",B.as,null,new C.co9(this),!1,B.d8,B.f7,null,116,null,116)},
c7t(d,e){var x=null,w=d.B(0.12),v=A.G(8)
return A.W(x,A.T(e,d,x,x,24),B.o,x,x,new A.R(w,x,x,v,x,x,B.r),x,x,x,x,B.X,x,x,x)},
u(a2){var x,w,v,u,t,s,r,q,p,o,n,m,l,k,j,i=this,h=null,g="Agora Market",f=y.p,e=A.f(a2,B.c,f),d=e.gNg(),a0=e.gawJ(),a1=y.e
e=A.a([A.ce(D.aVD,h,A.d(e.ga7H(),h,h,h,h,h,h,h,h,h),i.gdl1(),h)],a1)
x=i.c
x.toString
w=A.t(x)
x=i.c
x.toString
x=A.f(x,B.c,f)
v=x.ga34()
u=w.ax
t=u.p2
if(t==null)t=u.k2
s=u.ry
if(s==null){s=u.E
if(s==null)s=u.k3}s=A.aN(s.B(0.14),B.u,1)
s=A.W(h,new A.J(B.t7,i.cUD(),h),B.aR,h,h,new A.R(t,h,s,h,h,h,B.aW),h,96,h,h,h,h,h,96)
t=w.ok
r=t.f
r=A.d(g,h,h,h,h,h,r==null?h:r.av(B.F),h,h,h)
q=u.b
p=q.B(0.12)
o=A.G(8)
n=x.ga34()
m=t.as
q=A.W(h,A.d(n,h,h,h,h,h,m==null?h:m.aX(q,B.S),h,h,h),B.o,h,h,new A.R(p,h,h,o,h,h,B.r),h,h,h,h,D.aLD,h,h,h)
x=x.gawG()
t=t.z
if(t==null)u=h
else{p=u.rx
u=t.dm(p==null?u.k3:p,1.6)}u=A.w(A.a([s,B.a7,r,B.Q,q,B.n,A.d(x,h,h,h,h,h,u,B.az,h,h)],a1),B.l,h,B.e,B.f,0,B.j)
x=i.c
x.toString
w=A.t(x)
x=i.c
x.toString
x=A.f(x,B.c,f)
q=x.gNg()
r=x.gawA()
s=w.ok.z
t=s==null
if(t)p=h
else{p=w.ax
o=p.rx
p=s.dm(o==null?p.k3:o,1.8)}p=A.d(r,h,h,h,h,h,p,h,h,h)
x=x.gawI()
if(t)t=h
else{t=w.ax
r=t.rx
t=s.dm(r==null?t.k3:r,1.8)}t=A.w(A.a([p,B.n,A.d(x,h,h,h,h,h,t,h,h,h)],a1),B.m,h,B.e,B.f,0,B.j)
x=i.c
x.toString
w=A.t(x)
x=i.c
x.toString
x=A.f(x,B.c,f)
p=x.gb3F()
s=x.gblk()
r=w.ax
o=r.b
s=i.brI(o,x.gawE(),D.aTE,w,s)
n=x.gbgf()
m=r.y
n=i.brI(m,x.gawC(),D.aTg,w,n)
l=x.gbh1()
k=x.gawF()
r=r.CW
r=i.brI(r==null?m:r,k,D.aTA,w,l)
m=x.gbm5()
m=A.w(A.a([s,F.dy,n,F.dy,r,F.dy,i.brI(o,x.gawD(),D.aTz,w,m)],a1),B.m,h,B.e,B.f,0,B.j)
x=i.cX_()
o=i.cVg()
r=i.c
r.toString
w=A.t(r)
r=i.c
r.toString
f=A.f(r,B.c,f)
r=f.gUK()
n=f.UL(i.d)
s=w.ok.Q
l=s==null
if(l)k=h
else{k=w.ax
j=k.rx
k=s.a0(j==null?k.k3:j)}k=A.d(n,h,h,h,h,h,k,h,h,h)
n=A.W(h,h,B.o,w.ch,h,h,h,16,h,h,h,h,h,1)
f=f.aHn(i.e)
if(l)s=h
else{l=w.ax
j=l.rx
s=s.a0(j==null?l.k3:j)}return I.LP(e,A.a([new E.iS(g,u,B.fd,v,h),new E.iS(q,t,D.aT7,h,h),new E.iS(p,m,B.FS,h,h),x,o,new E.iS(r,A.z(A.a([k,B.ai,n,B.ai,A.d(f,h,h,h,h,h,s,h,h,h)],a1),B.l,h,B.b9,B.f,0,h,h),H.pt,h,h)],a1),B.fd,h,h,a0,d)},
brI(d,e,f,g,h){var x,w,v,u=null,t=d.B(0.05),s=A.G(8),r=A.aN(d.B(0.2),B.u,1),q=d.B(0.15),p=A.G(8)
p=A.W(u,A.T(f,d,u,u,24),B.o,u,u,new A.R(q,u,u,p,u,u,B.r),u,u,u,u,K.kp,u,u,u)
q=g.ax
x=q.k3
w=A.d(h,u,u,u,u,u,A.Y(u,u,x,u,u,u,u,u,u,u,u,17,u,u,B.F,u,u,!0,u,u,u,u,u,u,u,u),u,u,u)
v=g.ok.Q
if(v==null)q=u
else{q=q.rx
q=v.dm(q==null?x:q,1.5)}x=y.e
return A.W(u,A.z(A.a([p,B.ai,A.O(A.w(A.a([w,B.bw,A.d(e,u,u,u,u,u,q,u,u,u)],x),B.m,u,B.e,B.f,0,B.j),1,u)],x),B.m,u,B.e,B.f,0,u,u),B.o,u,u,new A.R(t,u,r,s,u,u,B.r),u,u,u,u,B.C,u,u,u)},
cX_(){var x,w=this.c
w.toString
x=A.t(w)
w=this.c
w.toString
w=A.f(w,B.c,y.p)
return new E.iS(w.gb0B(),A.cZ(new C.cob(this,w,x)),D.SR,null,null)},
c7H(d,e,f,g,h){var x,w,v,u,t,s,r=null,q=g.ax,p=q.p2
if(p==null)p=q.k2
x=A.G(8)
w=q.ry
if(w==null){w=q.E
if(w==null)w=q.k3}w=A.aN(w.B(0.14),B.u,1)
v=this.c7t(d,f)
u=g.ok
t=u.w
t=A.d(h,r,r,r,r,r,t==null?r:t.av(B.F),r,r,r)
u=u.Q
if(u==null)q=r
else{s=q.rx
q=u.dm(s==null?q.k3:s,1.6)}return A.W(r,A.w(A.a([v,B.n,t,B.v,A.d(e,r,r,r,r,r,q,r,r,r)],y.e),B.m,r,B.e,B.f,0,B.j),B.o,r,r,new A.R(p,r,w,x,r,r,B.r),r,r,r,r,B.C,r,r,r)},
cVg(){var x,w,v,u=this,t=u.c
t.toString
t=A.f(t,B.c,y.p)
x=t.gaM2()
w=t.gop()
v=u.c
v.toString
w=u.cVi(A.t(v).ax.b,G.SQ,"contact@agora.com",w)
t=t.ga7H()
v=u.c
v.toString
return new E.iS(x,A.w(A.a([w,L.Ds,u.c7h(A.t(v).ax.b,D.ST,new C.coa(u),"agora.io",t)],y.e),B.m,null,B.e,B.f,0,B.j),D.aTd,null,null)},
c7h(d,e,f,g,h){var x,w,v,u,t,s,r=null,q=this.c
q.toString
x=A.t(q)
q=A.G(8)
w=this.c7t(d,e)
v=x.ok
u=v.z
u=A.d(h,r,r,r,r,r,u==null?r:u.av(B.S),r,r,r)
v=v.Q
if(v==null)v=r
else{t=x.ax
s=t.rx
v=v.a0(s==null?t.k3:s)}t=y.e
t=A.a([w,B.ai,A.O(A.w(A.a([u,B.P,A.d(g,r,r,r,r,r,v,r,r,r)],t),B.m,r,B.e,B.f,0,B.j),1,r)],t)
if(f!=null){w=x.ax
v=w.rx
t.push(A.T(D.aT6,v==null?w.k3:v,r,r,16))}return A.el(!1,q,!0,new A.J(B.cJ,A.z(t,B.l,r,B.e,B.f,0,r,r),r),r,!0,!1,r,r,r,r,r,r,r,r,r,r,r,f,r,r,r,r,r,r,r)},
cVi(d,e,f,g){return this.c7h(d,e,null,f,g)}}
var z=a.updateTypes(["B<~>()"])
C.coc.prototype={
$0(){var x=this.a,w=this.b
x.d=w.Vd()
x.e=w.bG_()},
$S:0}
C.cod.prototype={
$0(){var x=this.a
x.d="1.0.0"
x.e="1"},
$S:0}
C.co9.prototype={
$3(d,e,f){return D.aUz},
$S:116}
C.cob.prototype={
$2(d,e){var x,w,v,u,t,s,r=null,q=e.b
if(q>=640)q=(q-12)/2
x=this.a
w=this.b
v=w.gbf2()
u=this.c
t=u.ax
v=x.c7H(t.b,w.gawH(),D.SR,u,v)
s=w.gbfr()
return A.bi(B.a0,A.a([new A.ad(q,r,v,r),new A.ad(q,r,x.c7H(t.y,w.gawK(),D.aTG,u,s),r)],y.e),B.ac,r,12,12)},
$S:101}
C.coa.prototype={
$0(){return this.a.asY()},
$S:0};(function installTearOffs(){var x=a._instance_0u
x(C.alH.prototype,"gdl1","asY",0)})();(function inheritance(){var x=a.inherit,w=a.inheritMany
x(C.GZ,A.L)
x(C.alH,A.S)
w(A.bt,[C.coc,C.cod,C.coa])
x(C.co9,A.bu)
x(C.cob,A.c9)})()
A.b0(b.typeUniverse,JSON.parse('{"GZ":{"L":[],"m":[]},"alH":{"S":["GZ"]}}'))
var y={p:A.C("bw"),e:A.C("v<m>"),f:A.C("~")};(function constants(){D.aLD=new A.ar(14,6,14,6)
D.aT6=new A.a0(62841,"MaterialIcons",!0)
D.aT7=new A.a0(62967,"MaterialIcons",!1)
D.aTd=new A.a0(63078,"MaterialIcons",!1)
D.SR=new A.a0(63336,"MaterialIcons",!1)
D.aTg=new A.a0(63341,"MaterialIcons",!1)
D.ST=new A.a0(63551,"MaterialIcons",!1)
D.aTz=new A.a0(983403,"MaterialIcons",!1)
D.aTA=new A.a0(983541,"MaterialIcons",!1)
D.aTE=new A.a0(983663,"MaterialIcons",!1)
D.aTG=new A.a0(983699,"MaterialIcons",!1)
D.aUz=new A.at(B.y4,56,null,null,null)
D.aVD=new A.at(D.ST,18,null,null,null)})()};
(a=>{a["dsL9PRzxecwM8o2KiebucPCrHbc="]=a.current})($__dart_deferred_initializers__);