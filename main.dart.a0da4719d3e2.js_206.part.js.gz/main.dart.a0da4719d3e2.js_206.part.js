((a,b)=>{a[b]=a[b]||{}})(self,"$__dart_deferred_initializers__")
$__dart_deferred_initializers__.current=function(a,b,c,$){var A,C,B={Qk:function Qk(d,e,f,g){var _=this
_.c=d
_.d=e
_.e=f
_.a=g},aWY:function aWY(){var _=this
_.d=$
_.e=null
_.f=$
_.c=_.a=null},cYi:function cYi(d,e){this.a=d
this.b=e},cYh:function cYh(d,e){this.a=d
this.b=e},cYj:function cYj(d){this.a=d},cYk:function cYk(d,e){this.a=d
this.b=e}}
A=c[0]
C=c[2]
B=a.updateHolder(c[168],B)
B.Qk.prototype={
O(){return new B.aWY()}}
B.aWY.prototype={
Y(){var x=this
x.a5()
x.f=x.a.d
x.c0U()},
aK(d){var x,w=this
w.b1(d)
x=w.a
if(d.c!==x.c||d.d!==x.d||d.e!==x.e){w.f=x.d
w.c0U()}},
c0U(){var x,w,v=this,u=$.dGC
$.dGC=u+1
v.d="storefront-html-preview-"+u
x=b.G.document.createElement("iframe")
x.srcdoc=v.a.c
x.style.border="0"
x.style.width="100%"
u=x.style
w=v.f
w===$&&A.f()
u.height=A.b(w)+"px"
x.style.overflow="hidden"
x.style.display="block"
x.style.pointerEvents="none"
x.setAttribute("sandbox","allow-same-origin")
x.setAttribute("referrerpolicy","no-referrer")
x.setAttribute("loading","lazy")
x.setAttribute("scrolling","no")
x.addEventListener("load",A.eL(new B.cYi(v,x)))
v.e=x
$.b13()
u=v.d
$.Du().a_Y(u,new B.cYj(x),!0)},
c1g(d){var x,w,v,u,t,s,r,q,p=this
if(p.c==null||p.e!==d)return
try{x=d.contentDocument
s=x
w=s==null?null:s.body
s=x
v=s==null?null:s.documentElement
if(w==null||v==null)return
w.style.overflow="hidden"
if(v!=null&&A.iq(v,"HTMLElement"))v.style.overflow="hidden"
s=w.scrollHeight
r=v.scrollHeight
u=Math.max(A.lP(s),A.lP(r))
t=C.k.cf(u,p.a.d,12e3)
s=p.f
s===$&&A.f()
if(Math.abs(t-s)<1)return
p.p(new B.cYk(p,t))
d.style.height=A.b(t)+"px"}catch(q){s=d.style
r=p.a.d
s.height=A.b(r)+"px"}},
u(d){var x,w,v,u,t,s=this,r=null,q=A.q(d),p=s.f
p===$&&A.f()
x=s.a.e
w=x?C.a_:q.ax.k2
v=A.B(x?0:8)
x=x?r:A.aE(q.ch.v(0.24),C.u,1)
u=s.f
t=s.d
t===$&&A.f()
return A.Yu(A.S(r,new A.ab(r,u,A.dow(r,C.FB,t),r),C.aQ,r,new A.at(0,1/0,p,1/0),new A.O(w,r,x,v,r,r,C.r),r,r,r,r,r,r,r,1/0),r,C.rI)}}
var z=a.updateTypes([])
B.cYi.prototype={
$1(d){var x=this.a,w=this.b
x.c1g(w)
A.dr(C.kC,new B.cYh(x,w),y.b)},
$S:51}
B.cYh.prototype={
$0(){return this.a.c1g(this.b)},
$S:0}
B.cYj.prototype={
$1(d){return this.a},
$S:1603}
B.cYk.prototype={
$0(){return this.a.f=this.b},
$S:0};(function inheritance(){var x=a.inherit,w=a.inheritMany
x(B.Qk,A.J)
x(B.aWY,A.R)
w(A.by,[B.cYi,B.cYj])
w(A.bw,[B.cYh,B.cYk])})()
A.aV(b.typeUniverse,JSON.parse('{"Qk":{"J":[],"m":[]},"aWY":{"R":["Qk"]}}'))
var y={b:A.A("~")};(function staticFields(){$.dGC=0})()};
(a=>{a["HJnGIgJdbDArvIF71Ntk1SGZ4q0="]=a.current})($__dart_deferred_initializers__);