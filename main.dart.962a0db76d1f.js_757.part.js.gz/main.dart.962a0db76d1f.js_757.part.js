((a,b)=>{a[b]=a[b]||{}})(self,"$__dart_deferred_initializers__")
$__dart_deferred_initializers__.current=function(a,b,c,$){var A,B
A=c[0]
B=c[757]
var z=a.updateTypes([]);(function constants(){B.K9=new A.br("\u67e5\u770b\u8a73\u60c5",null,null,null,null,null,null,null,null,null,null)})()};
(a=>{a["QkEIPOcNoi3ahP/QQBJZqNSAwhg="]=a.current})($__dart_deferred_initializers__);