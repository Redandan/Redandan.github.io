((a,b)=>{a[b]=a[b]||{}})(self,"$__dart_deferred_initializers__")
$__dart_deferred_initializers__.current=function(a,b,c,$){var B,C,A={
bgT(d,e){var x,w,v,u,t=d.to
if(t.length!==0){x=B.V(t).k("F<1,tV>")
t=B.P(new B.F(t,new A.dWD(e),x),x.k("ai.E"))
return t}w=A.dSV(d.w)
if(w!=null){t=A.dSV(d.x)
x=d.r
x=x>0?x:d.f
return B.a([new A.tV(w,t,d.y,x,A.eX1(d))],y.a)}v=d.ry
t=v==null
if(!t){x=v.c6
x=x.gcc(x)}else x=!1
if(x){x=v.c6
u=x.gS(x)}else u=null
x=d.f
return B.a([new A.tV(A.eYc(d,t?null:v.b,e),u,d.y,x,d.Q*x)],y.a)},
eX1(d){var x,w=d.f
if(d.r>w)return d.as
x=d.Q*w
if(x>0)return x
return d.as},
dSV(d){var x=d==null?null:C.b.F(d)
if(x==null||x.length===0)return null
return x},
eYc(d,e,f){var x,w,v=A.dSV(e)
if(v==null){x=f==null?null:f.gnN()
return x==null?"Unknown product":x}x=d.r
if(x>1){w=f==null?null:f.ga6T()
if(w==null)w="items"
return v+" \xb7 "+x+" "+w}return v},
tV:function tV(d,e,f,g,h){var _=this
_.a=d
_.b=e
_.c=f
_.d=g
_.e=h},
dWD:function dWD(d){this.a=d}}
B=c[0]
C=c[2]
A=a.updateHolder(c[259],A)
A.tV.prototype={}
var z=a.updateTypes(["tV(vB)"])
A.dWD.prototype={
$1(d){var x,w,v=this.a,u=d.r
if(u==null)u=1
x=d.as
if(x==null){x=d.Q
x=x!=null?x*u:null
w=x}else w=x
if(w==null)w=0
x=A.dSV(d.d)
if(x==null)v=v==null?null:v.gnN()
else v=x
if(v==null)v="Unknown product"
return new A.tV(v,d.e,d.f,u,w)},
$S:z+0};(function inheritance(){var x=a.inherit
x(A.tV,B.A)
x(A.dWD,B.bt)})()
var y={a:B.C("v<tV>")}};
(a=>{a["LYJ9w23d/WlpA7ESpj/s57T2g5w="]=a.current})($__dart_deferred_initializers__);