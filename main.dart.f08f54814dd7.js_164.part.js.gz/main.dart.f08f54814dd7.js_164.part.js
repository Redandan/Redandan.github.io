((a,b)=>{a[b]=a[b]||{}})(self,"$__dart_deferred_initializers__")
$__dart_deferred_initializers__.current=function(a,b,c,$){var A,C,B={
bGX(d,e,f){return new B.acT(d,e,f,null)},
bGY(d,e,f){var x,w,v=f.a,u=e.a,t=Math.pow(v[0]-u[0],2)+Math.pow(v[1]-u[1],2)
if(t===0)return e
x=d.aw(0,e)
w=f.aw(0,e)
return e.au(0,w.wZ(A.an(x.Pp(w)/t,0,1)))},
eDj(d,e){var x,w,v,u,t,s,r,q=e.a,p=d.aw(0,q),o=e.b,n=o.aw(0,q),m=e.d,l=m.aw(0,q),k=p.Pp(n),j=n.Pp(n),i=p.Pp(l),h=l.Pp(l)
if(0<=k&&k<=j&&0<=i&&i<=h)return d
x=e.c
w=[B.bGY(d,q,o),B.bGY(d,o,x),B.bGY(d,x,m),B.bGY(d,m,q)]
v=A.cG()
for(q=d.a,u=1/0,t=0;t<4;++t){s=w[t]
o=s.a
r=Math.sqrt(Math.pow(q[0]-o[0],2)+Math.pow(q[1]-o[1],2))
if(r<u){v.b=s
u=r}}return v.an()},
em1(d,e,f){return Math.log(f/d)/Math.log(e/100)},
en3(d,e){var x,w,v,u,t,s,r=new A.cZ(new Float64Array(16))
r.dT(d)
r.no(r)
x=e.a
w=e.b
v=new A.eD(new Float64Array(3))
v.iI(x,w,0)
v=r.qR(v)
u=e.c
t=new A.eD(new Float64Array(3))
t.iI(u,w,0)
t=r.qR(t)
w=e.d
s=new A.eD(new Float64Array(3))
s.iI(u,w,0)
s=r.qR(s)
u=new A.eD(new Float64Array(3))
u.iI(x,w,0)
u=r.qR(u)
x=new A.eD(new Float64Array(3))
x.dT(v)
w=new A.eD(new Float64Array(3))
w.dT(t)
v=new A.eD(new Float64Array(3))
v.dT(s)
t=new A.eD(new Float64Array(3))
t.dT(u)
return new E.a1C(x,w,v,t)},
elP(d,e){var x,w,v,u,t,s,r=[e.a,e.b,e.c,e.d]
for(x=C.P,w=0;w<4;++w){v=r[w]
u=B.eDj(v,d).a
t=v.a
s=u[0]-t[0]
t=u[1]-t[1]
if(Math.abs(s)>Math.abs(x.a))x=new A.N(s,x.b)
if(Math.abs(t)>Math.abs(x.b))x=new A.N(x.a,t)}return B.e4q(x)},
e4q(d){return new A.N(A.na(C.k.Z(d.a,9)),A.na(C.k.Z(d.b,9)))},
eUL(d,e){if(d.p(0,e))return null
return Math.abs(e.a-d.a)>Math.abs(e.b-d.b)?C.aa:C.y},
acT:function acT(d,e,f,g){var _=this
_.w=d
_.at=e
_.ax=f
_.a=g},
apF:function apF(d,e,f,g){var _=this
_.d=$
_.e=d
_.f=e
_.w=_.r=null
_.z=_.y=_.x=$
_.at=_.as=_.Q=null
_.ay=_.ax=0
_.ch=null
_.dx$=f
_.dy$=g
_.c=_.a=null},
cVA:function cVA(){},
b3E:function b3E(d,e,f,g,h,i,j){var _=this
_.c=d
_.d=e
_.e=f
_.f=g
_.r=h
_.w=i
_.a=j},
ap5:function ap5(d,e){this.a=d
this.b=e},
awL:function awL(){}},D,E
A=c[0]
C=c[2]
B=a.updateHolder(c[272],B)
D=c[814]
E=c[278]
B.acT.prototype={
S(){var x=null,w=y.z
return new B.apF(new A.bh(x,w),new A.bh(x,w),x,x)}}
B.apF.prototype={
gfo(){var x=this.d
if(x===$){this.a.toString
x=E.ei7()
this.d=x}return x},
gbry(){var x,w=$.am.ad$.x.i(0,this.e).gaK()
w.toString
x=y.g.a(w).gL()
this.a.toString
return C.J.aXL(new A.ao(0,0,0+x.a,0+x.b))},
gbz6(){var x=$.am.ad$.x.i(0,this.f).gaK()
x.toString
x=y.g.a(x).gL()
return new A.ao(0,0,0+x.a,0+x.b)},
a_i(a0,a1){var x,w,v,u,t,s,r,q,p,o,n,m,l,k,j,i,h,g,f,e,d=this
if(a1.p(0,C.P)){x=new A.cZ(new Float64Array(16))
x.dT(a0)
return x}if(d.Q!=null){d.a.toString
switch(3){case 3:break}}w=new A.cZ(new Float64Array(16))
w.dT(a0)
w.hC(a1.a,a1.b,0,1)
v=B.en3(w,d.gbz6())
if(d.gbry().gcvI(0))return w
x=d.gbry()
u=d.ay
t=new A.cZ(new Float64Array(16))
t.hD()
s=x.c
r=x.a
q=s-r
p=x.d
x=x.b
o=p-x
t.hC(q/2,o/2,0,1)
t.zk(u)
t.hC(-q/2,-o/2,0,1)
u=new A.eD(new Float64Array(3))
u.iI(r,x,0)
u=t.qR(u)
q=new A.eD(new Float64Array(3))
q.iI(s,x,0)
q=t.qR(q)
x=new A.eD(new Float64Array(3))
x.iI(s,p,0)
x=t.qR(x)
s=new A.eD(new Float64Array(3))
s.iI(r,p,0)
s=t.qR(s)
r=new Float64Array(3)
new A.eD(r).dT(u)
u=new Float64Array(3)
new A.eD(u).dT(q)
q=new Float64Array(3)
new A.eD(q).dT(x)
x=new Float64Array(3)
new A.eD(x).dT(s)
s=r[0]
p=u[0]
o=q[0]
n=x[0]
m=Math.min(s,Math.min(p,Math.min(o,n)))
r=r[1]
u=u[1]
q=q[1]
x=x[1]
l=Math.min(r,Math.min(u,Math.min(q,x)))
k=Math.max(s,Math.max(p,Math.max(o,n)))
j=Math.max(r,Math.max(u,Math.max(q,x)))
x=new A.eD(new Float64Array(3))
x.iI(m,l,0)
u=new A.eD(new Float64Array(3))
u.iI(k,l,0)
s=new A.eD(new Float64Array(3))
s.iI(k,j,0)
r=new A.eD(new Float64Array(3))
r.iI(m,j,0)
q=new A.eD(new Float64Array(3))
q.dT(x)
x=new A.eD(new Float64Array(3))
x.dT(u)
u=new A.eD(new Float64Array(3))
u.dT(s)
s=new A.eD(new Float64Array(3))
s.dT(r)
i=new E.a1C(q,x,u,s)
h=B.elP(i,v)
if(h.p(0,C.P))return w
x=w.bH9().a
u=x[0]
x=x[1]
g=a0.IK()
u-=h.a*g
x-=h.b*g
f=new A.cZ(new Float64Array(16))
f.dT(a0)
s=new A.eD(new Float64Array(3))
s.iI(u,x,0)
f.c3q(s)
e=B.elP(i,B.en3(f,d.gbz6()))
if(e.p(0,C.P))return f
s=e.a===0
if(!s&&e.b!==0){x=new A.cZ(new Float64Array(16))
x.dT(a0)
return x}u=s?u:0
x=e.b===0?x:0
s=new A.cZ(new Float64Array(16))
s.dT(a0)
r=new A.eD(new Float64Array(3))
r.iI(u,x,0)
s.c3q(r)
return s},
bOp(d,e){var x,w,v,u,t,s,r,q=this
if(e===1){x=new A.cZ(new Float64Array(16))
x.dT(d)
return x}w=q.gfo().a.IK()
x=q.gbz6()
v=q.gbry()
u=q.gbz6()
t=q.gbry()
s=Math.max(w*e,Math.max((x.c-x.a)/(v.c-v.a),(u.d-u.b)/(t.d-t.b)))
t=q.a
r=A.an(s,t.ax,t.at)/w
x=new A.cZ(new Float64Array(16))
x.dT(d)
x.r1(r,r,r,1)
return x},
dne(d,e,f){var x,w,v,u
if(e===0){x=new A.cZ(new Float64Array(16))
x.dT(d)
return x}w=this.gfo().qQ(f)
x=new A.cZ(new Float64Array(16))
x.dT(d)
v=w.a
u=w.b
x.hC(v,u,0,1)
x.zk(-e)
x.hC(-v,-u,0,1)
return x},
btk(d){var x
A:{x=!0
if(D.ccp===d){x=!1
break A}if(D.Bi===d){this.a.toString
break A}if(D.vB===d||d==null){this.a.toString
break A}x=null}return x},
ccK(d){this.a.toString
if(Math.abs(d.d-1)>Math.abs(0))return D.Bi
else return D.vB},
dqk(d){var x,w,v=this
v.a.toString
x=v.y
x===$&&A.e()
w=x.r
if(w!=null&&w.a!=null){x.hx()
x=v.y
x.sC(x.a)
x=v.r
if(x!=null)x.a.T(v.gbtS())
v.r=null}x=v.z
x===$&&A.e()
w=x.r
if(w!=null&&w.a!=null){x.hx()
x=v.z
x.sC(x.a)
x=v.w
if(x!=null)x.a.T(v.gbu2())
v.w=null}v.Q=v.ch=null
v.at=v.gfo().a.IK()
v.as=v.gfo().qQ(d.b)
v.ax=v.ay},
dqm(d){var x,w,v,u,t,s,r=this,q=r.gfo().a.IK(),p=r.x=d.c,o=r.gfo().qQ(p),n=r.ch
if(n===D.vB)n=r.ch=r.ccK(d)
else if(n==null){n=r.ccK(d)
r.ch=n}if(!r.btk(n)){r.a.toString
return}switch(n.a){case 1:n=r.at
n.toString
r.gfo().sC(r.bOp(r.gfo().a,n*d.d/q))
x=r.gfo().qQ(p)
n=r.gfo()
w=r.gfo().a
v=r.as
v.toString
n.sC(r.a_i(w,x.aw(0,v)))
u=r.gfo().qQ(p)
p=r.as
p.toString
if(!B.e4q(p).p(0,B.e4q(u)))r.as=u
break
case 2:n=d.r
if(n===0){r.a.toString
return}w=r.ax
w.toString
t=w+n
r.gfo().sC(r.dne(r.gfo().a,r.ay-t,p))
r.ay=t
break
case 0:if(d.d!==1){r.a.toString
return}if(r.Q==null){n=r.as
n.toString
r.Q=B.eUL(n,o)}n=r.as
n.toString
s=o.aw(0,n)
r.gfo().sC(r.a_i(r.gfo().a,s))
r.as=r.gfo().qQ(p)
break}r.a.toString},
dqi(d){var x,w,v,u,t,s,r,q,p,o,n,m=this
m.a.toString
m.as=m.ax=m.at=null
x=m.r
if(x!=null)x.a.T(m.gbtS())
x=m.w
if(x!=null)x.a.T(m.gbu2())
x=m.y
x===$&&A.e()
x.sC(x.a)
x=m.z
x===$&&A.e()
x.sC(x.a)
x=m.ch
if(!m.btk(x)){m.Q=null
return}A:{if(D.vB===x){x=d.a.a
if(x.gfz()<50){m.Q=null
return}w=m.gfo().a.bH9().a
v=w[0]
w=w[1]
m.a.toString
u=A.bCr(0.0000135,v,x.a,0)
m.a.toString
t=A.bCr(0.0000135,w,x.b,0)
x=x.gfz()
m.a.toString
s=B.em1(x,0.0000135,10)
x=u.ga5P()
r=t.ga5P()
q=y.A
p=A.ds(C.mZ,m.y,null)
m.r=new A.bm(p,new A.bn(new A.N(v,w),new A.N(x,r),q),q.k("bm<bx.T>"))
m.y.e=A.dM(0,0,0,C.k.b0(s*1000),0)
p.a4(m.gbtS())
m.y.dv()
break A}if(D.Bi===x){x=d.b
w=Math.abs(x)
if(w<0.1){m.Q=null
return}o=m.gfo().a.IK()
m.a.toString
n=A.bCr(0.0026999999999999997,o,x/10,0)
m.a.toString
s=B.em1(w,0.0000135,0.1)
x=n.lB(s)
w=y.f
v=A.ds(C.mZ,m.z,null)
m.w=new A.bm(v,new A.bn(o,x,w),w.k("bm<bx.T>"))
m.z.e=A.dM(0,0,0,C.k.b0(s*1000),0)
v.a4(m.gbu2())
m.z.dv()
break A}break A}},
dk4(d){var x,w,v,u,t,s,r,q=this,p=d.gf1(),o=d.gbD()
if(y.l.b(d)){x=d.ghg()===C.eV
if(x)q.a.toString
if(x){q.a.toString
x=o.au(0,d.gvi())
w=d.gvi()
v=A.Sz(d.gfh(),null,w,x)
if(!q.btk(D.vB)){q.a.toString
return}u=q.gfo().qQ(p)
t=q.gfo().qQ(p.aw(0,v))
q.gfo().sC(q.a_i(q.gfo().a,t.aw(0,u)))
q.a.toString
return}if(d.gvi().b===0)return
x=d.gvi()
q.a.toString
s=Math.exp(-x.b/200)}else if(y.B.b(d))s=d.gjV()
else return
q.a.toString
if(!q.btk(D.Bi))return
u=q.gfo().qQ(p)
q.gfo().sC(q.bOp(q.gfo().a,s))
r=q.gfo().qQ(p)
q.gfo().sC(q.a_i(q.gfo().a,r.aw(0,u)))
q.a.toString},
de5(){var x,w,v,u,t,s=this,r=s.y
r===$&&A.e()
r=r.r
if(!(r!=null&&r.a!=null)){s.Q=null
r=s.r
if(r!=null)r.a.T(s.gbtS())
s.r=null
r=s.y
r.sC(r.a)
return}r=s.gfo().a.bH9().a
x=r[0]
r=r[1]
w=s.gfo()
v=s.gfo().a
u=s.gfo()
t=s.r
w.sC(s.a_i(v,u.qQ(t.b.aN(t.a.gC())).aw(0,s.gfo().qQ(new A.N(x,r)))))},
dgh(){var x,w,v,u,t,s=this,r=s.z
r===$&&A.e()
r=r.r
if(!(r!=null&&r.a!=null)){s.Q=null
r=s.w
if(r!=null)r.a.T(s.gbu2())
s.w=null
r=s.z
r.sC(r.a)
return}r=s.w
x=r.b.aN(r.a.gC())
r=s.gfo().a.IK()
w=s.gfo()
v=s.x
v===$&&A.e()
u=w.qQ(v)
s.gfo().sC(s.bOp(s.gfo().a,x/r))
t=s.gfo().qQ(s.x)
s.gfo().sC(s.a_i(s.gfo().a,t.aw(0,u)))},
dij(){this.n(new B.cVA())},
Y(){var x=this,w=null
x.a6()
x.y=A.cL(w,w,w,1,w,x)
x.z=A.cL(w,w,w,1,w,x)
x.gfo().a4(x.gcem())},
aV(d){this.b_(d)
this.a.toString
return},
q(){var x=this,w=x.y
w===$&&A.e()
w.q()
w=x.z
w===$&&A.e()
w.q()
x.gfo().T(x.gcem())
x.a.toString
w=x.gfo()
w.ok$=$.aa()
w.k4$=0
x.cOP()},
u(d){var x,w,v,u=this,t=null
u.a.toString
x=u.gfo().a
w=u.a.w
v=new B.b3E(w,u.e,C.q,!0,x,t,t)
return A.Rv(C.hP,A.ic(C.bH,v,C.w,!1,t,t,t,t,t,t,t,t,t,t,t,t,u.gdqh(),u.gdqj(),u.gdql(),t,t,t,t,t,t,t,t,t,t,t,!1,new A.N(0,-0.005)),u.f,t,t,t,t,t,u.gdk3(),t)}}
B.b3E.prototype={
u(d){var x=this,w=A.UY(x.w,new A.mT(x.c,x.d),null,x.r,!0)
return A.td(w,x.e,null)}}
B.ap5.prototype={
W(){return"_GestureType."+this.b}}
B.awL.prototype={
cd(){this.df()
this.dl()
this.fR()},
q(){var x=this,w=x.dy$
if(w!=null)w.T(x.gfK())
x.dy$=null
x.a5()}}
var z=a.updateTypes(["~()","~(TR)","~(TS)","~(LI)","~(mo)"])
B.cVA.prototype={
$0(){},
$S:0};(function aliases(){var x=B.awL.prototype
x.cOP=x.q})();(function installTearOffs(){var x=a._instance_1u,w=a._instance_0u
var v
x(v=B.apF.prototype,"gdqj","dqk",1)
x(v,"gdql","dqm",2)
x(v,"gdqh","dqi",3)
x(v,"gdk3","dk4",4)
w(v,"gbtS","de5",0)
w(v,"gbu2","dgh",0)
w(v,"gcem","dij",0)})();(function inheritance(){var x=a.mixinHard,w=a.inherit
w(B.acT,A.L)
w(B.awL,A.U)
w(B.apF,B.awL)
w(B.cVA,A.bt)
w(B.b3E,A.x)
w(B.ap5,A.eA)
x(B.awL,A.fs)})()
A.b_(b.typeUniverse,JSON.parse('{"acT":{"L":[],"m":[]},"apF":{"U":["acT"]},"b3E":{"x":[],"m":[]}}'))
var y={z:A.C("bh<U<L>>"),B:A.C("SD"),l:A.C("Eg"),g:A.C("ak"),A:A.C("bn<N>"),f:A.C("bn<a4>")};(function constants(){D.vB=new B.ap5(0,"pan")
D.Bi=new B.ap5(1,"scale")
D.ccp=new B.ap5(2,"rotate")})()};
(a=>{a["BRpIpcMF26f/midsXZysLjEmAYQ="]=a.current})($__dart_deferred_initializers__);