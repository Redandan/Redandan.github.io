((a,b)=>{a[b]=a[b]||{}})(self,"$__dart_deferred_initializers__")
$__dart_deferred_initializers__.current=function(a,b,c,$){var A,B
A=c[0]
B=c[730]
var z=a.updateTypes([]);(function constants(){B.SH=new A.a0(62837,"MaterialIcons",!1)
B.FI=new A.a0(62846,"MaterialIcons",!1)})()};
(a=>{a["vY7VpCtbkugWpWfLSLRO1km6LUo="]=a.current})($__dart_deferred_initializers__);