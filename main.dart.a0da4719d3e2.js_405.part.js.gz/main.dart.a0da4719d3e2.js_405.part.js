((a,b)=>{a[b]=a[b]||{}})(self,"$__dart_deferred_initializers__")
$__dart_deferred_initializers__.current=function(a,b,c,$){var A,B
A=c[0]
B=c[345]
var z=a.updateTypes([]);(function constants(){B.mj=new A.X(58132,"MaterialIcons",!1)})()};
(a=>{a["no1mkQYrgEQTVsc0yTgiLJUflVg="]=a.current})($__dart_deferred_initializers__);