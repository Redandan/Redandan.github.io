((a,b)=>{a[b]=a[b]||{}})(self,"$__dart_deferred_initializers__")
$__dart_deferred_initializers__.current=function(a,b,c,$){var A,B
A=c[0]
B=c[401]
var z=a.updateTypes([]);(function constants(){B.Fz=new A.a0(61358,"MaterialIcons",!1)})()};
(a=>{a["8dxEfP5ndDekf16kKFR/5DalaSI="]=a.current})($__dart_deferred_initializers__);