((a,b)=>{a[b]=a[b]||{}})(self,"$__dart_deferred_initializers__")
$__dart_deferred_initializers__.current=function(a,b,c,$){var J,A,B,C={DN:function DN(d,e){this.a=d
this.b=e}}
J=c[1]
A=c[0]
B=c[2]
C=a.updateHolder(c[236],C)
C.DN.prototype={
wA(d){return new A.dt(this,y.d)},
z_(d,e){return A.RZ(null,this.lI(d,e),"MemoryImage("+("<optimized out>#"+A.d9(d.a))+")",null,d.b)},
wt(d,e){return A.RZ(null,this.lI(d,e),"MemoryImage("+("<optimized out>#"+A.d9(d.a))+")",null,d.b)},
lI(d,e){return this.dl0(d,e)},
dl0(d,e){var x=0,w=A.l(y.c),v,u=this,t
var $async$lI=A.h(function(f,g){if(f===1)return A.i(g,w)
for(;;)switch(x){case 0:t=e
x=3
return A.c(A.Dy(u.a),$async$lI)
case 3:v=t.$1(g)
x=1
break
case 1:return A.j(v,w)}})
return A.k($async$lI,w)},
p(d,e){if(e==null)return!1
if(J.ab(e)!==A.aq(this))return!1
return e instanceof C.DN&&e.a===this.a&&e.b===this.b},
gj(d){return A.Y(A.a8(this.a),this.b,B.a,B.a,B.a,B.a,B.a,B.a,B.a,B.a,B.a,B.a,B.a,B.a,B.a,B.a,B.a,B.a,B.a,B.a)},
l(d){return"MemoryImage("+("<optimized out>#"+A.d9(this.a))+", scale: "+B.h.Z(this.b,1)+")"}}
var z=a.updateTypes([]);(function inheritance(){var x=a.inherit
x(C.DN,A.iP)})()
A.b_(b.typeUniverse,JSON.parse('{"DN":{"iP":["DN"],"iP.T":"DN"}}'))
var y={c:A.B("j4"),d:A.B("dt<DN>")}};
(a=>{a["4A8cg7nuOHwAIGXe2rRGCWeU734="]=a.current})($__dart_deferred_initializers__);