((a,b)=>{a[b]=a[b]||{}})(self,"$__dart_deferred_initializers__")
$__dart_deferred_initializers__.current=function(a,b,c,$){var A,B={
ex8(){return new A.yU(null)}}
A=c[118]
B=a.updateHolder(c[10],B)
var z=a.updateTypes([])};
(a=>{a["v5Znu30xznxTCOE6PrB+qkLDJOE="]=a.current})($__dart_deferred_initializers__);