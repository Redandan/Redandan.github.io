((a,b)=>{a[b]=a[b]||{}})(self,"$__dart_deferred_initializers__")
$__dart_deferred_initializers__.current=function(a,b,c,$){var A,B,C={a3k:function a3k(d,e){this.c=d
this.a=e},bc3:function bc3(d){this.a=d}},D
A=c[0]
B=c[2]
C=a.updateHolder(c[212],C)
D=c[803]
C.a3k.prototype={
u(d){var y=null
return A.aSn(A.jV(y,y,y,new C.bc3(y),B.b1,!1),this.c)}}
C.bc3.prototype={
bb(d,e){var y,x,w,v,u,t,s,r=e.gjh(),q=e.a,p=e.b
$.b3()
y=A.bF()
y.r=D.ay0.gC()
d.jH(new A.M(q/2,p/2),r/2,y)
x=A.bF()
x.r=B.M.gC()
x.b=B.ch
w=A.bF()
w.r=B.M.gC()
w.b=B.bQ
w.d=B.mr
w.c=r*0.055
y=q*0.22
v=p*0.28
u=y+q*0.56
t=r*0.03
d.hm(A.u0(new A.ao(y,v,u,v+p*0.12),new A.c1(t,t)),x)
t=q*0.43
v=p*0.34
s=r*0.04
d.hm(A.u0(new A.ao(t,v,t+q*0.14,v+p*0.36),new A.c1(s,s)),x)
s=p*0.42
d.bWm(new A.ao(y,s,u,s+p*0.18),w)},
ii(d){return!1}}
var z=a.updateTypes([]);(function inheritance(){var y=a.inherit
y(C.a3k,A.x)
y(C.bc3,A.zp)})()
A.b0(b.typeUniverse,JSON.parse('{"a3k":{"x":[],"m":[]},"bc3":{"b2":[]}}'));(function constants(){D.ay0=new A.a3(1,0.14901960784313725,0.6313725490196078,0.4823529411764706,B.A)})()};
(a=>{a["jfpv5jlqCk5pxCwStTGzSt8gt2o="]=a.current})($__dart_deferred_initializers__);