((a,b)=>{a[b]=a[b]||{}})(self,"$__dart_deferred_initializers__")
$__dart_deferred_initializers__.current=function(a,b,c,$){var A,B
A=c[0]
B=c[777]
var z=a.updateTypes([]);(function constants(){B.DH=new A.ar(0,0,96,0)})()};
(a=>{a["SAIcsCl3hyqRqgOweWFCTfDjRWM="]=a.current})($__dart_deferred_initializers__);