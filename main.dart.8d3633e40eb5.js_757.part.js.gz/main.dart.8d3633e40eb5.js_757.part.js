((a,b)=>{a[b]=a[b]||{}})(self,"$__dart_deferred_initializers__")
$__dart_deferred_initializers__.current=function(a,b,c,$){var A,B
A=c[0]
B=c[757]
var z=a.updateTypes([]);(function constants(){B.Kh=new A.br("\u67e5\u770b\u8a73\u60c5",null,null,null,null,null,null,null,null,null,null)})()};
(a=>{a["CcxUGASRZzAxOcbibmOeq3uIiw0="]=a.current})($__dart_deferred_initializers__);