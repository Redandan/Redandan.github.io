((a,b)=>{a[b]=a[b]||{}})(self,"$__dart_deferred_initializers__")
$__dart_deferred_initializers__.current=function(a,b,c,$){var J,C,D,A={
Ey(d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,a0,a1,a2,a3,a4,a5,a6,a7,a8,a9,b0,b1,b2,b3,b4){return new A.jJ(b4,a0,h,a9,k,g,o,t,s,x,w,r,l,a6,e,q,b3,a5,i,a4,m,v,u,n,b0,d,a2,a1,a8,a7,a3,p,f,j,b2,b1)},
jJ:function jJ(d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,a0,a1,a2,a3,a4,a5,a6,a7,a8,a9,b0,b1,b2,b3,b4){var _=this
_.a=d
_.b=e
_.c=f
_.d=g
_.e=h
_.r=i
_.w=j
_.x=k
_.y=l
_.z=m
_.Q=n
_.as=o
_.at=p
_.ax=q
_.ay=r
_.ch=s
_.CW=t
_.cx=u
_.cy=v
_.db=w
_.dx=x
_.fx=a0
_.fy=a1
_.go=a2
_.id=a3
_.k1=a4
_.k2=a5
_.k3=a6
_.k4=a7
_.ok=a8
_.p1=a9
_.p2=b0
_.p3=b1
_.p4=b2
_.R8=b3
_.RG=b4},
h2:function h2(d){this.a=d},
bVl:function bVl(){},
hQ:function hQ(d){this.a=d}},B
J=c[1]
C=c[0]
D=c[2]
A=a.updateHolder(c[235],A)
B=c[680]
A.jJ.prototype={
p(d,e){var x,w=this
if(e==null)return!1
if(w!==e)x=e instanceof A.jJ&&e.a===w.a&&e.b===w.b&&e.c===w.c&&e.d===w.d&&e.e===w.e&&e.r===w.r&&D.U.ar(e.w,w.w)&&e.x===w.x&&e.y===w.y&&e.z==w.z&&e.Q==w.Q&&e.as==w.as&&e.at==w.at&&D.U.ar(e.ax,w.ax)&&e.ay==w.ay&&e.ch==w.ch&&e.CW==w.CW&&e.cx==w.cx&&e.cy==w.cy&&e.db==w.db&&e.dx==w.dx&&D.U.ar(e.fx,w.fx)&&D.U.ar(e.fy,w.fy)&&e.go==w.go&&e.id==w.id&&e.k1==w.k1&&e.k2==w.k2&&e.k3==w.k3&&e.k4==w.k4&&e.ok==w.ok&&e.p1==w.p1&&e.p2==w.p2&&e.p3==w.p3&&e.p4==w.p4&&e.R8==w.R8&&e.RG==w.RG
else x=!0
return x},
gj(b6){var x,w,v,u,t,s,r,q,p,o,n,m,l,k,j,i,h,g,f,e,d,a0,a1,a2,a3,a4,a5=this,a6=D.b.gj(a5.a),a7=D.k.gj(a5.b),a8=C.a8(a5.c),a9=D.h.gj(a5.d),b0=D.b.gj(a5.e),b1=C.a8(a5.r),b2=C.a8(a5.w),b3=D.k.gj(a5.x),b4=D.k.gj(a5.y),b5=a5.z
b5=b5==null?0:D.b.gj(b5)
x=a5.Q
x=x==null?0:D.b.gj(x)
w=a5.as
w=w==null?0:D.b.gj(w)
v=a5.at
v=v==null?0:D.D.gj(v)
u=C.a8(a5.ax)
t=a5.ay
t=t==null?0:D.b.gj(t)
s=a5.ch
s=s==null?0:D.h.gj(s)
r=a5.CW
r=r==null?0:D.b.gj(r)
q=a5.cx
q=q==null?0:D.h.gj(q)
p=a5.cy
p=p==null?0:D.b.gj(p)
o=a5.db
o=o==null?0:D.b.gj(o)
n=a5.dx
n=n==null?0:D.h.gj(n)
m=J.aH(a5.fx)
l=C.a8(a5.fy)
k=a5.go
k=k==null?0:D.k.gj(k)
j=a5.id
j=j==null?0:D.h.gj(j)
i=a5.k1
i=i==null?0:D.D.gj(i)
h=a5.k2
h=h==null?0:D.b.gj(h)
g=a5.k3
g=g==null?0:C.a8(g)
f=a5.k4
f=f==null?0:D.b.gj(f)
e=a5.ok
e=e==null?0:D.b.gj(e)
d=a5.p1
d=d==null?0:D.h.gj(d)
a0=a5.p2
a0=a0==null?0:D.h.gj(a0)
a1=a5.p3
a1=a1==null?0:D.b.gj(a1)
a2=a5.p4
a2=a2==null?0:D.b.gj(a2)
a3=a5.R8
a3=a3==null?0:D.h.gj(a3)
a4=a5.RG
a4=a4==null?0:D.b.gj(a4)
return a6+a7+a8+a9+b0+b1+b2+b3+b4+b5+x+w+v+u+t+s+r+q+p+o+n+m+l+k+j+i+h+g+f+e+d+a0+a1+a2+a3+a4},
l(d){var x=this
return"ProductCreateParam[title="+x.a+", price="+C.b(x.b)+", currency="+x.c.l(0)+", stock="+x.d+", description="+x.e+", defaultLocale=null, category="+x.r.l(0)+", imageUrls="+x.w.l(0)+", pickupLongitude="+C.b(x.x)+", pickupLatitude="+C.b(x.y)+", pickupTimeStart="+C.b(x.z)+", pickupTimeEnd="+C.b(x.Q)+", pickupAddress="+C.b(x.as)+", enablePlatformDelivery="+C.b(x.at)+", skus="+x.ax.l(0)+", brand="+C.b(x.ay)+", minStock="+C.b(x.ch)+", tags="+C.b(x.CW)+", shippingPreparationHours="+C.b(x.cx)+", dailyShippingDeadline="+C.b(x.cy)+", shippingDescription="+C.b(x.db)+", estimatedDeliveryDays="+C.b(x.dx)+", supportsScheduledShipping=null, shippingDateRange=null, pickupServiceTypes="+C.b(x.fx)+", pickupServiceTypeFees="+x.fy.l(0)+", freeShippingThreshold="+C.b(x.go)+", stockAlertThreshold="+C.b(x.id)+", allowNegativeStock="+C.b(x.k1)+", purchaseUrl="+C.b(x.k2)+", productType="+C.b(x.k3)+", sourceRegion="+C.b(x.k4)+", sourcePlatform="+C.b(x.ok)+", serviceLeadTimeHours="+C.b(x.p1)+", maxConcurrentOrders="+C.b(x.p2)+", buyerInfoRequiredJson="+C.b(x.p3)+", dataResidencyNotice="+C.b(x.p4)+", subscriptionDurationDays="+C.b(x.R8)+", subscriptionAccessNote="+C.b(x.RG)+"]"},
A(){var x,w=this,v=null,u="pickupTimeStart",t="pickupTimeEnd",s="pickupAddress",r="enablePlatformDelivery",q="minStock",p="shippingPreparationHours",o="dailyShippingDeadline",n="shippingDescription",m="estimatedDeliveryDays",l="freeShippingThreshold",k="stockAlertThreshold",j="allowNegativeStock",i="purchaseUrl",h="productType",g="sourceRegion",f="sourcePlatform",e="serviceLeadTimeHours",d="maxConcurrentOrders",a0="buyerInfoRequiredJson",a1="dataResidencyNotice",a2="subscriptionDurationDays",a3="subscriptionAccessNote",a4=C.q(y.g,y.b)
a4.h(0,"title",w.a)
a4.h(0,"price",w.b)
a4.h(0,"currency",w.c)
a4.h(0,"stock",w.d)
a4.h(0,"description",w.e)
a4.h(0,"defaultLocale",v)
a4.h(0,"category",w.r)
a4.h(0,"imageUrls",w.w.bI(0,!1))
a4.h(0,"pickupLongitude",w.x)
a4.h(0,"pickupLatitude",w.y)
x=w.z
if(x!=null)a4.h(0,u,x)
else a4.h(0,u,v)
x=w.Q
if(x!=null)a4.h(0,t,x)
else a4.h(0,t,v)
x=w.as
if(x!=null)a4.h(0,s,x)
else a4.h(0,s,v)
x=w.at
if(x!=null)a4.h(0,r,x)
else a4.h(0,r,v)
a4.h(0,"skus",w.ax.bI(0,!1))
x=w.ay
if(x!=null)a4.h(0,"brand",x)
else a4.h(0,"brand",v)
x=w.ch
if(x!=null)a4.h(0,q,x)
else a4.h(0,q,v)
x=w.CW
if(x!=null)a4.h(0,"tags",x)
else a4.h(0,"tags",v)
x=w.cx
if(x!=null)a4.h(0,p,x)
else a4.h(0,p,v)
x=w.cy
if(x!=null)a4.h(0,o,x)
else a4.h(0,o,v)
x=w.db
if(x!=null)a4.h(0,n,x)
else a4.h(0,n,v)
x=w.dx
if(x!=null)a4.h(0,m,x)
else a4.h(0,m,v)
a4.h(0,"supportsScheduledShipping",v)
a4.h(0,"shippingDateRange",v)
a4.h(0,"pickupServiceTypes",w.fx)
a4.h(0,"pickupServiceTypeFees",w.fy)
x=w.go
if(x!=null)a4.h(0,l,x)
else a4.h(0,l,v)
x=w.id
if(x!=null)a4.h(0,k,x)
else a4.h(0,k,v)
x=w.k1
if(x!=null)a4.h(0,j,x)
else a4.h(0,j,v)
x=w.k2
if(x!=null)a4.h(0,i,x)
else a4.h(0,i,v)
x=w.k3
if(x!=null)a4.h(0,h,x)
else a4.h(0,h,v)
x=w.k4
if(x!=null)a4.h(0,g,x)
else a4.h(0,g,v)
x=w.ok
if(x!=null)a4.h(0,f,x)
else a4.h(0,f,v)
x=w.p1
if(x!=null)a4.h(0,e,x)
else a4.h(0,e,v)
x=w.p2
if(x!=null)a4.h(0,d,x)
else a4.h(0,d,v)
x=w.p3
if(x!=null)a4.h(0,a0,x)
else a4.h(0,a0,v)
x=w.p4
if(x!=null)a4.h(0,a1,x)
else a4.h(0,a1,v)
x=w.R8
if(x!=null)a4.h(0,a2,x)
else a4.h(0,a2,v)
x=w.RG
if(x!=null)a4.h(0,a3,x)
else a4.h(0,a3,v)
return a4}}
A.h2.prototype={
l(d){return this.a},
A(){return this.a}}
A.bVl.prototype={
D(d){if(d!=null)switch(d){case"USDT":return B.dJ
case"USD":return B.uF
case"TWD":return B.uE
case"THB":return B.I_
case"CNY":return B.ux
case"JPY":return B.uB
case"EUR":return B.uy
case"GBP":return B.uz
case"KRW":return B.uC
case"SGD":return B.uD
case"HKD":return B.uA
case"AUD":return B.uw
case"unknown_default_open_api":return B.uG}return null}}
A.hQ.prototype={
l(d){return this.a},
A(){return this.a}}
var z=a.updateTypes([]);(function inheritance(){var x=a.inheritMany
x(C.A,[A.jJ,A.h2,A.bVl,A.hQ])})()
var y={g:C.C("n"),b:C.C("@")};(function constants(){var x=a.makeConstList
B.oN=new A.bVl()
B.uv=new A.hQ("ELECTRONICS")
B.aak=new A.hQ("MOBILE")
B.A1=new A.hQ("CLOTHING")
B.aao=new A.hQ("SHOES")
B.aaf=new A.hQ("BAGS")
B.aag=new A.hQ("BEAUTY")
B.A4=new A.hQ("HEALTH")
B.A3=new A.hQ("FOOD")
B.A5=new A.hQ("HOME")
B.aaj=new A.hQ("FURNITURE")
B.aae=new A.hQ("BABY")
B.aaq=new A.hQ("TOYS")
B.aam=new A.hQ("PET_SUPPLIES")
B.aap=new A.hQ("SPORTS")
B.aal=new A.hQ("OUTDOOR")
B.aad=new A.hQ("AUTOMOTIVE")
B.aah=new A.hQ("BOOKS")
B.aan=new A.hQ("SECOND_HAND")
B.aai=new A.hQ("DIGITAL_SERVICE")
B.A2=new A.hQ("CREATOR_SUBSCRIPTION")
B.jK=new A.hQ("OTHER")
B.dJ=new A.h2("USDT")
B.uF=new A.h2("USD")
B.uE=new A.h2("TWD")
B.I_=new A.h2("THB")
B.ux=new A.h2("CNY")
B.uB=new A.h2("JPY")
B.uy=new A.h2("EUR")
B.uz=new A.h2("GBP")
B.uC=new A.h2("KRW")
B.uD=new A.h2("SGD")
B.uA=new A.h2("HKD")
B.uw=new A.h2("AUD")
B.uG=new A.h2("unknown_default_open_api")
B.z0=x([],C.C("v<iW>"))})();(function staticFields(){$.xN=null})()};
(a=>{a["2ro82uwpVkwJ4kIIb83VGU4hOvM="]=a.current})($__dart_deferred_initializers__);