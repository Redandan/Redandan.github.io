((a,b)=>{a[b]=a[b]||{}})(self,"$__dart_deferred_initializers__")
$__dart_deferred_initializers__.current=function(a,b,c,$){var A,B
A=c[0]
B=c[550]
var z=a.updateTypes([]);(function constants(){B.Jp=new A.ad(null,18,null,null)})()};
(a=>{a["vbRSqO5BTCN7HIeNGTDlUFsYoM8="]=a.current})($__dart_deferred_initializers__);