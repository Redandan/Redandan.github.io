((a,b)=>{a[b]=a[b]||{}})(self,"$__dart_deferred_initializers__")
$__dart_deferred_initializers__.current=function(a,b,c,$){var A,B
A=c[0]
B=c[567]
var z=a.updateTypes([]);(function constants(){B.DF=new A.ar(0,0,80,0)})()};
(a=>{a["gdesVQAjWY5AGLorUgiq+uE3cVo="]=a.current})($__dart_deferred_initializers__);