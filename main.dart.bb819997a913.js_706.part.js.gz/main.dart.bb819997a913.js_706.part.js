((a,b)=>{a[b]=a[b]||{}})(self,"$__dart_deferred_initializers__")
$__dart_deferred_initializers__.current=function(a,b,c,$){var A,B
A=c[0]
B=c[496]
var z=a.updateTypes([]);(function constants(){B.iS=new A.br("\u95dc\u9589",null,null,null,null,null,null,null,null,null,null)})()};
(a=>{a["VOfvkojIJl68Lspoa3XnWwkiRxc="]=a.current})($__dart_deferred_initializers__);