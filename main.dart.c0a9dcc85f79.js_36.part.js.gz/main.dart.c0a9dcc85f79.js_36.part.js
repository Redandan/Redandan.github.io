((a,b)=>{a[b]=a[b]||{}})(self,"$__dart_deferred_initializers__")
$__dart_deferred_initializers__.current=function(a,b,c,$){var A,B
A=c[0]
B=c[306]
var z=a.updateTypes([]);(function constants(){B.T5=new A.a0(984374,"MaterialIcons",!1)})()};
(a=>{a["9IPeE2PQqPYX+YMLNHoJIhPyvlM="]=a.current})($__dart_deferred_initializers__);