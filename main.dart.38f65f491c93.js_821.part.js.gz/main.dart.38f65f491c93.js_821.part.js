((a,b)=>{a[b]=a[b]||{}})(self,"$__dart_deferred_initializers__")
$__dart_deferred_initializers__.current=function(a,b,c,$){var A,B
A=c[0]
B=c[626]
var z=a.updateTypes([]);(function constants(){B.Fw=new A.a0(61081,"MaterialIcons",!0)})()};
(a=>{a["RLhdLloKR95xqBGom0jWUGSMGow="]=a.current})($__dart_deferred_initializers__);