((a,b)=>{a[b]=a[b]||{}})(self,"$__dart_deferred_initializers__")
$__dart_deferred_initializers__.current=function(a,b,c,$){var A,B
A=c[0]
B=c[504]
var z=a.updateTypes([]);(function constants(){B.RI=new A.a0(57998,"MaterialIcons",!1)})()};
(a=>{a["nezauXZ2QDqLnQSRk8ISrXNORTE="]=a.current})($__dart_deferred_initializers__);