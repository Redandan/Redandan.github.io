((a,b)=>{a[b]=a[b]||{}})(self,"$__dart_deferred_initializers__")
$__dart_deferred_initializers__.current=function(a,b,c,$){var A,C,B={a3u:function a3u(){},cfc:function cfc(d){this.a=d},cfb:function cfb(d,e,f){this.a=d
this.b=e
this.c=f},
efs(d,e){var x=d>0?"+":""
return x+(C.k.Z(d,2)+" "+A.eP(e))}}
A=c[0]
C=c[2]
B=a.updateHolder(c[158],B)
B.a3u.prototype={
cyP(d){var x=A.cs(d,null,y.h)
if(x!=null)this.bWP$.H(0,x)},
bAh(){var x=this.lu$
x===$&&A.e()
return x.fw(new B.cfc(this))},
ga37(){if(this.c!=null){var x=this.lu$
x===$&&A.e()
x=x.gN()}else x=!1
if(x){x=this.aVz$
x=(x==null?null:x.gN())!==!1}else x=!1
return x},
cyQ(d){var x=this.lu$
x===$&&A.e()
x=x.mg($.al().$1$0(y.a).a,d)
return new A.jC(x)},
dym(){var x,w,v,u=this
if(u.c!=null){x=u.lu$
x===$&&A.e()
x=x.gN()}else x=!0
if(x)return
u.n(u.gcrP())
if(u.bWO$)return
u.bWO$=!0
w=u.aVz$
v=w==null?null:w.b
$.am.y2$.push(new B.cfb(u,v,w))}}
var z=a.updateTypes(["~()"])
B.cfc.prototype={
$0(){return this.a.c!=null},
$S:1}
B.cfb.prototype={
$1(d){var x,w,v,u,t,s=this
for(x=s.a.bWP$,w=A.e_(x,x.r,A.D(x).c),v=w.$ti.c;w.F();){u=w.d
if(u==null)u=v.a(u)
t=u.b
if(t!=null&&t.c!=null&&u.gfd()&&!u.gle())t.ho(u)}x.a2(0)
x=s.b
w=!1
if(x!=null)if(x.c!=null){w=s.c
w=w.gfd()&&!w.gle()}if(w)x.ho(s.c)},
$S:2};(function installTearOffs(){var x=a._instance_0u
x(B.a3u.prototype,"gbwR","dym",0)})();(function inheritance(){var x=a.inherit
x(B.a3u,A.A)
x(B.cfc,A.bt)
x(B.cfb,A.bu)})()
A.mF(b.typeUniverse,JSON.parse('{"a3u":1}'))
var y={a:A.C("jC"),h:A.C("A?")}};
(a=>{a["poyfxqn4or2cdHrGL4NwnkvDRbQ="]=a.current})($__dart_deferred_initializers__);