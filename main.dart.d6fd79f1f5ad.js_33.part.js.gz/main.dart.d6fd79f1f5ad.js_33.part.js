((a,b)=>{a[b]=a[b]||{}})(self,"$__dart_deferred_initializers__")
$__dart_deferred_initializers__.current=function(a,b,c,$){var A,B
A=c[0]
B=c[303]
var z=a.updateTypes([]);(function constants(){B.Sr=new A.a0(61464,"MaterialIcons",!1)})()};
(a=>{a["htYxZINRftbiuaQiNiPJ2LEUmnw="]=a.current})($__dart_deferred_initializers__);