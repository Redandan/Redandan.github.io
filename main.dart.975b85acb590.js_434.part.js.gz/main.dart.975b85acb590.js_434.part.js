((a,b)=>{a[b]=a[b]||{}})(self,"$__dart_deferred_initializers__")
$__dart_deferred_initializers__.current=function(a,b,c,$){var B,A
B=c[0]
A=c[579]
var z=a.updateTypes([]);(function constants(){A.aQX=new B.a0(57499,"MaterialIcons",!0)
A.TK=new B.at(A.aQX,null,null,null,null)})()};
(a=>{a["s2ZWVHZEzH7QlzwB8MP8pss8puA="]=a.current})($__dart_deferred_initializers__);