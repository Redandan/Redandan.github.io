((a,b)=>{a[b]=a[b]||{}})(self,"$__dart_deferred_initializers__")
$__dart_deferred_initializers__.current=function(a,b,c,$){var A,C,B={bS4:function bS4(d,e){this.a=d
this.b=e},aPR:function aPR(d,e,f,g,h,i,j,k,l,m){var _=this
_.em=d
_.en=e
_.e7=f
_.h0=g
_.hS=h
_.U=null
_.aJ=i
_.b7=j
_.V$=k
_.dy=l
_.b=_.fy=null
_.c=0
_.y=_.d=null
_.z=!0
_.Q=null
_.as=!1
_.at=null
_.ay=$
_.ch=m
_.CW=!1
_.cx=$
_.cy=!0
_.db=!1
_.dx=$},
eIc(d,e,f,g,h,i){return new B.aN0(d,i,g,h,f,e,null)},
aN0:function aN0(d,e,f,g,h,i,j){var _=this
_.e=d
_.f=e
_.r=f
_.w=g
_.x=h
_.c=i
_.a=j}},D
A=c[0]
C=c[2]
B=a.updateHolder(c[291],B)
D=c[825]
B.bS4.prototype={
W(){return"OverflowBoxFit."+this.b}}
B.aPR.prototype={
se4C(d){if(this.em===d)return
this.em=d
this.aC()},
sbZA(d){if(this.en===d)return
this.en=d
this.aC()},
se4w(d){if(this.e7===d)return
this.e7=d
this.aC()},
sbZz(d){if(this.h0===d)return
this.h0=d
this.aC()},
spB(d){var x=this
if(x.hS===d)return
x.hS=d
x.aC()
x.bDB()},
Fu(d){var x=this,w=x.em,v=x.en,u=x.e7,t=x.h0
return new A.ay(w,v,u,t)},
gn7(){switch(this.hS.a){case 0:var x=!0
break
case 1:x=!1
break
default:x=null}return x},
ev(d){var x
switch(this.hS.a){case 0:x=new A.ae(A.an(1/0,d.a,d.b),A.an(1/0,d.c,d.d))
break
case 1:x=this.V$
x=x==null?null:x.aS(C.b3,d,x.ge9())
if(x==null)x=new A.ae(A.an(0,d.a,d.b),A.an(0,d.c,d.d))
break
default:x=null}return x},
fG(d,e){var x,w,v,u,t=this,s=t.V$
if(s==null)return null
x=t.Fu(d)
w=s.iw(x,e)
if(w==null)return null
v=s.aS(C.b3,x,s.ge9())
u=t.aS(C.b3,d,t.ge9())
return w+t.gaam().mi(y.b.a(u.az(0,v))).b},
ds(){var x,w=this,v=w.V$
if(v!=null){x=y.a
v.ey(w.Fu(x.a(A.af.prototype.gaj.call(w))),!0)
switch(w.hS.a){case 0:break
case 1:w.fy=x.a(A.af.prototype.gaj.call(w)).co(w.V$.gL())
break}w.a2f()}else switch(w.hS.a){case 0:break
case 1:v=y.a.a(A.af.prototype.gaj.call(w))
w.fy=new A.ae(A.an(0,v.a,v.b),A.an(0,v.c,v.d))
break}}}
B.aN0.prototype={
bl(d){var x=this,w=new B.aPR(x.f,x.r,x.w,x.x,D.a6r,x.e,A.hm(d),null,new A.cm(),A.bq(y.d))
w.bk()
w.scb(null)
return w},
bF(d,e){var x=this
e.siD(x.e)
e.se4C(x.f)
e.sbZA(x.r)
e.se4w(x.w)
e.sbZz(x.x)
e.spB(D.a6r)
e.sdV(A.hm(d))}}
var z=a.updateTypes([]);(function inheritance(){var x=a.inherit
x(B.bS4,A.eD)
x(B.aPR,A.LJ)
x(B.aN0,A.cz)})()
A.b0(b.typeUniverse,JSON.parse('{"aPR":{"aj":[],"cc":["aj"],"af":[],"bx":[]},"aN0":{"cz":[],"bA":[],"m":[]}}'))
var y={a:A.C("ay"),d:A.C("i3"),b:A.C("M")};(function constants(){D.a6r=new B.bS4(0,"max")})()};
(a=>{a["EZaE2rbAV1TDV9JUZ6wYJeHNXwU="]=a.current})($__dart_deferred_initializers__);