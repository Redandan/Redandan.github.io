((a,b)=>{a[b]=a[b]||{}})(self,"$__dart_deferred_initializers__")
$__dart_deferred_initializers__.current=function(a,b,c,$){var A,B
A=c[0]
B=c[470]
var z=a.updateTypes([]);(function constants(){B.lE=new A.a0(984391,"MaterialIcons",!1)})()};
(a=>{a["OqDEXv8qLIZPpG9X2fFeJtXJHCY="]=a.current})($__dart_deferred_initializers__);