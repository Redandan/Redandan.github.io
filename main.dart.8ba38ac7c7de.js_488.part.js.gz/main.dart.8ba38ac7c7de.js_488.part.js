((a,b)=>{a[b]=a[b]||{}})(self,"$__dart_deferred_initializers__")
$__dart_deferred_initializers__.current=function(a,b,c,$){var J,A,B,K,L,F,G,M,H,N,O,E,P,C={aED:function aED(d,e,f,g,h,i){var _=this
_.a=d
_.b=e
_.c=f
_.d=g
_.e=h
_.f=i},aRs:function aRs(d,e,f,g,h,i){var _=this
_.a=d
_.b=e
_.c=f
_.d=g
_.e=h
_.f=i},
eEa(){return new C.Ji(null)},
Ji:function Ji(d){this.a=d},
b3c:function b3c(d){this.d=d
this.c=this.a=null},
cV0:function cV0(d){this.a=d},
cV_:function cV_(){},
cUZ:function cUZ(d,e){this.a=d
this.b=e},
cUX:function cUX(d){this.a=d},
cUY:function cUY(d){this.a=d},
cUU:function cUU(d,e){this.a=d
this.b=e},
cUT:function cUT(d,e){this.a=d
this.b=e},
cUW:function cUW(d,e){this.a=d
this.b=e},
cUV:function cUV(d,e){this.a=d
this.b=e}},D,Q,I,R,S,T,U,V
J=c[1]
A=c[0]
B=c[2]
K=c[352]
L=c[361]
F=c[413]
G=c[592]
M=c[375]
H=c[262]
N=c[501]
O=c[595]
E=c[280]
P=c[271]
C=a.updateHolder(c[40],C)
D=c[593]
Q=c[512]
I=c[457]
R=c[350]
S=c[359]
T=c[320]
U=c[594]
V=c[265]
C.aED.prototype={}
C.aRs.prototype={}
C.Ji.prototype={
O(){return new C.b3c(new A.aj(B.L,$.aa()))}}
C.b3c.prototype={
q(){var x=this.d
x.ok$=$.aa()
x.k4$=0
this.a5()},
u(d){var x,w,v,u,t,s,r=this,q=null,p=y.J,o=A.f(d,B.c,p).gaXr(),n=A.f(d,B.c,p).gWc(),m=r.cY_(d),l=A.f(d,B.c,p),k=l.gaXl()
l=l.gaXk()
x=A.t(d).ax
w=A.G(8)
v=x.ry
if(v==null){v=x.E
if(v==null)v=x.k3}v=A.aN(v.B(0.14),B.u,1)
u=x.k3
t=A.Y(q,q,u,q,q,q,q,q,q,q,q,16,q,q,q,q,q,!0,q,q,q,q,q,q,q,q)
p=A.f(d,B.c,p).gaXj()
s=A.Y(q,q,u.B(0.541),q,q,q,q,q,q,q,q,16,q,q,q,q,q,!0,q,q,q,q,q,q,q,q)
u=A.T(G.pl,u.B(0.541),q,q,q)
return P.LR(B.aS,A.a([m,B.a7,new E.iS(k,new A.cb(new A.R(x.k2,q,v,w,q,q,B.r),B.at,A.bB(q,B.N,!1,q,!0,B.q,q,A.bD(),r.d,q,q,q,q,q,2,A.aJ(q,new A.dP(4,A.G(12),B.B),q,B.C,q,q,q,q,!0,q,q,q,q,q,q,B.a4,!0,q,q,q,q,q,q,q,q,q,q,q,q,q,s,p,q,q,q,q,q,q,q,q,q,!0,!0,!1,q,u,q,q,q,q,q,q,q,q,q,q,q,q),B.w,!0,q,!0,q,!1,q,B.a3,q,q,q,q,q,q,q,q,q,1,q,q,!1,"\u2022",q,q,q,q,q,!1,q,q,!1,q,!0,q,B.W,q,q,q,q,q,q,q,q,q,q,q,t,!0,B.J,q,B.K,q,q,q,q),q),G.pl,l,q),B.a7,r.cW3(d)],y.p),F.ju,new C.cV0(r),B.cx,n,o)},
cY_(d){var x=A.f(d,B.c,y.J),w=x.gaXf(),v=x.gaXg()
return new E.iS(w,A.cZ(new C.cUZ(this,x)),F.ju,v,null)},
c7T(d,e,f,g,h,i,j){var x,w,v,u,t=null,s=A.t(d),r=f?s.ax.b.B(0.055):t,q=f?s.ax.b.B(0.24):t,p=s.ax,o=p.b,n=f?o:o.B(0.1),m=A.G(8)
n=A.W(t,A.T(g,f?B.M:o,t,t,26),B.o,t,t,new A.R(n,t,t,m,t,t,B.r),t,t,t,t,B.C,t,t,t)
m=p.k3
x=A.d(h,t,t,t,t,t,A.Y(t,t,m,t,t,t,t,t,t,t,t,16,t,t,B.F,t,t,!0,t,t,t,t,t,t,t,t),t,t,t)
w=o.B(0.08)
v=A.G(99)
u=y.p
v=A.O(A.w(A.a([A.bi(B.a0,A.a([x,A.W(t,A.d(e,t,t,t,t,t,A.Y(t,t,o,t,t,t,t,t,t,t,t,11,t,t,B.F,t,t,!0,t,t,t,t,t,t,t,t),t,t,t),B.o,t,t,new A.R(w,t,t,v,t,t,B.r),t,t,t,t,L.nc,t,t,t)],u),B.bx,t,4,8),B.P,A.d(j,t,t,t,t,t,A.Y(t,t,m.B(0.62),t,t,t,t,t,t,t,t,13,t,t,t,t,1.35,!0,t,t,t,t,t,t,t,t),t,t,t)],u),B.m,t,B.e,B.f,0,B.j),1,t)
p=p.rx
return A.bd(r,q,A.z(A.a([n,B.ai,v,B.z,A.T(B.kt,p==null?m:p,t,t,20)],u),B.l,t,B.e,B.f,0,t,t),t,B.I,i,B.aU,!1,h)},
cW3(d){var x,w,v,u,t,s,r=y.J,q=A.f(d,B.c,r),p=q.gaWL()
q=q.gaWM()
r=A.f(d,B.c,r)
x=y.N
w=y.K
v=y.x
u=y.z
t=y.m
s=y.U
r=A.P(new A.E(A.a([A.a_(["title",r.gaWN(),"icon",B.T6,"isExpanded",!1,"questions",A.a([A.a_(["question",r.gaWB(),"answer",r.ga6j(),"homeScreenGuide",!0],x,w),A.a_(["question",r.gaWH(),"answer",r.gaWG(),"action",A.a_(["label",r.gaXs(),"route","chatgpt_mcp_guide"],x,x)],x,w)],v)],x,u),A.a_(["title",r.gaWA(),"icon",D.aU_,"isExpanded",!1,"questions",A.a([A.a_(["question",r.gaWU(),"answer",r.gaWV()],x,x),A.a_(["question",r.gaWW(),"answer",r.gaWX()],x,x)],t)],x,u),A.a_(["title",r.gaX9(),"icon",B.c0,"isExpanded",!1,"questions",A.a([A.a_(["question",r.gaWY(),"answer",r.gaWZ()],x,x),A.a_(["question",r.gaXp(),"answer",r.gaXq()],x,x),A.a_(["question",r.gaX_(),"answer",r.gaX0()],x,x)],t)],x,u),A.a_(["title",r.gaXe(),"icon",B.kw,"isExpanded",!1,"questions",A.a([A.a_(["question",r.gaXa(),"answer",r.gaXb()],x,x),A.a_(["question",r.gaXc(),"answer",r.gaXd()],x,x),A.a_(["question",r.gaX7(),"answer",r.gaX8()],x,x),A.a_(["question",r.gaX3(),"answer",r.gaX4(),"action",A.a_(["label",r.gaXt(),"route","seller_guidelines"],x,x)],x,w)],v)],x,u),A.a_(["title",r.gaXm(),"icon",B.d9,"isExpanded",!1,"questions",A.a([A.a_(["question",r.gaWS(),"answer",r.gaWT()],x,x),A.a_(["question",r.gaXh(),"answer",r.gaXi()],x,x)],t)],x,u)],y.t),new C.cUU(this,d),s),s.k("ai.E"))
return new E.iS(p,A.w(r,B.l,null,B.e,B.f,0,B.j),N.hd,q,null)},
cW2(d,e){var x,w,v,u,t,s=null,r=A.t(d),q=A.f(d,B.c,y.J)
q.toString
x=A.t(d).csD(B.a4)
q=q.gaWE()
w=r.ax
v=w.b
u=v.B(0.1)
t=A.G(8)
t=A.W(s,A.T(y.Z.a(e.i(0,"icon")),v,s,s,20),B.o,s,s,new A.R(u,s,s,t,s,s,B.r),s,s,s,s,B.ar,s,s,s)
w=A.d(A.bc(e.i(0,"title")),s,s,s,s,s,A.Y(s,s,w.k3,s,s,s,s,s,s,s,s,16,s,s,B.S,s,s,!0,s,s,s,s,s,s,s,s),s,s,s)
u=J.dB(y.D.a(e.i(0,"questions")),new C.cUT(this,d),y.l)
v=A.P(u,u.$ti.k("ai.E"))
return A.bd(s,s,new A.oo(x,H.EY(v,s,s,!1,q,t,!1,s,s,w,s),s),s,K.cI,s,B.I,!1,s)},
cXZ(d,e){var x,w,v,u,t,s,r,q,p,o,n,m=this,l=null,k="question",j="action",i=A.t(d).ax,h=i.ry
if(h==null){h=i.E
if(h==null)h=i.k3}h=h.B(0.2)
x=A.t(d).csD(B.a4)
w=A.bc(e.i(0,k))
v=i.k3
u=A.d(A.bc(e.i(0,k)),l,l,l,l,l,A.Y(l,l,v,l,l,l,l,l,l,l,l,14,l,l,B.a5,l,l,!0,l,l,l,l,l,l,l,l),l,l,l)
t=y.p
v=A.a([A.d(A.bc(e.i(0,"answer")),l,l,l,l,l,A.Y(l,l,v.B(0.702),l,l,l,l,l,l,l,l,14,l,l,l,l,1.5,!0,l,l,l,l,l,l,l,l),l,l,l)],t)
if(J.p(e.i(0,"homeScreenGuide"),!0)){s=A.f(d,B.c,y.J)
s.toString
r=m.cWd(d)
q=s.gQj()
p=y.s
o=A.a([s.ga6p(),s.ga6q(),s.ga6r(),s.gaX2()],p)
q=m.bKh(d,D.RN,s.ga6o(),o,q)
o=s.gQi()
n=A.a([s.ga6k(),s.gQg(),s.gaWD(),s.gQh()],p)
o=m.bKh(d,I.EV,s.gaWC(),n,o)
n=s.gH5()
p=A.a([s.ga6l(),s.gaWJ(),s.gH4(),s.gaWK()],p)
B.d.v(v,A.a([B.n,A.w(A.a([r,B.n,q,B.Q,o,B.Q,m.bKh(d,R.pm,s.gaWI(),p,n)],t),B.m,l,B.e,B.f,0,B.j)],t))}if(e.i(0,j)!=null){s=A.bc(J.ax(e.i(0,j),"label"))
r=A.co(i.b,l,l,l,l,B.er,new A.b9(A.G(8),B.B),l,l,l)
B.d.v(v,A.a([B.n,new A.ad(1/0,l,A.Q(l,!0,l,A.c6(A.d(A.bc(J.ax(e.i(0,j),"label")),l,l,l,l,l,D.bRG,l,l,l),l,new C.cUW(e,d),r),!1,l,l,l,!1,l,!1,l,l,l,l,l,l,l,l,l,l,l,s,l,l,l,l,l,l,l,l,l,l,l,l,l,l,l,l,l,l,l,l,l,l,l,l,l,l,l,l,l,l,B.p,l),l)],t))}return new A.cb(new A.R(i.k2,l,new A.dM(new A.aV(h,0.5,B.u,-1),B.B,B.B,B.B),l,l,l,B.r),B.at,new A.oo(x,H.EY(A.a([new A.J(B.C,A.w(v,B.m,l,B.e,B.f,0,B.j),l)],t),l,l,!1,w,l,!1,l,l,u,l),l),l)},
cWd(d){var x,w,v,u=null,t=A.t(d),s=A.f(d,B.c,y.J)
s.toString
x=t.ax.b
w=x.B(0.06)
v=A.G(8)
return new A.cb(new A.R(w,u,A.aN(x.B(0.16),B.u,1),v,u,u,B.r),B.at,new A.J(B.C,A.cZ(new C.cUV(this,s)),u),u)},
bKp(d,e,a0,a1,a2){var x,w,v,u,t,s,r,q,p,o,n,m=null,l=A.t(d).ax,k=l.k3,j=A.d(a2,m,m,m,m,m,A.Y(m,m,k,m,m,m,m,m,m,m,m,13,m,m,B.S,m,m,!0,m,m,m,m,m,m,m,m),B.ay,m,m),i=l.k2,h=A.G(22),g=l.ry,f=g==null
if(f){x=l.E
if(x==null)x=k}else x=g
x=A.aN(x.B(0.35),B.u,2)
w=A.a([new A.cq(0,B.aN,B.V.B(0.08),B.kF,18)],y.V)
if(f){g=l.E
if(g==null)g=k}g=A.W(m,m,B.o,m,m,new A.R(g.B(0.35),m,m,A.G(99),m,m,B.r),m,5,m,m,m,m,m,44)
f=l.RG
f=(f==null?i:f).B(0.58)
v=A.G(12)
u=l.rx
t=u==null
s=y.p
r=A.z(A.a([A.T(M.eM,t?k:u,m,m,12),B.aM,A.O(A.W(m,m,B.o,m,m,new A.R(i,m,m,A.G(99),m,m,B.r),m,10,m,m,m,m,m,m),1,m)],s),B.l,m,B.e,B.f,0,m,m)
l=l.b
q=A.G(14)
q=A.W(m,A.T(a1,B.M,m,m,28),B.o,m,m,new A.R(l,m,m,q,m,m,B.r),m,54,m,m,m,m,m,54)
p=l.B(0.12)
o=A.G(8)
n=A.aN(l.B(0.24),B.u,1)
o=A.W(m,A.d(a0,m,m,m,m,m,A.Y(m,m,l,m,m,m,m,m,m,m,m,12,m,m,B.F,m,m,!0,m,m,m,m,m,m,m,m),B.ay,m,m),B.o,m,m,new A.R(p,m,n,o,m,m,B.r),m,m,m,m,D.aMm,m,m,1/0)
return A.w(A.a([j,B.v,A.W(m,A.w(A.a([g,B.Q,A.O(new A.cb(new A.R(f,m,m,v,m,m,B.r),B.at,new A.J(B.ar,A.w(A.a([r,B.n,q,B.Q,o,B.bP,A.d(e,m,m,m,m,m,A.Y(m,m,t?k:u,m,m,m,m,m,m,m,m,11,m,m,m,m,m,!0,m,m,m,m,m,m,m,m),B.ay,m,m)],s),B.l,m,B.e,B.f,0,B.j),m),m),1,m)],s),B.l,m,B.e,B.f,0,B.j),B.o,m,m,new A.R(i,m,x,h,w,m,B.r),m,230,m,m,T.kp,m,m,150)],s),B.l,m,B.e,B.f,0,B.j)},
bKh(d,e,f,g,h){var x,w,v,u,t,s,r,q,p,o,n=null,m=A.t(d).ax,l=m.RG
l=(l==null?m.k2:l).B(0.32)
x=A.G(8)
w=m.ry
if(w==null){w=m.E
if(w==null)w=m.k3}w=A.aN(w.B(0.14),B.u,1)
v=m.b
u=v.B(0.1)
t=A.G(8)
s=m.k3
r=y.p
t=A.a([A.z(A.a([A.W(n,A.T(e,v,n,n,20),B.o,n,n,new A.R(u,n,n,t,n,n,B.r),n,n,n,n,B.ar,n,n,n),B.ah,A.O(A.d(h,n,n,n,n,n,A.Y(n,n,s,n,n,n,n,n,n,n,n,15,n,n,B.F,n,n,!0,n,n,n,n,n,n,n,n),n,n,n),1,n)],r),B.m,n,B.e,B.f,0,n,n),B.Q],r)
for(q=0;q<4;q=p){p=q+1
v=g[q]
u=A.t(d).ax
o=new A.c1(99,99)
o=A.W(B.as,A.d(""+p,n,n,n,n,n,U.aeP,n,n,n),B.o,n,n,new A.R(u.b,n,n,new A.e7(o,o,o,o),n,n,B.r),n,22,n,n,n,n,n,22)
u=u.k3.B(0.78)
v=A.a([new A.dk(B.aa,B.e,B.f,B.m,n,B.j,n,0,A.a([o,B.ah,new A.dq(1,B.aH,A.d(v,n,n,n,n,n,new A.ag(!0,u,n,n,n,n,14,n,n,n,n,n,1.45,n,n,n,n,n,n,n,n,n,n,n,n,n),n,n,n),n)],r),n)],r)
if(q!==3)v.push(B.v)
B.d.v(t,v)}t.push(B.Q)
m=m.rx
v=m==null
u=A.T(B.bb,v?s:m,n,n,16)
t.push(A.z(A.a([u,B.aM,A.O(A.d(f,n,n,n,n,n,A.Y(n,n,v?s:m,n,n,n,n,n,n,n,n,13,n,n,n,n,1.45,!0,n,n,n,n,n,n,n,n),n,n,n),1,n)],r),B.m,n,B.e,B.f,0,n,n))
return new A.cb(new A.R(l,n,w,x,n,n,B.r),B.at,new A.J(B.C,A.w(t,B.m,n,B.e,B.f,0,B.j),n),n)}}
var z=a.updateTypes([])
C.cV0.prototype={
$0(){var x=0,w=A.l(y.H),v,u=this
var $async$$0=A.h(function(d,e){if(d===1)return A.i(e,w)
for(;;)switch(x){case 0:v=u.a.n(new C.cV_())
x=1
break
case 1:return A.j(v,w)}})
return A.k($async$$0,w)},
$S:3}
C.cV_.prototype={
$0(){},
$S:0}
C.cUZ.prototype={
$2(d,e){var x,w,v=null,u=this.a,t=this.b,s=t.gaXn(),r=t.gaXo()
r=u.c7T(d,t.gaWF(),!0,B.ly,s,new C.cUX(d),r)
s=t.gaX5()
x=t.gaX6()
w=[r,u.c7T(d,t.gaX1(),!1,Q.xN,s,new C.cUY(d),x)]
if(e.b<560)return A.w(A.a([w[0],B.Q,w[1]],y.p),B.l,v,B.e,B.f,0,B.j)
return A.z(A.a([A.O(w[0],1,v),B.ah,A.O(w[1],1,v)],y.p),B.l,v,B.e,B.f,0,v,v)},
$S:56}
C.cUX.prototype={
$0(){A.aK(this.a,!1).f.aM(V.Sa(null,"0"),y.X)},
$S:0}
C.cUY.prototype={
$0(){A.aK(this.a,!1).f.aM(D.aDX,y.X)},
$S:0}
C.cUU.prototype={
$1(d){return this.a.cW2(this.b,d)},
$S:391}
C.cUT.prototype={
$1(d){return this.a.cXZ(this.b,d)},
$S:391}
C.cUW.prototype={
$0(){if(A.b6(J.ax(this.a.i(0,"action"),"route"))==="chatgpt_mcp_guide"){A.aK(this.b,!1).f.aM(O.Cn,y.X)
return}A.aK(this.b,!1).f.aM(D.bEb,y.X)},
$S:0}
C.cUV.prototype={
$2(d,e){var x,w,v,u,t=null,s=this.a,r=this.b,q=r.gaWR()
q=s.bKp(d,r.ga6n(),r.gyQ(),D.RN,q)
x=r.gaWO()
x=s.bKp(d,"Agora Market",r.ga6m(),S.Fu,x)
w=r.gaWQ()
v=[q,x,s.bKp(d,r.gaWP(),"Agora",I.Rs,w)]
if(e.b<620){s=y.p
r=A.a([],s)
for(u=0;u<3;++u){q=A.a([v[u]],s)
if(u!==2)q.push(B.Q)
B.d.v(r,q)}return A.w(r,B.a8,t,B.e,B.f,0,B.j)}s=y.p
r=A.a([],s)
for(u=0;u<3;++u){q=A.a([new A.dq(1,B.aH,v[u],t)],s)
if(u!==2)q.push(B.ah)
B.d.v(r,q)}return A.z(r,B.m,t,B.e,B.f,0,t,t)},
$S:56};(function inheritance(){var x=a.inheritMany,w=a.inherit
x(A.bU,[C.aED,C.aRs])
w(C.Ji,A.L)
w(C.b3c,A.S)
x(A.bu,[C.cV0,C.cV_,C.cUX,C.cUY,C.cUW])
x(A.c9,[C.cUZ,C.cUV])
x(A.bt,[C.cUU,C.cUT])})()
A.b0(b.typeUniverse,JSON.parse('{"aED":{"bU":["~"]},"aRs":{"bU":["~"]},"Ji":{"L":[],"m":[]},"b3c":{"S":["Ji"]}}'))
var y=(function rtii(){var x=A.C
return{J:x("bw"),Z:x("a0"),V:x("v<cq>"),x:x("v<a2<n,A>>"),m:x("v<a2<n,n>>"),t:x("v<a2<n,@>>"),s:x("v<n>"),p:x("v<m>"),D:x("a1<a2<n,@>>"),U:x("E<a2<n,@>,m>"),K:x("A"),N:x("n"),l:x("m"),z:x("@"),X:x("A?"),H:x("~")}})();(function constants(){D.aDX=new C.aED("CustomerIssueRoute",null,B.ae,B.ae,null,"")
D.aMm=new A.ar(8,7,8,7)
D.RN=new A.a0(58189,"MaterialIcons",!1)
D.aU_=new A.a0(984824,"MaterialIcons",!1)
D.bEb=new C.aRs("SellerGuidelinesRoute",null,B.ae,B.ae,null,"")
D.bRG=new A.ag(!0,B.M,null,null,null,null,null,B.a5,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null)})()};
(a=>{a["Wx4tqzp7V8Q/9EwrEAkuW9S/TMA="]=a.current})($__dart_deferred_initializers__);