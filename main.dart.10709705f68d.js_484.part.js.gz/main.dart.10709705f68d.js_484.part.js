((a,b)=>{a[b]=a[b]||{}})(self,"$__dart_deferred_initializers__")
$__dart_deferred_initializers__.current=function(a,b,c,$){var A,B
A=c[0]
B=c[381]
var z=a.updateTypes([]);(function constants(){B.adE=new A.aX(8,8,4,null,null)})()};
(a=>{a["Fh55xJRHcerKajIFO7MERidQnY0="]=a.current})($__dart_deferred_initializers__);