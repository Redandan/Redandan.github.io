((a,b)=>{a[b]=a[b]||{}})(self,"$__dart_deferred_initializers__")
$__dart_deferred_initializers__.current=function(a,b,c,$){var A,B
A=c[0]
B=c[374]
var z=a.updateTypes([]);(function constants(){B.F1=new A.a0(57847,"MaterialIcons",!1)})()};
(a=>{a["5PLF5Yjv+fe81V9ClnL4o1FI8iI="]=a.current})($__dart_deferred_initializers__);