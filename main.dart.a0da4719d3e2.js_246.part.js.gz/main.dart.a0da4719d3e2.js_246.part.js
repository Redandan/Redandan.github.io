((a,b)=>{a[b]=a[b]||{}})(self,"$__dart_deferred_initializers__")
$__dart_deferred_initializers__.current=function(a,b,c,$){var A,C,B={aX4:function aX4(d,e){this.a=d
this.b=e},ad0:function ad0(d,e,f,g,h,i,j,k,l){var _=this
_.c=d
_.d=e
_.go=f
_.id=g
_.k3=h
_.k4=i
_.p1=j
_.xr=k
_.a=l},bQW:function bQW(d){this.a=d}},E,D,F
A=c[0]
C=c[2]
B=a.updateHolder(c[206],B)
E=c[752]
D=c[241]
F=c[780]
B.aX4.prototype={
U(){return"_SwitchListTileType."+this.b}}
B.ad0.prototype={
u(d){var x,w,v,u,t,s,r,q,p=this,o=null
switch(p.p1.a){case 1:x=new A.Fh(!0,new D.ad_(p.c,p.d,o,o,o,o,o,o,o,o,o,o,o,o,o,C.cb,F.ada,p.xr,C.x,o,o,o,o,!1,o),o)
break
case 0:x=new A.Fh(!0,D.YZ(o,o,o,o,!1,C.x,o,o,o,C.cb,o,o,p.d,o,o,o,o,o,o,o,o,p.c),o)
break
default:x=o}A.a7T(d)
A:{w=new A.bb(o,x)
break A}v=w.a
u=w.b
t=A.q(d)
s=D.dq9(d)
w=s.a
w=w==null?o:w.ac(A.b3(y.c))
r=w
if(r==null)r=t.ax.y
w=p.d!=null
q=w?new B.bQW(p):o
return new A.p7(A.d6(!1,p.k4,p.k3,o,w,o,o,o,!1,o,o,v,o,o,o,o,o,q,!1,r,o,o,o,p.id,o,p.go,o,o,u,o),o)}}
var z=a.updateTypes([])
B.bQW.prototype={
$0(){var x=this.a
x.d.$1(!x.c)},
$S:0};(function inheritance(){var x=a.inherit
x(B.aX4,A.es)
x(B.ad0,A.x)
x(B.bQW,A.bw)})()
A.aV(b.typeUniverse,JSON.parse('{"ad0":{"x":[],"m":[]}}'))
var y={c:A.A("e9")};(function constants(){E.bZp=new B.aX4(0,"material")
E.bZq=new B.aX4(1,"adaptive")})()};
(a=>{a["4MdvI6/RuzdmDLvUmcW041fspJw="]=a.current})($__dart_deferred_initializers__);