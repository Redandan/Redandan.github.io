((a,b)=>{a[b]=a[b]||{}})(self,"$__dart_deferred_initializers__")
$__dart_deferred_initializers__.current=function(a,b,c,$){var A,B
A=c[0]
B=c[565]
var z=a.updateTypes([]);(function constants(){B.E8=new A.ar(9,5,9,5)
B.S2=new A.a0(58595,"MaterialIcons",!1)})()};
(a=>{a["IhQXwf1tYlmqIfPGAJcGWwYyzhE="]=a.current})($__dart_deferred_initializers__);