((a,b)=>{a[b]=a[b]||{}})(self,"$__dart_deferred_initializers__")
$__dart_deferred_initializers__.current=function(a,b,c,$){var A,B
A=c[0]
B=c[630]
var z=a.updateTypes([]);(function constants(){B.AD=new A.aX(1/0,16,6,null,null)})()};
(a=>{a["o2ySG8vVq+FHm+BcQTgv2brjXXw="]=a.current})($__dart_deferred_initializers__);