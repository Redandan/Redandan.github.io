((a,b)=>{a[b]=a[b]||{}})(self,"$__dart_deferred_initializers__")
$__dart_deferred_initializers__.current=function(a,b,c,$){var A,B
A=c[0]
B=c[321]
var z=a.updateTypes([]);(function constants(){B.RP=new A.a_(63237,"MaterialIcons",!1)})()};
(a=>{a["QIAg18BojaHQTzg7NjNOFVGj2Oc="]=a.current})($__dart_deferred_initializers__);