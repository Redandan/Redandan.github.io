((a,b)=>{a[b]=a[b]||{}})(self,"$__dart_deferred_initializers__")
$__dart_deferred_initializers__.current=function(a,b,c,$){var A,B
A=c[0]
B=c[374]
var z=a.updateTypes([]);(function constants(){B.F3=new A.a0(57847,"MaterialIcons",!1)})()};
(a=>{a["PRaHhQd68x/FORVbATZhSqbcVks="]=a.current})($__dart_deferred_initializers__);