((a,b)=>{a[b]=a[b]||{}})(self,"$__dart_deferred_initializers__")
$__dart_deferred_initializers__.current=function(a,b,c,$){var J,A,B,K,L,M,N,H,O,P,Q,R,I,S,F,T,U,V,W,E,X,Y,C={
e72(d){var w,v,u,t,s,r,q,p,o,n,m,l,k,j,i,h,g=null,f=d==null
if(f)w=g
else{v=d.b
w=v==null?g:B.c.G(v)}if((w==null?g:w.length!==0)===!0){w.toString
u=w}else u=y.l
if(f)t=g
else{v=d.d
t=v==null?g:B.c.G(v)}s=f?g:d.w
if(s==null)s=0
r=f?g:d.c
if(r==null)r=B.N
v=x.w
q=A.ei(D.WO,v)
q.A(0,new A.am(r,new C.cg0(),A.V(r).m("am<1>")))
q.S(0,u)
p=f?g:d.x
if(p==null)p=B.N
o=A.ei(D.W5,v)
o.A(0,new A.am(p,new C.cg1(),A.V(p).m("am<1>")))
o=A.U(o,A.C(o).c)
o.$flags=1
n=o
m=f?g:d.z
if(m==null)m=B.N
o=A.ei(D.Sr,v)
o.A(0,new A.am(m,new C.cg2(),A.V(m).m("am<1>")))
o=A.U(o,A.C(o).c)
o.$flags=1
l=f?g:d.y
if(l==null)l=B.xy
k=A.ei(D.Xh,v)
f=f?g:d.Q
if(f==null)f=B.N
k.A(0,new A.am(f,new C.cg3(),A.V(f).m("am<1>")))
f=l.j(0,"productImport")
if(f==null)f=B.N
k.A(0,J.fU(f,new C.cg4()))
f=A.U(k,A.C(k).c)
f.$flags=1
k=B.e.gli(n)
j=x.l
i=j.m("a4.E")
h=A.U(new A.am(D.VP,k,j),i)
h.$flags=1
k=A.U(new A.am(D.Wm,k,j),i)
k.$flags=1
v=A.ei(D.SP,v)
j=l.j(0,"sellerFulfillmentPreview")
if(j==null)j=B.N
v.A(0,J.fU(j,new C.cg5()))
v=A.U(v,A.C(v).c)
v.$flags=1
q=A.U(q,A.C(q).c)
q.$flags=1
if((t==null?g:t.length!==0)===!0){t.toString
j=t}else j=y.f
i=s>74?s:74
return new C.aLv(u,q,j,i,n,o,f,h,k,v)},
dTp(){return new C.Ez(null)},
De(d,e,f,g,h,i,j){return new C.aWQ(g,h,j,f,e,d,i,null)},
dH0(d,e){var w=A.V(d).m("am<1>"),v=new A.am(d,new C.dah(),w)
if(!v.gam(0).F())return new C.aZl(!1,e)
w=w.m("h9<a4.E,o>")
return C.drl(A.ei(new A.h9(v,new C.dai(),w),w.m("a4.E")),e)},
drl(d,e){var w=A.V(e).m("am<1>")
w=A.U(new A.am(e,new C.daj(J.dRB(d)),w),w.m("a4.E"))
w.$flags=1
return new C.aZl(!0,w)},
drG(d){var w,v
if(d==null)return null
w=d.er()
v=new C.dce()
return""+A.bB(w)+"-"+A.b(v.$1(A.bE(w)))+"-"+A.b(v.$1(A.cf(w)))+" "+A.b(v.$1(A.hP(w)))+":"+A.b(v.$1(A.mL(w)))},
aLv:function aLv(d,e,f,g,h,i,j,k,l,m){var _=this
_.a=d
_.b=e
_.c=f
_.d=g
_.e=h
_.f=i
_.r=j
_.w=k
_.x=l
_.y=m},
cg0:function cg0(){},
cg1:function cg1(){},
cg2:function cg2(){},
cg3:function cg3(){},
cg4:function cg4(){},
cg5:function cg5(){},
aY2:function aY2(d,e,f){this.c=d
this.d=e
this.a=f},
SM:function SM(d,e){this.c=d
this.a=e},
Ez:function Ez(d){this.a=d},
afO:function afO(){var _=this
_.e=_.d=$
_.c=_.a=null},
ccF:function ccF(d){this.a=d},
ccI:function ccI(d){this.a=d},
ccG:function ccG(d,e){this.a=d
this.b=e},
ccH:function ccH(d,e){this.a=d
this.b=e},
aLt:function aLt(d,e,f){this.a=d
this.b=e
this.c=f},
Rz:function Rz(d,e,f,g,h,i,j){var _=this
_.a=d
_.b=e
_.c=f
_.d=g
_.e=h
_.w=i
_.x=j},
aLu:function aLu(d,e,f,g,h,i){var _=this
_.c=d
_.d=e
_.e=f
_.f=g
_.r=h
_.a=i},
aQB:function aQB(d){this.a=d},
aWR:function aWR(d,e,f,g,h){var _=this
_.c=d
_.d=e
_.e=f
_.f=g
_.a=h},
aL3:function aL3(d,e){this.c=d
this.a=e},
aSz:function aSz(d,e){this.c=d
this.a=e},
aVn:function aVn(d,e){this.c=d
this.a=e},
aXv:function aXv(d,e){this.c=d
this.a=e},
d1L:function d1L(d){this.a=d},
a1l:function a1l(d,e){this.a=d
this.b=e},
aWQ:function aWQ(d,e,f,g,h,i,j,k){var _=this
_.c=d
_.d=e
_.e=f
_.f=g
_.r=h
_.w=i
_.x=j
_.a=k},
Sz:function Sz(d,e,f){this.c=d
this.d=e
this.a=f},
aZl:function aZl(d,e){this.a=d
this.b=e},
dah:function dah(){},
dai:function dai(){},
daj:function daj(d){this.a=d},
aOV:function aOV(d,e,f,g){var _=this
_.c=d
_.d=e
_.e=f
_.a=g},
crE:function crE(){},
aOU:function aOU(d,e,f,g){var _=this
_.c=d
_.d=e
_.e=f
_.a=g},
crD:function crD(d,e){this.a=d
this.b=e},
aOW:function aOW(d,e,f){this.c=d
this.d=e
this.a=f},
aUS:function aUS(d,e,f){this.c=d
this.d=e
this.a=f},
dce:function dce(){},
aVW:function aVW(d){this.a=d},
K7:function K7(d,e,f){this.c=d
this.d=e
this.a=f},
aYv:function aYv(d){this.a=d},
SN:function SN(d,e,f){this.c=d
this.d=e
this.a=f},
a_m:function a_m(d,e,f,g){var _=this
_.c=d
_.d=e
_.e=f
_.a=g},
cg7:function cg7(d){this.a=d}},D,Z,A_,A0,A1,G
J=c[1]
A=c[0]
B=c[2]
K=c[340]
L=c[528]
M=c[231]
N=c[280]
H=c[570]
O=c[283]
P=c[300]
Q=c[532]
R=c[486]
I=c[567]
S=c[571]
F=c[573]
T=c[565]
U=c[438]
V=c[393]
W=c[538]
E=c[251]
X=c[240]
Y=c[572]
C=a.updateHolder(c[22],C)
D=c[566]
Z=c[569]
A_=c[575]
A0=c[568]
A1=c[574]
G=c[312]
C.aLv.prototype={}
C.aY2.prototype={
u(b0){var w,v,u,t,s,r,q,p,o,n,m,l,k,j,i,h,g,f,e,d,a0,a1,a2,a3,a4,a5,a6,a7,a8=null,a9=A.e(b0,B.b,x.F)
a9.toString
w=A.q(b0)
v=w.ax
u=v.b
t=a9.gaOs()
s=a9.gaOr()
r=u.v(0.1)
q=A.B(8)
q=A.S(a8,A.N(T.wd,u,a8,a8,20),B.o,a8,a8,new A.O(r,a8,a8,q,a8,a8,B.r),a8,a8,a8,a8,B.ap,a8,a8,a8)
r=a9.gaOe()
p=w.ok
o=p.x
n=o==null
m=x.u
r=A.bo(B.a1,A.a([A.d(r,a8,a8,a8,a8,a8,n?a8:o.aj(B.A),a8,a8,a8),new C.Sz(a9.gaOg(),u,a8)],m),B.bG,a8,4,8)
l=this.c
k=a9.aOd(l.c,l.d)
p=p.Q
j=p==null
if(j)i=a8
else{i=v.rx
i=p.dZ(i==null?v.k3:i,1.45)}i=A.y(A.a([q,B.aa,A.Q(A.v(A.a([r,B.O,A.d(k,a8,a8,a8,a8,a8,i,a8,a8,a8)],m),B.m,a8,B.d,B.h,0,B.j),1,a8)],m),B.m,a8,B.d,B.h,0,a8,a8)
k=v.CW
r=k==null
q=(r?v.y:k).v(0.08)
h=A.B(8)
g=A.aE((r?v.y:k).v(0.22),B.u,1)
k=A.N(D.aK0,r?v.y:k,a8,a8,20)
f=a9.gaOo()
r=A.d(f,a8,a8,a8,a8,a8,n?a8:o.aj(B.A),a8,a8,a8)
f=l.y
e=a9.aOn(B.e.aS(f,", "))
if(j)d=a8
else{d=v.rx
d=p.dZ(d==null?v.k3:d,1.45)}d=A.y(A.a([k,B.aa,A.Q(A.v(A.a([r,B.O,A.d(e,a8,a8,a8,a8,a8,d,a8,a8,a8)],m),B.m,a8,B.d,B.h,0,B.j),1,a8)],m),B.m,a8,B.d,B.h,0,a8,a8)
e=a9.gaOq()
r=A.d(e,a8,a8,a8,a8,a8,n?a8:o.aj(B.A),a8,a8,a8)
k=a9.gaOp()
if(j)e=a8
else{e=v.rx
e=p.dZ(e==null?v.k3:e,1.45)}e=A.d(k,a8,a8,a8,a8,a8,e,a8,a8,a8)
k=A.a([],m)
for(a0=l.f,a1=a0.length,a2=0;a2<a0.length;a0.length===a1||(0,A.a8)(a0),++a2)k.push(new C.SM(a0[a2],a8))
k=A.bo(B.a1,k,B.a9,a8,8,8)
a0=a9.gaOm()
a0=A.d(a0,a8,a8,a8,a8,a8,n?a8:o.aj(B.A),a8,a8,a8)
a1=a9.gaOl()
if(j)a3=a8
else{a3=v.rx
a3=p.dZ(a3==null?v.k3:a3,1.45)}a3=A.d(a1,a8,a8,a8,a8,a8,a3,a8,a8,a8)
a1=A.a([],m)
for(a4=l.w,a5=a4.length,a2=0;a2<a4.length;a4.length===a5||(0,A.a8)(a4),++a2)a1.push(new C.SM(a4[a2],a8))
a1=A.bo(B.a1,a1,B.a9,a8,8,8)
a4=a9.gaOi()
a4=A.d(a4,a8,a8,a8,a8,a8,n?a8:o.aj(B.A),a8,a8,a8)
f=a9.aOh(B.e.aS(f,", "))
if(j)a5=a8
else{a5=v.rx
a5=p.dZ(a5==null?v.k3:a5,1.45)}a5=A.d(f,a8,a8,a8,a8,a8,a5,a8,a8,a8)
f=A.a([],m)
for(a6=l.x,a7=a6.length,a2=0;a2<a6.length;a6.length===a7||(0,A.a8)(a6),++a2)f.push(new C.SM(a6[a2],a8))
r=A.a([i,B.n,new A.bZ(new A.O(q,a8,g,h,a8,a8,B.r),B.aq,new A.I(B.F,d,a8),a8),B.n,r,B.O,e,B.U,k,B.n,a0,B.O,a3,B.U,a1,B.n,a4,B.O,a5,B.U,A.bo(B.a1,f,B.a9,a8,8,8)],m)
q=l.b
if(q.length!==0){l=a9.gaOk()
o=A.d(l,a8,a8,a8,a8,a8,n?a8:o.aj(B.A),a8,a8,a8)
l=a9.gaOj()
if(j)v=a8
else{n=v.rx
v=p.dZ(n==null?v.k3:n,1.45)}v=A.d(l,a8,a8,a8,a8,a8,v,a8,a8,a8)
l=A.a([],m)
for(p=q.length,a2=0;a2<q.length;q.length===p||(0,A.a8)(q),++a2)l.push(new C.SM(q[a2],a8))
B.e.A(r,A.a([B.n,o,B.O,v,B.U,A.bo(B.a1,l,B.a9,a8,8,8)],m))}r.push(B.n)
r.push(A.ca(D.aMI,a8,A.d(a9.gaOf(),a8,a8,a8,a8,a8,a8,a8,a8,a8),this.d,a8))
return E.jw(A.v(r,B.m,a8,B.d,B.h,0,B.j),I.Pf,s,t)}}
C.SM.prototype={
u(d){var w=null,v=A.q(d),u=v.ax.b,t=u.v(0.08),s=A.B(8),r=A.aE(u.v(0.22),B.u,1),q=v.ok.at
u=q==null?w:q.c8r(u,"monospace",B.Q)
return new A.bZ(new A.O(t,w,r,s,w,w,B.r),B.aq,new A.I(A0.MZ,A.d(this.c,w,w,w,w,w,u,w,w,w),w),w)}}
C.Ez.prototype={
O(){return new C.afO()}}
C.afO.prototype={
Y(){var w,v=this
v.a5()
w=$.av().$1$0(x.E)
v.d!==$&&A.b5()
v.d=w
v.e=v.Fb()},
Fb(){var w=0,v=A.l(x.a),u,t=2,s=[],r=this,q,p,o,n,m,l,k,j,i,h,g,f,e,d,a0,a1,a2,a3,a4,a5,a6,a7
var $async$Fb=A.h(function(a8,a9){if(a8===1){s.push(a9)
w=t}for(;;)switch(w){case 0:a1=null
a2=null
a3=null
a4=!1
t=4
o=r.d
o===$&&A.f()
w=7
return A.c(o.zX(),$async$Fb)
case 7:a1=a9
t=2
w=6
break
case 4:t=3
a5=s.pop()
a1=null
w=6
break
case 3:w=2
break
case 6:t=9
o=r.d
o===$&&A.f()
w=12
return A.c(o.Lf(),$async$Fb)
case 12:a2=a9
t=2
w=11
break
case 9:t=8
a6=s.pop()
o=A.u(a6)
if(o instanceof A.k6){q=o
a4=q.a===401}else a4=!0
w=11
break
case 8:w=2
break
case 11:t=14
o=r.d
o===$&&A.f()
w=17
return A.c(o.CT(),$async$Fb)
case 17:a3=a9
t=2
w=16
break
case 14:t=13
a7=s.pop()
o=A.u(a7)
if(o instanceof A.k6){p=o
a4=a4||p.a===401}else a4=!0
w=16
break
case 13:w=2
break
case 16:o=a1
m=a2
l=a3
k=a4
j=m==null
i=j?null:m.a
h=j?null:m.e
g=j?null:m.b
if(g==null)g=o==null?null:o.r
f=C.e72(g)
e=o==null
d=e?null:o.a
if(d==null)d=i==null?null:i.a
if(d==null)d="Agora User MCP"
o=e?null:o.c
if(o==null)o=i==null?null:i.c
if(o==null)o=y.n
if(j)m=null
else{m=m.c
m=m==null?null:m.d}e=h==null
a0=e?null:h.a
e=e?null:h.b
l=l==null?null:l.a
if(l==null)l=B.Vv
k=k&&j
u=new C.Rz(new C.aLt(f.a,d,o),f,m,a0,e,l,k)
w=1
break
case 1:return A.j(u,v)
case 2:return A.i(s.at(-1),v)}})
return A.k($async$Fb,v)},
c0O(){this.p(new C.ccF(this))},
afT(d,e){return this.cEk(d,e)},
cEk(d,e){var w=0,v=A.l(x.v),u,t=this,s
var $async$afT=A.h(function(f,g){if(f===1)return A.i(g,v)
for(;;)switch(w){case 0:w=3
return A.c(A.i9(new A.hG(e)),$async$afT)
case 3:s=t.c
if(s==null){w=1
break}A.a7(s,A.e(s,B.b,x.F).aNm(d),B.X,null)
case 1:return A.j(u,v)}})
return A.k($async$afT,v)},
bfI(d){return this.cE5(d)},
cE5(d){var w=0,v=A.l(x.v),u,t=this,s,r,q,p
var $async$bfI=A.h(function(e,f){if(e===1)return A.i(f,v)
for(;;)switch(w){case 0:p=t.c
p.toString
p=A.e(p,B.b,x.F)
s=d.a
r=d.b
w=3
return A.c(A.i9(new A.hG("Connector URL: "+s.a+"\n"+p.gcs()+": "+s.b+"\n"+p.go_()+": "+s.c+"\nManifest: "+r.c+"\nExpected minimum tools: "+r.d+"\nRequired tools: "+B.e.aS(r.e,", ")+"\nSeller fulfillment shipment tools: "+B.e.aS(r.x,", ")+"\nSeller fulfillment shipment scopes: "+B.e.aS(r.y,", ")+"\nSeller fulfillment boundary: capability check, shipping preview, and seller-confirmed logistics/platform shipment requests only; no cancellation, return, refund, wallet, inventory, or digital-delivery mutation.\nCompatible legacy URLs: "+B.e.aS(r.b,", "))),$async$bfI)
case 3:q=t.c
if(q==null){w=1
break}A.a7(q,p.gaNn(),B.X,null)
case 1:return A.j(u,v)}})
return A.k($async$bfI,v)},
bfR(d){return this.cEp(d)},
cEp(d){var w=0,v=A.l(x.v),u=this,t,s
var $async$bfR=A.h(function(e,f){if(e===1)return A.i(f,v)
for(;;)switch(w){case 0:s=u.c
s.toString
s=A.e(s,B.b,x.F)
t=d.b
w=2
return A.c(u.afT(s.gaOc(),s.aOt(d.a.a,t.c,t.d,B.e.aS(t.e,", "))),$async$bfR)
case 2:return A.j(null,v)}})
return A.k($async$bfR,v)},
bjI(d){return this.d7r(d)},
d7r(d){var w=0,v=A.l(x.v),u,t=2,s=[],r=this,q,p,o
var $async$bjI=A.h(function(e,f){if(e===1){s.push(f)
w=t}for(;;)switch(w){case 0:t=4
q=r.d
q===$&&A.f()
w=7
return A.c(q.b0w(d),$async$bjI)
case 7:q=r.c
if(q==null){w=1
break}A.a7(q,A.e(q,B.b,x.F).gaNH(),B.X,null)
r.c0O()
t=2
w=6
break
case 4:t=3
o=s.pop()
q=r.c
if(q==null){w=1
break}A.a7(q,A.e(q,B.b,x.F).gaNG(),B.Y,null)
w=6
break
case 3:w=2
break
case 6:case 1:return A.j(u,v)
case 2:return A.i(s.at(-1),v)}})
return A.k($async$bjI,v)},
u(d){var w,v=null,u=A.e(d,B.b,x.F),t=u.gaNL(),s=u.gaNK(),r=x.u
u=A.a([A.ca(G.cs,v,A.d(u.gYC(),v,v,v,v,v,v,v,v,v),this.gc0N(),v)],r)
w=this.e
w===$&&A.f()
return X.PS(u,A.a([A.awI(new C.ccI(this),w,x.a)],r),Z.P8,v,v,s,t)}}
C.aLt.prototype={}
C.Rz.prototype={}
C.aLu.prototype={
u(d){var w,v,u=this,t=null,s=A.e(d,B.b,x.F),r=s.gaNq(),q=s.gaNp(),p=x.u,o=A.a([],p)
if(u.d)B.e.A(o,A.a([H.kQ,B.n],p))
w=u.c
v=u.e
o.push(new C.a_m("Connector URL",w.a,v,t))
o.push(B.U)
o.push(new C.a_m(s.gcs(),w.b,v,t))
o.push(B.U)
o.push(new C.a_m(s.go_(),w.c,v,t))
o.push(B.n)
o.push(D.bWK)
o.push(B.n)
o.push(A.bo(B.a1,A.a([A.bF(S.DW,t,A.d(s.gazQ(),t,t,t,t,t,t,t,t,t),u.f,t),A.ca(G.cs,t,A.d(s.gYC(),t,t,t,t,t,t,t,t,t),u.r,t)],p),B.a9,t,8,8))
return E.jw(A.v(o,B.m,t,B.d,B.h,0,B.j),I.P6,q,r)}}
C.aQB.prototype={
u(d){var w,v,u,t,s,r,q,p=null,o=A.q(d),n=A.e(d,B.b,x.F)
n.toString
w=o.ax
v=w.CW
if(v==null)v=w.y
u=v.v(0.1)
t=A.aE(v.v(0.28),B.u,1)
s=A.B(8)
r=A.N(Y.w6,v,p,p,18)
n=n.gaNX()
q=o.ok.Q
return new A.bZ(new A.O(u,p,t,s,p,p,B.r),B.aq,new A.I(B.ap,A.y(A.a([r,B.B,A.Q(A.d(n,p,p,p,p,p,q==null?p:q.dZ(w.k3,1.35),p,p,p),1,p)],x.u),B.m,p,B.d,B.h,0,p,p),p),p)}}
C.aWR.prototype={
u(d){var w,v,u,t=this,s=null,r=A.e(d,B.b,x.F),q=r.gaO5(),p=r.gaO4(),o=x.u,n=A.a([],o)
if(t.d)B.e.A(n,A.a([H.kQ,B.n],o))
w=t.c
if(w.x){v=r.gaNb()
u=r.gaNc()
B.e.A(n,A.a([C.De(s,r.gYy(),u,Q.fJ,D.u1,s,v),D.kB],o))}n.push(new C.aXv(w.c,s))
n.push(D.kB)
n.push(new C.aL3(w,s))
n.push(D.kB)
n.push(new C.aSz(w,s))
n.push(D.kB)
n.push(new C.aVn(w,s))
v=w.w
if(v.length!==0)B.e.A(n,A.a([D.kB,new C.aOV(v,w.b,t.f,s)],o))
n.push(B.U)
n.push(new A.ci(B.cx,s,s,O.e7(G.cs,s,A.d(r.gaNV(),s,s,s,s,s,s,s,s,s),t.e,s),s))
return E.jw(A.v(n,B.l,s,B.d,B.h,0,B.j),L.jH,p,q)}}
C.aL3.prototype={
u(d){var w,v,u,t,s=null,r=A.e(d,B.b,x.F)
r.toString
w=this.c
v=w.d
u=C.drG(w.e)
if(v==="active"){w=r.gaNk()
t=u==null?r.gaNl():r.aNT(u)
return C.De(s,r.gaNe(),t,F.mq,D.zD,s,w)}if(v==="authorized"){w=r.gaNi()
t=u==null?r.gaNj():r.aNU(u)
return C.De(s,r.gaNh(),t,F.mq,D.u1,s,w)}if(v==="no_grant"){w=r.gYB()
t=r.gaNJ()
return C.De(s,r.gaNg(),t,F.mq,D.ad7,s,w)}w=r.gYB()
t=r.gaNI()
return C.De(s,r.gYz(),t,F.mq,D.ad7,s,w)}}
C.aSz.prototype={
u(d){var w,v,u,t,s,r,q,p,o,n=null,m=A.e(d,B.b,x.F)
m.toString
w=this.c
v=C.dH0(w.w,w.b.r)
A:{if(!v.a){w=new A.eF(D.u1,m.gaNO(),m.gaNP())
break A}u=v.b
w=u.length
if(w===0){w=new A.eF(D.zD,m.gaNQ(),m.gaNR())
break A}w=new A.eF(D.IH,m.gaNM(),m.aNN(B.e.aS(u,", ")))
break A}t=w.a
s=n
r=n
q=w.b
p=w.c
r=p
s=q
o=t
return C.De(n,s,r,B.bP,o,n,m.gaNS())}}
C.aVn.prototype={
u(d){var w,v,u,t,s,r,q,p,o,n=null,m=A.e(d,B.b,x.F)
m.toString
w=this.c
v=C.dH0(w.w,w.b.y)
A:{if(!v.a){w=new A.eF(D.u1,m.gaNt(),m.gaNu())
break A}u=v.b
w=u.length
if(w===0){w=new A.eF(D.zD,m.gaNv(),m.gaNw())
break A}w=new A.eF(D.IH,m.gaNr(),m.aNs(B.e.aS(u,", ")))
break A}t=w.a
s=n
r=n
q=w.b
p=w.c
r=p
s=q
o=t
return C.De(n,s,r,B.cT,o,n,m.gaNx())}}
C.aXv.prototype={
u(d){var w,v,u,t=null,s=A.e(d,B.b,x.F)
s.toString
w=this.c
if(w===!0){w=s.gaO6()
v=s.gaO7()
return C.De(t,s.gaNd(),v,B.om,D.zD,t,w)}if(w===!1){w=s.gaO8()
v=s.gaO9()
u=s.gaNf()
return C.De(s.gYA(),u,v,B.om,D.IH,new C.d1L(d),w)}w=s.gaOa()
v=s.gaOb()
return C.De(t,s.gYz(),v,B.om,D.u1,t,w)}}
C.a1l.prototype={
U(){return"_StatusTone."+this.b}}
C.aWQ.prototype={
u(d){var w,v,u,t,s,r,q=this,p=null,o=A.q(d)
switch(q.d.a){case 0:w=o.ax.b
break
case 1:w=o.ax
v=w.CW
w=v==null?w.y:v
break
case 2:w=o.ax.fy
break
case 3:w=o.ax.b
break
default:w=p}v=w.v(0.1)
u=A.B(8)
u=A.S(p,A.N(q.c,w,p,p,20),B.o,p,p,new A.O(v,p,p,u,p,p,B.r),p,p,p,p,B.ap,p,p,p)
v=o.ok
t=v.x
t=t==null?p:t.aj(B.A)
s=x.u
w=A.bo(B.a1,A.a([A.d(q.e,p,p,p,p,p,t,p,p,p),new C.Sz(q.r,w,p)],s),B.bG,p,4,8)
v=v.Q
if(v==null)v=p
else{t=o.ax
r=t.rx
v=v.dZ(r==null?t.k3:r,1.45)}v=A.a([w,B.O,A.d(q.f,p,p,p,p,p,v,p,p,p)],s)
w=q.w
if(w!=null&&q.x!=null)B.e.A(v,A.a([B.w,A.ca(A1.DT,p,A.d(w,p,p,p,p,p,p,p,p,p),q.x,p)],s))
return A.y(A.a([u,B.aa,A.Q(A.v(v,B.m,p,B.d,B.h,0,B.j),1,p)],s),B.m,p,B.d,B.h,0,p,p)}}
C.Sz.prototype={
u(d){var w=null,v=this.d,u=v.v(0.08),t=A.B(99)
return new A.bZ(new A.O(u,w,A.aE(v.v(0.24),B.u,1),t,w,w,B.r),B.aq,new A.I(K.m9,A.d(this.c,w,w,w,w,w,A.E(w,w,v,w,w,w,w,w,w,w,w,12,w,w,B.A,w,w,!0,w,w,w,w,w,w,w,w),w,w,w),w),w)}}
C.aZl.prototype={}
C.aOV.prototype={
u(d){var w,v,u,t,s,r,q,p=null,o=A.e(d,B.b,x.F)
o.toString
w=this.c
v=A.V(w).m("am<1>")
u=A.U(new A.am(w,new C.crE(),v),v.m("a4.E"))
if(u.length!==0)w=u
o=o.gaNF()
v=A.q(d).ok.x
t=x.u
v=A.a([A.d(o,p,p,p,p,p,v==null?p:v.aj(B.A),p,p,p),B.U],t)
for(o=this.d,s=this.e,r=0;r<w.length;++r){q=A.a([new C.aOU(w[r],o,s,p)],t)
if(r!==w.length-1)q.push(B.U)
B.e.A(v,q)}return A.v(v,B.m,p,B.d,B.h,0,B.j)}}
C.aOU.prototype={
u(d){var w,v,u,t,s,r,q,p,o,n=null,m=A.q(d),l=this.c,k=l.a,j=C.drG(l.f),i=C.drG(l.e)
if(j!=null)w=A.e(d,B.b,x.F).aNC(j)
else{v=x.F
w=i!=null?A.e(d,B.b,v).aNz(i):A.e(d,B.b,v).gaNy()}v=m.ax
u=v.RG
u=(u==null?v.k2:u).v(0.32)
t=A.B(8)
s=v.ry
if(s==null){s=v.E
if(s==null)s=v.k3}s=A.aE(s.v(0.14),B.u,1)
r=A.N(V.kM,v.b,n,n,20)
q=l.b
if((q==null?n:B.c.G(q).length!==0)===!0){q.toString
q=B.c.G(q)}else q="ChatGPT"
p=m.ok
o=p.x
q=A.d(q,n,n,n,n,n,o==null?n:o.aj(B.A),n,n,n)
p=p.Q
if(p==null)v=n
else{o=v.rx
v=p.a_(o==null?v.k3:o)}p=x.u
v=A.a([r,B.aa,A.Q(A.v(A.a([q,B.O,A.d(w,n,n,n,n,n,v,n,n,n),B.w,new C.aOW(l,this.d,n)],p),B.m,n,B.d,B.h,0,B.j),1,n)],p)
if(l.y===!0&&k!=null)B.e.A(v,A.a([B.aa,A.aK(n,n,n,n,n,D.aNz,n,n,new C.crD(this,k),n,n,n,n,A.e(d,B.b,x.F).gaNW(),n)],p))
return new A.bZ(new A.O(u,n,s,t,n,n,B.r),B.aq,new A.I(B.F,A.y(v,B.m,n,B.d,B.h,0,n,n),n),n)}}
C.aOW.prototype={
u(d){var w,v,u,t,s,r,q,p,o,n,m,l,k,j,i,h,g,f=null,e=A.e(d,B.b,x.F)
e.toString
w=A.q(d)
v=this.c.d
u=this.d
t=u.r
s=C.drl(v,t)
u=u.y
r=C.drl(v,u)
q=s.b
p=q.length===0
o=r.b
n=o.length===0
m=w.ax
l=p?m.b:m.fy
k=n?m.b:m.fy
j=p?e.gaNE():e.aND(B.e.aS(q,", "))
i=n?e.gaNB():e.aNA(B.e.aS(o,", "))
e=A.ei(t,x.w)
e.A(0,u)
u=x.u
t=A.a([A.bo(B.a1,A.a([new C.Sz(j,l,f),new C.Sz(i,k,f)],u),B.a9,f,8,8)],u)
if(v.length!==0){q=A.a([],u)
for(o=v.length,h=0;h<v.length;v.length===o||(0,A.a8)(v),++h){g=v[h]
q.push(new C.aUS(g,e.t(0,g),f))}B.e.A(t,A.a([B.O,A.bo(B.a1,q,B.a9,f,8,8)],u))}return A.v(t,B.m,f,B.d,B.h,0,B.j)}}
C.aUS.prototype={
u(d){var w,v,u,t,s=null,r=A.q(d),q=this.d,p=r.ax
if(q)w=p.b
else{v=p.rx
w=v==null?p.k3:v}p=w.v(q?0.1:0.06)
v=A.B(8)
u=A.aE(w.v(0.18),B.u,1)
t=r.ok.ax
if(t==null)q=s
else{t=t.aH(w,q?B.A:B.a0)
q=t}return new A.bZ(new A.O(p,s,u,v,s,s,B.r),B.aq,new A.I(B.bH,A.d(this.c,s,s,s,s,s,q,s,s,s),s),s)}}
C.aVW.prototype={
u(d){var w=null,v=A.e(d,B.b,x.F),u=v.gaO3(),t=v.gaO2()
return E.jw(A.v(A.a([new C.K7(1,v.gaNY(),w),B.w,new C.K7(2,v.gaNZ(),w),B.w,new C.K7(3,v.gaO_(),w),B.w,new C.K7(4,v.gaO0(),w),B.w,new C.K7(5,v.gaO1(),w)],x.u),B.m,w,B.d,B.h,0,B.j),W.r6,t,u)}}
C.K7.prototype={
u(d){var w=null,v=A.q(d),u=v.ax.b,t=u.v(0.1),s=A.B(8)
s=A.S(B.ar,A.d(""+this.c,w,w,w,w,w,A.E(w,w,u,w,w,w,w,w,w,w,w,12,w,w,B.A,w,w,!0,w,w,w,w,w,w,w,w),w,w,w),B.o,w,w,new A.O(t,w,w,s,w,w,B.r),w,24,w,w,w,w,w,24)
t=v.ok.z
u=t==null?w:t.azV(1.45)
return A.y(A.a([s,B.aa,A.Q(A.d(this.d,w,w,w,w,w,u,w,w,w),1,w)],x.u),B.m,w,B.d,B.h,0,w,w)}}
C.aYv.prototype={
u(d){var w=null,v=A.e(d,B.b,x.F),u=v.gaOZ(),t=v.gaOY()
return E.jw(A.v(A.a([new C.SN(v.gaOT(),v.gaOS(),w),D.kB,new C.SN(v.gaOV(),v.gaOU(),w),D.kB,new C.SN(v.gaOX(),v.gaOW(),w),D.kB,new C.SN(v.gaP0(),v.gaP_(),w)],x.u),B.l,w,B.d,B.h,0,B.j),R.fI,t,u)}}
C.SN.prototype={
u(d){var w=null,v=A.q(d),u=v.ax,t=u.rx,s=t==null,r=A.N(B.bb,s?u.k3:t,w,w,20),q=v.ok,p=q.x
p=p==null?w:p.aj(B.A)
p=A.d(this.c,w,w,w,w,w,p,w,w,w)
q=q.Q
if(q==null)u=w
else u=q.dZ(s?u.k3:t,1.45)
t=x.u
return A.y(A.a([r,B.aa,A.Q(A.v(A.a([p,B.O,A.d(this.d,w,w,w,w,w,u,w,w,w)],t),B.m,w,B.d,B.h,0,B.j),1,w)],t),B.m,w,B.d,B.h,0,w,w)}}
C.a_m.prototype={
u(d){var w,v,u,t,s,r,q,p=null,o=A.q(d),n=o.ax,m=n.RG
m=(m==null?n.k2:m).v(0.42)
w=A.B(8)
v=n.ry
if(v==null){v=n.E
if(v==null)v=n.k3}v=A.aE(v.v(0.14),B.u,1)
u=this.c
t=this.d
s=o.ok
r=s.at
if(r==null)r=p
else{q=n.rx
r=r.aH(q==null?n.k3:q,B.A)}r=A.d(u,p,p,p,p,p,r,p,p,p)
s=s.z
q=x.u
return new A.bZ(new A.O(m,p,v,w,p,p,B.r),B.aq,new A.I(B.F,A.y(A.a([A.Q(A.P(p,p,p,new A.kA(!0,A.v(A.a([r,B.O,N.m6(t,p,s==null?p:s.Vy(n.k3,B.Q,1.4),p)],q),B.m,p,B.d,B.h,0,B.j),p),!0,p,p,p,!1,p,!1,p,p,p,p,p,p,p,p,p,p,p,u+": "+t,p,p,p,p,p,p,p,p,p,p,p,p,p,p,p,p,p,p,p,p,p,p,p,p,p,p,p,p,p,p,B.p,p),1,p),B.aa,M.dyL(A_.rf,new C.cg7(this),A.e(d,B.b,x.F).aNo(u))],q),B.m,p,B.d,B.h,0,p,p),p),p)}}
var z=a.updateTypes(["~()","T<~>(o,o)","T<~>(o)","cj(M,hs<Rz>)"])
C.cg0.prototype={
$1(d){return B.c.G(d).length!==0},
$S:12}
C.cg1.prototype={
$1(d){return B.c.G(d).length!==0},
$S:12}
C.cg2.prototype={
$1(d){return B.c.G(d).length!==0},
$S:12}
C.cg3.prototype={
$1(d){return B.c.G(d).length!==0},
$S:12}
C.cg4.prototype={
$1(d){return B.c.G(d).length!==0},
$S:12}
C.cg5.prototype={
$1(d){return B.c.G(d).length!==0},
$S:12}
C.ccF.prototype={
$0(){var w=this.a
w.e=w.Fb()},
$S:0}
C.ccI.prototype={
$2(d,e){var w,v,u,t=null,s=e.b
if(s==null)s=D.bV6
w=e.a===B.qs
v=this.a
u=v.gc0N()
return A.v(A.a([new C.aLu(s.a,w,v.gcEj(),new C.ccG(v,s),u,t),B.a4,new C.aY2(s.b,new C.ccH(v,s),t),B.a4,new C.aWR(s,w,u,v.gd7q(),t),B.a4,D.bYJ,B.a4,D.bZG],x.u),B.aj,t,B.d,B.h,0,B.j)},
$S:z+3}
C.ccG.prototype={
$0(){return this.a.bfI(this.b)},
$S:0}
C.ccH.prototype={
$0(){return this.a.bfR(this.b)},
$S:0}
C.d1L.prototype={
$0(){return A.aL(this.a,!1).f.aG(B.pR,x.q)},
$S:0}
C.dah.prototype={
$1(d){return d.x!==!1},
$S:538}
C.dai.prototype={
$1(d){return d.d},
$S:1684}
C.daj.prototype={
$1(d){return!this.a.t(0,d)},
$S:12}
C.crE.prototype={
$1(d){return d.x===!0},
$S:538}
C.crD.prototype={
$0(){return this.a.e.$1(this.b)},
$S:0}
C.dce.prototype={
$1(d){return B.c.c0(B.i.l(d),2,"0")},
$S:81}
C.cg7.prototype={
$0(){var w=this.a
return w.e.$2(w.c,w.d)},
$S:0};(function installTearOffs(){var w=a._instance_0u,v=a._instance_2u,u=a._instance_1u
var t
w(t=C.afO.prototype,"gc0N","c0O",0)
v(t,"gcEj","afT",1)
u(t,"gd7q","bjI",2)})();(function inheritance(){var w=a.inheritMany,v=a.inherit
w(A.G,[C.aLv,C.aLt,C.Rz,C.aZl])
w(A.by,[C.cg0,C.cg1,C.cg2,C.cg3,C.cg4,C.cg5,C.dah,C.dai,C.daj,C.crE,C.dce])
w(A.x,[C.aY2,C.SM,C.aLu,C.aQB,C.aWR,C.aL3,C.aSz,C.aVn,C.aXv,C.aWQ,C.Sz,C.aOV,C.aOU,C.aOW,C.aUS,C.aVW,C.K7,C.aYv,C.SN,C.a_m])
v(C.Ez,A.J)
v(C.afO,A.R)
w(A.bw,[C.ccF,C.ccG,C.ccH,C.d1L,C.crD,C.cg7])
v(C.ccI,A.c0)
v(C.a1l,A.es)})()
A.aV(b.typeUniverse,JSON.parse('{"aY2":{"x":[],"m":[]},"SM":{"x":[],"m":[]},"Ez":{"J":[],"m":[]},"afO":{"R":["Ez"]},"aLu":{"x":[],"m":[]},"aQB":{"x":[],"m":[]},"aWR":{"x":[],"m":[]},"aL3":{"x":[],"m":[]},"aSz":{"x":[],"m":[]},"aVn":{"x":[],"m":[]},"aXv":{"x":[],"m":[]},"aWQ":{"x":[],"m":[]},"Sz":{"x":[],"m":[]},"aOV":{"x":[],"m":[]},"aOU":{"x":[],"m":[]},"aOW":{"x":[],"m":[]},"aUS":{"x":[],"m":[]},"aVW":{"x":[],"m":[]},"K7":{"x":[],"m":[]},"aYv":{"x":[],"m":[]},"SN":{"x":[],"m":[]},"a_m":{"x":[],"m":[]}}'))
var y={n:"Let ChatGPT use your Agora account for shopping and seller MCP tools.",l:"https://agoramarketapi.purrtechllc.com/api/mcp/user/v6",f:"user-mcp-tools-2026-07-15-seller-fulfillment-preview-remaining"}
var x={F:A.A("bv"),x:A.A("w<o>"),u:A.A("w<m>"),E:A.A("Gm"),w:A.A("o"),l:A.A("am<o>"),a:A.A("Rz"),q:A.A("G?"),v:A.A("~")};(function constants(){var w=a.makeConstList
D.kB=new A.oV(20,null,null,null,null,null,null)
D.aK0=new A.X(62482,"MaterialIcons",!1)
D.aMI=new A.aq(U.iK,18,null,null,null)
D.aNz=new A.aq(P.Dl,18,null,null,null)
D.Sr=w(["getMyProductImportGuide","previewMyProductImport","requestBatchCreateMyProducts"],x.x)
D.SP=w(["agora:orders:read","agora:orders:write","offline_access"],x.x)
D.VP=w(["previewMyProductUpdate","requestUpdateMyProduct","setMyProductStock","bulkSetMyProductStatus","listMyLowStockProducts","listMyOutOfStockProducts"],x.x)
D.W5=w(["getMyMcpCapabilities","getMyProductImportGuide","previewMyProductImport","requestBatchCreateMyProducts","previewMyProductUpdate","requestUpdateMyProduct","setMyProductStock","bulkSetMyProductStatus","listMyLowStockProducts","listMyOutOfStockProducts","getMySellerFulfillmentCapabilities","previewShipMyOrder","requestShipMyOrderLogistics","requestShipMyOrderPlatform","previewCancelMySellerOrder","previewSubmitMyDigitalDeliveryProof","previewProcessMyReturnRequest","previewConfirmMyReturnReceived"],x.x)
D.Wm=w(["getMySellerFulfillmentCapabilities","previewShipMyOrder","requestShipMyOrderLogistics","requestShipMyOrderPlatform","previewCancelMySellerOrder","previewSubmitMyDigitalDeliveryProof","previewProcessMyReturnRequest","previewConfirmMyReturnReceived"],x.x)
D.WO=w(["https://agoramarketapi.purrtechllc.com/api/mcp/user/v5","https://agoramarketapi.purrtechllc.com/api/mcp/user/v4","https://agoramarketapi.purrtechllc.com/api/mcp/user/v3","https://agoramarketapi.purrtechllc.com/api/mcp/user/v2","https://agoramarketapi.purrtechllc.com/api/mcp/user"],x.x)
D.Xh=w(["agora:products:read","agora:products:write","offline_access"],x.x)
D.bV5=new C.aLt(y.l,"Agora User MCP",y.n)
D.bV7=new C.aLv(y.l,D.WO,y.f,74,D.W5,D.Sr,D.Xh,D.VP,D.Wm,D.SP)
D.bV6=new C.Rz(D.bV5,D.bV7,null,null,null,B.Vv,!1)
D.bWK=new C.aQB(null)
D.bYJ=new C.aVW(null)
D.zD=new C.a1l(0,"ready")
D.u1=new C.a1l(1,"warning")
D.IH=new C.a1l(2,"blocked")
D.ad7=new C.a1l(3,"neutral")
D.bZG=new C.aYv(null)})()};
(a=>{a["lC+3935q2tbKlJGlfR35SNMM5FA="]=a.current})($__dart_deferred_initializers__);