((a,b)=>{a[b]=a[b]||{}})(self,"$__dart_deferred_initializers__")
$__dart_deferred_initializers__.current=function(a,b,c,$){var A,B
A=c[0]
B=c[505]
var z=a.updateTypes([]);(function constants(){B.RG=new A.a0(57998,"MaterialIcons",!1)})()};
(a=>{a["rhiI9eGZj092kLzQJZ8YHL9kDDk="]=a.current})($__dart_deferred_initializers__);