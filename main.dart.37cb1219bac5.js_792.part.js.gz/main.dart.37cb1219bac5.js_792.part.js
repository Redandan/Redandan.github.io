((a,b)=>{a[b]=a[b]||{}})(self,"$__dart_deferred_initializers__")
$__dart_deferred_initializers__.current=function(a,b,c,$){var A,B
A=c[0]
B=c[732]
var z=a.updateTypes([]);(function constants(){B.SZ=new A.a0(984320,"MaterialIcons",!1)})()};
(a=>{a["fYpJChvtWG5JlPFi6csqOzDaNYM="]=a.current})($__dart_deferred_initializers__);