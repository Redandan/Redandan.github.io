((a,b)=>{a[b]=a[b]||{}})(self,"$__dart_deferred_initializers__")
$__dart_deferred_initializers__.current=function(a,b,c,$){var A,B
A=c[0]
B=c[389]
var z=a.updateTypes([]);(function constants(){B.eg=new A.ay(0,980,0,1/0)})()};
(a=>{a["H+wfqBKxYgdftKaZhGuzzjPJplA="]=a.current})($__dart_deferred_initializers__);