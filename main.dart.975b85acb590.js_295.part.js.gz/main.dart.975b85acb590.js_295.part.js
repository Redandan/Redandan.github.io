((a,b)=>{a[b]=a[b]||{}})(self,"$__dart_deferred_initializers__")
$__dart_deferred_initializers__.current=function(a,b,c,$){var A,B
A=c[0]
B=c[508]
var z=a.updateTypes([]);(function constants(){B.xz=new A.a0(57857,"MaterialIcons",!1)})()};
(a=>{a["oCZrfO7mJFrbteY/5dfp92EeFoc="]=a.current})($__dart_deferred_initializers__);