((a,b)=>{a[b]=a[b]||{}})(self,"$__dart_deferred_initializers__")
$__dart_deferred_initializers__.current=function(a,b,c,$){var J,A,B,E,C={IU:function IU(d,e){this.a=d
this.b=e},bB4:function bB4(d){this.a=d},bB5:function bB5(d){this.a=d},
e1K(d){var x=0,w=A.l(y.b)
var $async$e1K=A.h(function(e,f){if(e===1)return A.i(f,w)
for(;;)switch(x){case 0:throw A.o(A.cS("ImmutableBuffer.fromFilePath is not supported on the web."))
return A.j(null,w)}})
return A.k($async$e1K,w)},
e1G(d,e){var x=null
return new A.vd(A.a23(x,x,new C.IU(d,1)),x,x,x,x,x,x,x,B.d9,x,e,B.as,B.et,!1,!1,x)},
e1H(d,e){var x=null
return new A.vd(A.a23(x,x,new E.DM(d,1)),x,x,x,x,x,x,x,B.d9,x,e,B.as,B.et,!1,!1,x)}},D
J=c[1]
A=c[0]
B=c[2]
E=c[239]
C=a.updateHolder(c[217],C)
D=c[717]
C.IU.prototype={
uO(d){return new A.dr(this,y.o)},
z_(d,e){return A.S4(null,this.lK(d,e),d.a.gdz(),new C.bB4(this),d.b)},
wA(d,e){return A.S4(null,this.lK(d,e),d.a.gdz(),new C.bB5(this),d.b)},
lK(d,e){return this.dlw(d,e)},
dlw(d,e){var x=0,w=A.l(y.c),v,u=this,t,s,r,q
var $async$lK=A.h(function(f,g){if(f===1)return A.i(g,w)
for(;;)switch(x){case 0:s=u.a
x=3
return A.c(s.qF(0),$async$lK)
case 3:if(g===0){t=$.j9.lv$
t===$&&A.e()
t.PJ(d)
throw A.o(A.aB(s.l(0)+" is empty and cannot be loaded as an image."))}x=A.aq(s)===D.bXy?4:6
break
case 4:r=e
x=7
return A.c(C.e1K(s.gdz()),$async$lK)
case 7:g=r.$1(g)
x=5
break
case 6:r=e
q=A
x=9
return A.c(s.HS(),$async$lK)
case 9:x=8
return A.c(q.Dx(g),$async$lK)
case 8:g=r.$1(g)
case 5:v=g
x=1
break
case 1:return A.j(v,w)}})
return A.k($async$lK,w)},
p(d,e){if(e==null)return!1
if(J.ab(e)!==A.aq(this))return!1
return e instanceof C.IU&&e.a.gdz()===this.a.gdz()&&e.b===this.b},
gj(d){return A.X(this.a.gdz(),this.b,B.a,B.a,B.a,B.a,B.a,B.a,B.a,B.a,B.a,B.a,B.a,B.a,B.a,B.a,B.a,B.a,B.a,B.a)},
l(d){return'FileImage("'+this.a.gdz()+'", scale: '+B.h.Z(this.b,1)+")"}}
var z=a.updateTypes([])
C.bB4.prototype={
$0(){return A.a([A.dN("Path: "+this.a.a.gdz())],y.d)},
$S:46}
C.bB5.prototype={
$0(){return A.a([A.dN("Path: "+this.a.a.gdz())],y.d)},
$S:46};(function inheritance(){var x=a.inherit,w=a.inheritMany
x(C.IU,A.ii)
w(A.bu,[C.bB4,C.bB5])})()
A.b0(b.typeUniverse,JSON.parse('{"IU":{"ii":["IU"],"ii.T":"IU"}}'))
var y={c:A.C("j3"),b:A.C("tD"),d:A.C("v<kq>"),o:A.C("dr<IU>")};(function constants(){D.aRc=new A.a0(57717,"MaterialIcons",!1)
D.Tt=new A.at(D.aRc,null,null,null,null)
D.bXy=A.cX("qP")})()};
(a=>{a["PAqJjTo4Gh4tPxoLp/PwDWTj1dM="]=a.current})($__dart_deferred_initializers__);