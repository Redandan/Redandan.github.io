((a,b)=>{a[b]=a[b]||{}})(self,"$__dart_deferred_initializers__")
$__dart_deferred_initializers__.current=function(a,b,c,$){var J,B,D,A={
elE(d){return d.c},
ys(d){var x=d.d
if(!(x instanceof B.Nf))throw B.o(D.x)
return x},
a4d(d,e){var x=null,w=d.ay,v=w==null,u=v?x:w.a,t=e.b,s=!1
if(u===t.c){w=v?x:w.b
if(w===e.c){w=d.ch
v=w==null
u=v?x:w.a
if(u===t.a){w=v?x:w.c
t=w===t.b
w=t}else w=s}else w=s}else w=s
return w},
elD(d,e,f,g){var x,w
try{x=!1
if(g.$0())if(f===d.CW){x=A.ys(d).qS()
x=(x==null?null:x.hR()===e.hR())===!0}return x}catch(w){return!1}},
al1(d,e,f){var x=0,w=B.l(y.V),v,u,t,s,r,q
var $async$al1=B.h(function(g,h){if(g===1)return B.i(h,w)
for(;;)switch(x){case 0:q=new A.ckF(d,e,d.CW,f)
B.jo(q)
x=3
return B.c(d.d.dk(),$async$al1)
case 3:u=h
B.jo(q)
q=u==null
t=q?null:u.a
s=e.b
r=!0
if(t===s.a){t=q?null:u.c
if(t===s.b)if((q?null:u.f)==null)if((q?null:u.e)==null){t=(q?null:u.r)!=null
q=t}else q=r
else q=r
else q=r}else q=r
if(q)throw B.o(D.f8)
x=d.gdR()==null?4:5
break
case 4:x=6
return B.c(d.bF4(!1),$async$al1)
case 6:case 5:if(f.$0()){q=A.ys(d).qS()
q=(q==null?null:q.hR()===e.hR())!==!0||!A.a4d(d,e)}else q=!0
if(q)throw B.o(D.f8)
v=d.nq()
x=1
break
case 1:return B.j(v,w)}})
return B.k($async$al1,w)},
ckW(d,e,f){var x=0,w=B.l(y.K),v,u
var $async$ckW=B.h(function(g,h){if(g===1)return B.i(h,w)
for(;;)switch(x){case 0:if(e.d!==D.i7)throw B.o(D.x)
x=3
return B.c(A.al2(d,e,f),$async$ckW)
case 3:u=h.e
if(u==null)throw B.o(C.L1)
v=u
x=1
break
case 1:return B.j(v,w)}})
return B.k($async$ckW,w)},
ckX(d,e,f){var x=0,w=B.l(y.A),v,u
var $async$ckX=B.h(function(g,h){if(g===1)return B.i(h,w)
for(;;)switch(x){case 0:if(e.d!==D.i8)throw B.o(D.x)
x=3
return B.c(A.al2(d,e,f),$async$ckX)
case 3:u=h.r
if(u==null)throw B.o(C.L1)
v=u
x=1
break
case 1:return B.j(v,w)}})
return B.k($async$ckX,w)},
ckY(d,e,f){var x=0,w=B.l(y.f),v,u
var $async$ckY=B.h(function(g,h){if(g===1)return B.i(h,w)
for(;;)switch(x){case 0:x=3
return B.c(A.al2(d,e,f),$async$ckY)
case 3:u=h.w
if(u==null||!u.aYv(e))throw B.o(D.x)
v=u
x=1
break
case 1:return B.j(v,w)}})
return B.k($async$ckY,w)},
al2(d,e,f){var x=0,w=B.l(y.I),v,u,t,s
var $async$al2=B.h(function(g,h){if(g===1)return B.i(h,w)
for(;;)switch(x){case 0:u=d.e
t=A
s=d
x=3
return B.c(A.al1(d,e,f),$async$al2)
case 3:v=u.dO(new t.ckH(s,h,f,e),y.I)
x=1
break
case 1:return B.j(v,w)}})
return B.k($async$al2,w)},
eQ8(d){return new A.ckL(d)},
eQ9(d){return new A.ckM(d)},
eQa(d){return new A.ckN(d)},
a4c(d,e,f,g,h,i){var x=0,w=B.l(y.H),v,u,t
var $async$a4c=B.h(function(j,k){if(j===1)return B.i(k,w)
for(;;)switch(x){case 0:if(e.d!==h)throw B.o(D.x)
v=d.e
u=A
t=d
x=3
return B.c(A.al1(d,e,i),$async$a4c)
case 3:x=2
return B.c(v.dO(new u.ckC(t,k,i,e,h,f,g),y.P),$async$a4c)
case 2:return B.j(null,w)}})
return B.k($async$a4c,w)},
ckE(d,e,f){var x,w
try{x=A.ys(d)
w=x.qS()
w=w==null?null:w.hR()
if(w!==e.hR())B.T(D.f8)
x.b.$2("agora.webSession.binding.v2","")
if(x.qS()!=null)B.T(D.x)}finally{if(f==="CONSUMED"&&A.a4d(d,e)){d.nC()
d.sf0(D.eC)}}},
eQd(d,e,f,g){return d.e.dO(new A.ckU(d,e,g,f),y.N)},
ckF:function ckF(d,e,f,g){var _=this
_.a=d
_.b=e
_.c=f
_.d=g},
ckH:function ckH(d,e,f,g){var _=this
_.a=d
_.b=e
_.c=f
_.d=g},
ckG:function ckG(d,e,f,g){var _=this
_.a=d
_.b=e
_.c=f
_.d=g},
ckL:function ckL(d){this.a=d},
ckM:function ckM(d){this.a=d},
ckN:function ckN(d){this.a=d},
ckC:function ckC(d,e,f,g,h,i,j){var _=this
_.a=d
_.b=e
_.c=f
_.d=g
_.e=h
_.f=i
_.r=j},
ckD:function ckD(d,e,f,g){var _=this
_.a=d
_.b=e
_.c=f
_.d=g},
ckU:function ckU(d,e,f,g){var _=this
_.a=d
_.b=e
_.c=f
_.d=g},
ckV:function ckV(d,e,f,g){var _=this
_.a=d
_.b=e
_.c=f
_.d=g},
aWe(){return new A.Ng(C.agA,null,null)},
elO(d,e){var x,w,v,u,t,s,r,q,p="completionCode"
try{x=D.G.bD(d,null)
if(!y.a.b(x)){u=A.aWe()
return u}w=J.p(x.i(0,"status"),"ready")
v=J.p(x.i(0,"status"),"providerFailure")
u=B.dK(["status","flowId"],y.N)
if(w)J.c2(u,p)
if(e)J.c2(u,"purpose")
t=u
u=!0
if(!(!w&&!v))if(!(e&&!J.p(x.i(0,"purpose"),"binding"))){s=x
if(s.gJ(s)===t.a){u=x.gdr()
u=!u.fH(u,J.ezd(t))}}if(u){u=A.aWe()
return u}u=w?C.agz:C.c8p
s=B.bZ(x.i(0,"flowId"))
r=w?B.f_(x.i(0,p)):null
return new A.Ng(u,s,r)}catch(q){u=A.aWe()
return u}},
alh:function alh(d,e){this.a=d
this.b=e},
Ng:function Ng(d,e,f){this.a=d
this.b=e
this.c=f},
oy:function oy(d,e){this.a=d
this.b=e},
al5:function al5(d,e,f,g,h){var _=this
_.a=d
_.b=e
_.c=f
_.d=null
_.e=!1
_.r=_.f=null
_.w=!0
_.x=!1
_.y=0
_.as=_.Q=_.z=!1
_.at=g
_.k4$=0
_.ok$=h
_.p2$=_.p1$=0},
ckZ:function ckZ(d,e){this.a=d
this.b=e},
cl_:function cl_(d,e){this.a=d
this.b=e},
cl0:function cl0(d,e){this.a=d
this.b=e},
cl1:function cl1(d,e){this.a=d
this.b=e},
cl2:function cl2(d,e){this.a=d
this.b=e},
G1:function G1(d,e,f,g){var _=this
_.c=d
_.d=e
_.r=f
_.a=g},
amU:function amU(d,e,f){var _=this
_.d=$
_.e=d
_.f=e
_.r=f
_.x=_.w=null
_.y=!0
_.c=_.a=_.z=null},
cBM:function cBM(d){this.a=d},
cBy:function cBy(){},
cBx:function cBx(){},
cBA:function cBA(d){this.a=d},
cBz:function cBz(){},
cBB:function cBB(d){this.a=d},
cBC:function cBC(){},
cBE:function cBE(d){this.a=d},
cBF:function cBF(d){this.a=d},
cBG:function cBG(d){this.a=d},
cBH:function cBH(d){this.a=d},
cBI:function cBI(d,e){this.a=d
this.b=e},
cBJ:function cBJ(d){this.a=d},
cBK:function cBK(d){this.a=d},
cBL:function cBL(d){this.a=d},
cBD:function cBD(d){this.a=d},
beJ:function beJ(){},
eqU(){var x=b.G.__AGORA_WEB_SESSION_BINDING_ENTRY__
return(x==null?null:x)===!0},
f7I(){var x,w,v
if(!A.eqU())return null
try{w=b.G.__AGORA_TAKE_WEB_SESSION_BINDING__
x=w==null?null:w.call()
if(x==null)return null
w=A.elO(B.bb(x),!0)
return w}catch(v){w=A.aWe()
return w}}},C,E
J=c[1]
B=c[0]
D=c[2]
A=a.updateHolder(c[111],A)
C=c[308]
E=c[253]
A.alh.prototype={
W(){return"WebSessionOAuthCallbackStatus."+this.b}}
A.Ng.prototype={
pA(){return this.c=null},
l(d){return"WebSessionOAuthCallback[redacted]"}}
A.oy.prototype={
W(){return"WebSessionBindingReturnState."+this.b}}
A.al5.prototype={
cSb(d,e,f,g,h){var x,w,v,u,t=this
try{x=t.f=A.ys(t.a).qS()
w=!0
if(x!=null)if(!(g&&d==null))if(d!=null)x=x.d!==D.i7||d.a===C.agA||d.b!==x.a
else x=!1
else x=w
else x=w
if(x)t.at=C.qS
else{if(d==null)x=null
else{v=d.c
d.c=null
x=v}t.r=x}}catch(u){t.at=C.qS}finally{if(d!=null)d.c=null}x=t.a
t.x=x.ay!=null
x.at.H(0,t.gcfC())},
gQE(){var x=this.f
return(x==null?null:x.d)===D.h3},
gCq(){var x=this.f
return(x==null?null:x.d)===D.i8},
dkV(){var x,w,v,u=this
if(!u.w||u.f==null)return
x=u.a
w=x.ay==null
if(!(w&&u.x))if(!w){v=u.f
v.toString
v=!A.a4d(x,v)
x=v}else x=!1
else x=!0
if(x){u.d=u.r=null
if(!u.z&&u.gG2())u.at=C.hA
u.R()}u.x=!w},
gG2(){var x=this
return x.w&&x.b.$0()&&x.f!=null&&!C.bF3.t(0,x.at)},
dGK(d){var x,w=this
A:{if("CREATED"===d){if(w.gQE())x=C.vu
else x=w.gCq()?C.qU:C.Bj
break A}if("READY"===d){x=w.r==null?C.agg:C.qT
break A}if("CONSUMED"===d){x=C.qV
break A}if("CANCELLED"===d){x=C.vr
break A}if("EXPIRED"===d||"FAILED"===d){x=C.vs
break A}if("SUPERSEDED"===d){x=C.vt
break A}x=C.hA
break A}w.at=x
if(C.bFc.t(0,x))w.r=null},
Ni(d,e){return this.dzJ(d,e)},
cqs(d){return this.Ni(d,!1)},
dzJ(d,e){var x=0,w=B.l(y.H),v,u=this,t,s,r,q,p,o
var $async$Ni=B.h(function(f,g){if(f===1)return B.i(g,w)
for(;;)switch(x){case 0:p=u.a
o=u.f
o.toString
x=3
return B.c(A.eQd(p,o,e,new A.ckZ(u,d)),$async$Ni)
case 3:t=g
if(!(u.w&&u.b.$0()&&d===u.y)){x=1
break}u.dGK(t)
u.d=null
x=u.gQE()&&t==="CREATED"&&!e?4:5
break
case 4:o=u.f
o.toString
x=6
return B.c(A.ckY(p,o,new A.cl_(u,d)),$async$Ni)
case 6:s=g
if(!(u.w&&u.b.$0()&&d===u.y)){x=1
break}u.d=s
o=u.f
o=o==null?null:o.e
o.toString
o=D.b.aR(o,"0x")?D.fr:D.mB
x=7
return B.c(u.c.BO(o),$async$Ni)
case 7:r=g
o=!1
if(u.w&&u.b.$0()&&d===u.y){q=u.f
q.toString
if(s.aYv(q)){o=u.f
o.toString
o=A.a4d(p,o)
p=o}else p=o}else p=o
if(p){p=u.f
u.at=r==(p==null?null:p.e)?C.vv:C.vu}case 5:case 1:return B.j(v,w)}})
return B.k($async$Ni,w)},
ct(){var x=0,w=B.l(y.H),v,u=2,t=[],s=[],r=this,q,p,o
var $async$ct=B.h(function(d,e){if(d===1){t.push(e)
x=u}for(;;)switch(x){case 0:if(!(r.w&&r.b.$0())||r.z||!r.gG2()){x=1
break}q=++r.y
r.z=!0
r.R()
u=4
x=7
return B.c(r.cqs(q),$async$ct)
case 7:s.push(6)
x=5
break
case 4:u=3
o=t.pop()
if(r.w&&r.b.$0()&&q===r.y)r.at=C.hA
s.push(6)
x=5
break
case 3:s=[2]
case 5:u=2
if(r.w&&r.b.$0()&&q===r.y){r.z=!1
r.R()}x=s.pop()
break
case 6:case 1:return B.j(v,w)
case 2:return B.i(t.at(-1),w)}})
return B.k($async$ct,w)},
a3W(d){return this.dTa(d)},
yz(){return this.a3W(null)},
dTa(d){var x=0,w=B.l(y.H),v,u=2,t=[],s=[],r=this,q,p,o,n,m,l,k,j,i,h
var $async$a3W=B.h(function(e,f){if(e===1){t.push(f)
x=u}for(;;)switch(x){case 0:if(!(r.w&&r.b.$0())||r.z||r.r==null||!C.bEU.t(0,r.at)){x=1
break}q=++r.y
l=r.r
l.toString
p=l
r.r=null
r.z=!0
r.R()
u=4
if(r.gQE())k=A.eQa(r.a)
else{l=r.a
k=r.gCq()?A.eQ9(l):A.eQ8(l)}o=k
l=r.f
l.toString
x=7
return B.c(o.$4$isPageCurrent(l,p,d,new A.cl0(r,q)),$async$a3W)
case 7:if(r.w&&r.b.$0()&&q===r.y)r.at=C.qV
s.push(6)
x=5
break
case 4:u=3
i=t.pop()
n=B.u(i)
if(!(r.w&&r.b.$0()&&q===r.y)){s=[1]
x=5
break}m=n instanceof B.jl?n.b:""
if(J.p(m,"AUTH_TWO_FACTOR_REQUIRED")||J.p(m,"AUTH_TWO_FACTOR_INVALID")){l=r.f
l.toString
l=A.a4d(r.a,l)}else l=!1
x=l?8:10
break
case 8:r.r=p
r.Q=J.p(m,"AUTH_TWO_FACTOR_INVALID")
r.at=C.vw
x=9
break
case 10:r.as=r.gCq()&&J.p(m,"AUTHENTICATION_FAILED")
r.at=C.hA
u=12
x=15
return B.c(r.cqs(q),$async$a3W)
case 15:u=3
x=14
break
case 12:u=11
h=t.pop()
x=14
break
case 11:x=3
break
case 14:case 9:s.push(6)
x=5
break
case 3:s=[2]
case 5:u=2
if(r.w&&r.b.$0()&&q===r.y){r.z=!1
r.R()}x=s.pop()
break
case 6:case 1:return B.j(v,w)
case 2:return B.i(t.at(-1),w)}})
return B.k($async$a3W,w)},
bBg(d){return this.dTl(d)},
dTl(d){var x=0,w=B.l(y.H),v,u=this,t
var $async$bBg=B.h(function(e,f){if(e===1)return B.i(f,w)
for(;;)switch(x){case 0:t=!0
if(u.w&&u.b.$0())if(!u.z)if(u.gCq())if(u.at===C.qU){t=B.az("^[0-9]{6}$",!0,!1,!1,!1)
t=!t.b.test(d)}if(t){x=1
break}u.r=d
u.as=!1
u.at=C.qT
x=3
return B.c(u.yz(),$async$bBg)
case 3:case 1:return B.j(v,w)}})
return B.k($async$bBg,w)},
gbzI(){var x,w=this,v=!1
if(w.w&&w.b.$0()){x=w.f
if(x!=null)if(A.a4d(w.a,x)){v=w.d
v=(v==null?null:v.aYv(x))===!0}}return v},
bBh(){var x=0,w=B.l(y.H),v,u=2,t=[],s=[],r=this,q,p,o,n,m
var $async$bBh=B.h(function(d,e){if(d===1){t.push(e)
x=u}for(;;)switch(x){case 0:if(r.z||!r.gbzI()||r.at!==C.vu){x=1
break}q=++r.y
r.z=!0
r.e=!1
r.R()
u=4
o=r.f
o=o==null?null:o.e
o.toString
o=D.b.aR(o,"0x")?D.fr:D.mB
x=7
return B.c(r.c.Gi(o),$async$bBh)
case 7:p=e
if(!(r.w&&r.b.$0()&&q===r.y)||!r.gbzI()){s=[1]
x=5
break}o=r.f
o=o==null?null:o.e
if(!J.p(p,o))throw B.o(D.x)
r.at=C.vv
s.push(6)
x=5
break
case 4:u=3
m=t.pop()
if(r.w&&r.b.$0()&&q===r.y){r.e=!0
r.at=C.hA}s.push(6)
x=5
break
case 3:s=[2]
case 5:u=2
if(r.w&&r.b.$0()&&q===r.y){r.z=!1
r.R()}x=s.pop()
break
case 6:case 1:return B.j(v,w)
case 2:return B.i(t.at(-1),w)}})
return B.k($async$bBh,w)},
amG(){var x=0,w=B.l(y.H),v,u=2,t=[],s=[],r=this,q,p,o,n,m,l
var $async$amG=B.h(function(d,e){if(d===1){t.push(e)
x=u}for(;;)switch(x){case 0:if(r.z||!r.gbzI()||r.at!==C.vv){x=1
break}q=++r.y
n=r.d
n.toString
p=n
r.z=!0
r.e=!1
r.R()
u=4
n=r.f
n=n==null?null:n.e
n.toString
n=D.b.aR(n,"0x")?D.fr:D.mB
x=7
return B.c(r.c.Ku(0,n,p.b,p.c),$async$amG)
case 7:o=e
if(!(r.w&&r.b.$0()&&q===r.y)||!r.gbzI()){s=[1]
x=5
break}r.r=o
r.at=C.qT
r.z=!1
x=8
return B.c(r.yz(),$async$amG)
case 8:s.push(6)
x=5
break
case 4:u=3
l=t.pop()
if(r.w&&r.b.$0()&&q===r.y){r.r=null
r.e=!0
r.at=C.hA}s.push(6)
x=5
break
case 3:s=[2]
case 5:u=2
if(r.w&&r.b.$0()&&q===r.y){r.z=!1
r.R()}x=s.pop()
break
case 6:case 1:return B.j(v,w)
case 2:return B.i(t.at(-1),w)}})
return B.k($async$amG,w)},
Rx(d){return this.e7i(d)},
e7i(d){var x=0,w=B.l(y.H),v,u=2,t=[],s=[],r=this,q,p,o,n,m,l
var $async$Rx=B.h(function(e,f){if(e===1){t.push(f)
x=u}for(;;)switch(x){case 0:if(!(r.w&&r.b.$0())||r.z||!r.gCq()||r.at!==C.qU){x=1
break}q=++r.y
r.z=!0
r.R()
u=4
o=r.f
o.toString
x=7
return B.c(A.ckX(r.a,o,new A.cl1(r,q)),$async$Rx)
case 7:p=f
x=r.w&&r.b.$0()&&q===r.y?8:10
break
case 8:o=p
l=B.dV(0,0,o.d.ghQ(),0,0).a<o.c.a
if(l){x=11
break}else f=l
x=12
break
case 11:x=13
return B.c(d.$1(p.b),$async$Rx)
case 13:f=!f
case 12:o=f
x=9
break
case 10:o=!1
case 9:if(o)if(r.w&&r.b.$0()&&q===r.y)r.at=C.hA
s.push(6)
x=5
break
case 4:u=3
m=t.pop()
if(r.w&&r.b.$0()&&q===r.y)r.at=C.hA
s.push(6)
x=5
break
case 3:s=[2]
case 5:u=2
if(r.w&&r.b.$0()&&q===r.y){r.z=!1
r.R()}x=s.pop()
break
case 6:case 1:return B.j(v,w)
case 2:return B.i(t.at(-1),w)}})
return B.k($async$Rx,w)},
cRt(){var x,w=this
if(w.w)x=!w.gCq()&&!w.gQE()||!w.gG2()
else x=!0
if(x)return;++w.y
w.d=w.r=null
w.z=!1
w.at=C.hA
w.R()},
bFt(d){return this.eb8(d)},
eb8(d){var x=0,w=B.l(y.H),v,u=2,t=[],s=[],r=this,q,p,o,n,m
var $async$bFt=B.h(function(e,f){if(e===1){t.push(f)
x=u}for(;;)switch(x){case 0:if(!(r.w&&r.b.$0())||r.z||r.at!==C.Bj){x=1
break}q=++r.y
r.z=!0
r.R()
u=4
o=r.f
o.toString
x=7
return B.c(A.ckW(r.a,o,new A.cl2(r,q)),$async$bFt)
case 7:p=f
if(r.w&&r.b.$0()&&q===r.y)d.$1(p)
s.push(6)
x=5
break
case 4:u=3
m=t.pop()
if(r.w&&r.b.$0()&&q===r.y)r.at=C.hA
s.push(6)
x=5
break
case 3:s=[2]
case 5:u=2
if(r.w&&r.b.$0()&&q===r.y){r.z=!1
r.R()}x=s.pop()
break
case 6:case 1:return B.j(v,w)
case 2:return B.i(t.at(-1),w)}})
return B.k($async$bFt,w)},
a7(){var x=0,w=B.l(y.H),v,u=2,t=[],s=[],r=this,q,p,o
var $async$a7=B.h(function(d,e){if(d===1){t.push(e)
x=u}for(;;)switch(x){case 0:if(!r.gG2()){x=1
break}q=++r.y
r.d=r.r=null
r.z=!0
r.R()
u=4
x=7
return B.c(r.Ni(q,!0),$async$a7)
case 7:s.push(6)
x=5
break
case 4:u=3
o=t.pop()
if(r.w&&r.b.$0()&&q===r.y)r.at=C.hA
s.push(6)
x=5
break
case 3:s=[2]
case 5:u=2
if(r.w&&r.b.$0()&&q===r.y){r.z=!1
r.R()}x=s.pop()
break
case 6:case 1:return B.j(v,w)
case 2:return B.i(t.at(-1),w)}})
return B.k($async$a7,w)},
w2(){var x=this
x.w=!1;++x.y
x.d=x.r=null
x.z=!1
x.at=C.qS},
q(){var x=this
x.a.at.N(0,x.gcfC())
x.w2()
x.e_()}}
A.G1.prototype={
O(){var x=$.aa()
return new A.amU(new B.al(D.L,x),new B.al(D.L,x),new B.bg(null,y.w))},
c1m(){return A.f8j().$0()}}
A.amU.prototype={
awF(){var x,w=this,v=!1
if(w.c!=null)if(w.y){x=w.w
x=x==null?null:x.jE(!0).gP().a.Q
if(x==w.x){v=w.c
v.toString
v=B.ce(v,null,y.X)
v=v==null?null:v.gL()
v=v===!0}}return v},
X(){var x,w,v,u,t,s,r,q=this
q.a6()
$.ah.bs$.push(q)
v=q.a.c
if(v==null)v=$.am().$1$0(y.e).a
u=q.gdN_()
t=q.a
s=t.d
r=t.r
x=s?t.c1m():null
w=s
x=x
w=w
t=r==null?new B.a4H():r
t=new A.al5(v,u,t,C.agf,$.aa())
t.cSb(x,v,u,w,r)
t.a4(q.gcqt())
q.d!==$&&B.aL()
q.d=t
$.ah.y2$.push(new A.cBM(q))},
b0(){var x,w=this
w.by()
if(w.w==null){x=w.c
x.toString
x=B.aJ(x,!1).f.gkZ()
w.w=x
w.x=x.jE(!0).gP().a.Q
w.w.a4(w.gclm())}if(!w.awF())w.atc()},
dAN(){if(!this.awF())this.atc()},
atc(){var x,w=this
w.e.sC(D.a_)
w.f.sC(D.a_)
x=w.d
x===$&&B.e()
x.w2()
if(w.c!=null&&w.y)w.n(new A.cBy())},
cqu(){var x=this,w=x.d
w===$&&B.e()
if(!w.gCq()&&!w.gQE()){x.atc()
return}x.e.sC(D.a_)
x.f.sC(D.a_)
w.cRt()},
oo(d){var x=this.d
x===$&&B.e()
if(!x.gCq()&&!x.gQE())return
if(d===D.cz){if(this.awF()&&x.at===C.hA)x.ct()}else this.cqu()},
dMZ(){var x,w=this
if(w.c==null||!w.y)return
x=w.d
x===$&&B.e()
if(x.at!==C.vw)w.e.sC(D.a_)
if(x.at!==C.qU)w.f.sC(D.a_)
w.n(new A.cBx())},
cqv(d){var x,w,v=this
if(!v.awF())return
v.atc()
v.y=!1
x=v.w
x.toString
w=y.h
x.hV(0,d?B.a([D.cS],w):B.a([B.hZ(null,null)],w))},
i0(){this.y=!1
this.atc()
this.na()},
cg(){this.y=!0
this.dh()},
q(){var x,w,v=this
$.ah.iV(v)
x=v.w
if(x!=null)x.T(v.gclm())
x=v.z
if(x!=null)x.$0()
x=v.d
x===$&&B.e()
x.T(v.gcqt())
x.q()
x=v.e
w=$.aa()
x.ok$=w
x.k4$=0
x=v.f
x.ok$=w
x.k4$=0
v.a5()},
u(a1){var x,w,v,u,t,s,r,q,p,o,n,m,l,k,j,i,h,g,f,e=this,d=null,a0=B.f(a1,D.c,y.J)
a0.toString
x=e.d
x===$&&B.e()
w=x.at
v=w===C.vw
u=w===C.Bj
t=w===C.qT
s=w===C.qU
r=x.gCq()
q=x.gQE()
p=w===C.vu
o=w===C.vv
n=C.bFM.t(0,w)
if(q)m=a0.gzU()
else m=r?a0.gKa():a0.gFY()
A:{if(C.agf===w){l=a0.gRv()
break A}if(C.Bj===w){l=a0.gXA()
break A}if(C.qT===w){if(q)l=a0.gKb()
else l=r?a0.gWl():a0.gakC()
break A}if(C.qU===w){l=x.as?a0.gWm():a0.gWl()
break A}if(C.vu===w||C.vv===w){l=a0.gKb()
k=x.f
k=k==null?d:k.e
if(k==null)k=""
k=l+"\n"+k
l=k
break A}if(C.vw===w){l=x.Q?a0.gq0():a0.gvn()
break A}if(C.hA===w){l=q&&x.e?a0.gWo():a0.gWk()
break A}if(C.agg===w||C.qS===w){l=a0.gakE()
break A}if(C.qV===w){if(q)l=a0.gWx()
else l=r?a0.gakI():a0.gakF()
break A}if(C.vr===w){if(q)l=a0.gakL()
else l=r?a0.gakG():a0.gakB()
break A}if(C.vs===w){if(q)l=a0.gakN()
else l=r?a0.gakH():a0.gakD()
break A}if(C.vt===w){l=a0.gK9()
break A}l=d}k=x.z
j=a0.ghN()
if(p)i=a0.gakM()
else if(o)i=a0.gakO()
else i=u?a0.gXy():a0.ga3Y()
h=!v
if(!h||s){if(s){g=x.z?d:new A.cBA(e)
g=B.fn(B.d(a0.gHv(),d,d,d,d,d,d,d,d,d),C.c0D,g,d)
f=x.z
a0=B.w(B.a([g,B.bX(!1,d,!1,e.f,B.aK(d,d,d,d,d,d,d,d,!0,d,d,d,d,d,d,d,d,d,d,d,d,d,d,d,d,d,d,d,d,d,d,d,d,d,d,d,d,d,d,d,a0.goO(),!0,!0,!1,d,d,d,d,d,d,d,d,d,d,d,d,d,d),!1,!f,!1,d,d,C.c0E,D.aC,6,1,d,!1,d,d,d,d,d,!1,d,d,D.J,D.K,d,new A.cBB(a0))],y.p),D.l,d,D.e,D.H,0,D.j)}else a0=new B.VC(!0,!1,e.e,new A.cBC(),d)
a0=B.fK(d,a0,e.r)}else a0=d
if(p)g=new A.cBE(e)
else if(o)g=new A.cBF(e)
else if(u)g=new A.cBG(e)
else if(s)g=new A.cBH(e)
else g=t||v?new A.cBI(e,v):d
x=x.gG2()?new A.cBJ(e):d
h=!n&&!u&&!t&&h&&!s&&!p&&!o?new A.cBK(e):d
f=n?new A.cBL(e):d
return B.cni(k,j,!0,i,l,new A.cBD(e),x,g,d,h,f,a0,m)}}
A.beJ.prototype={}
var z=a.updateTypes(["~()","E()","Ng?()"])
A.ckF.prototype={
$0(){var x=this
return A.elD(x.a,x.b,x.c,x.d)},
$S:1}
A.ckH.prototype={
$0(){var x=0,w=B.l(y.I),v,u=this,t,s,r,q,p
var $async$$0=B.h(function(d,e){if(d===1)return B.i(e,w)
for(;;)switch(x){case 0:r=u.a
q=u.b
p=u.c
x=3
return B.c(r.j4(q,p),$async$$0)
case 3:t=u.d
x=4
return B.c(E.w7(r).FZ(t.b,t.a,new A.ckG(r,q,p,t),t.d),$async$$0)
case 4:s=e
r.fX(q,p)
v=s
x=1
break
case 1:return B.j(v,w)}})
return B.k($async$$0,w)},
$S:1548}
A.ckG.prototype={
$0(){var x=this,w=x.a,v=!1
if(w.dC(x.b))if(x.c.$0()){w=A.ys(w).qS()
w=(w==null?null:w.hR()===x.d.hR())===!0}else w=v
else w=v
return w},
$S:1}
A.ckL.prototype={
$4$isPageCurrent(d,e,f,g){return A.a4c(this.a,d,e,f,D.i7,g)},
$S:360}
A.ckM.prototype={
$4$isPageCurrent(d,e,f,g){return A.a4c(this.a,d,e,f,D.i8,g)},
$S:360}
A.ckN.prototype={
$4$isPageCurrent(d,e,f,g){return A.a4c(this.a,d,e,f,D.h3,g)},
$S:360}
A.ckC.prototype={
$0(){var x=0,w=B.l(y.P),v=this,u,t,s,r,q,p
var $async$$0=B.h(function(d,e){if(d===1)return B.i(e,w)
for(;;)switch(x){case 0:r=v.a
q=v.b
p=v.c
x=2
return B.c(r.j4(q,p),$async$$0)
case 2:u=v.d
t=new A.ckD(r,q,p,u)
x=3
return B.c(E.w7(r).FZ(u.b,u.a,t,u.d),$async$$0)
case 3:s=e
q=s.b
p=v.e
if(q!==(p!==D.i7?"CREATED":"READY"))throw B.o(C.L1)
if(p===D.h3){q=s.w
q=(q==null?null:q.aYv(u))!==!0}else q=!1
if(q)throw B.o(D.x)
switch(p.a){case 1:q=E.w7(r).gdT1()
break
case 2:q=A.elE(r).gdT5()
break
case 0:q=E.w7(r).gdSU()
break
default:q=null}x=4
return B.c(q.$5$isCurrent(u,s.c,v.f,v.r,t),$async$$0)
case 4:B.jo(t)
A.ckE(r,u,"CONSUMED")
return B.j(null,w)}})
return B.k($async$$0,w)},
$S:49}
A.ckD.prototype={
$0(){var x=this,w=x.a,v=!1
if(w.dC(x.b))if(x.c.$0()){w=A.ys(w).qS()
w=(w==null?null:w.hR()===x.d.hR())===!0}else w=v
else w=v
return w},
$S:1}
A.ckU.prototype={
$0(){var x=0,w=B.l(y.N),v,u=2,t=[],s=this,r,q,p,o,n,m,l,k,j,i,h
var $async$$0=B.h(function(d,e){if(d===1){t.push(e)
x=u}for(;;)switch(x){case 0:k=s.a
j=s.b
i=new A.ckV(k,j,k.CW,s.c)
B.jo(i)
x=k.as===D.i9&&k.ay!=null&&!A.a4d(k,j)?3:4
break
case 3:x=5
return B.c(k.d.dk(),$async$$0)
case 5:p=e
B.jo(i)
o=p==null?null:D.G.aw(p.A(),null)
n=k.ch
if(o==(n==null?null:D.G.aw(n.A(),null))){A.ckE(k,j,"SUPERSEDED")
v="SUPERSEDED"
x=1
break}throw B.o(D.f8)
case 4:r=null
u=7
x=10
return B.c(E.w7(k).FZ(j.b,j.a,i,j.d),$async$$0)
case 10:r=e
u=2
x=9
break
case 7:u=6
h=t.pop()
o=B.u(h)
if(o instanceof B.jl){q=o
if(q.b!=="BINDING_FLOW_EXPIRED")throw h
B.jo(i)
A.ckE(k,j,"EXPIRED")
v="EXPIRED"
x=1
break}else throw h
x=9
break
case 6:x=2
break
case 9:x=s.d&&!D.acM.t(0,r.b)?11:12
break
case 11:l=r.f
if(l==null)throw B.o(D.x)
x=13
return B.c(E.w7(k).bAR(j,l,i),$async$$0)
case 13:x=14
return B.c(E.w7(k).FZ(j.b,j.a,i,j.d),$async$$0)
case 14:r=e
case 12:B.jo(i)
if(D.acM.t(0,r.b))A.ckE(k,j,r.b)
v=r.b
x=1
break
case 1:return B.j(v,w)
case 2:return B.i(t.at(-1),w)}})
return B.k($async$$0,w)},
$S:394}
A.ckV.prototype={
$0(){var x=this
return A.elD(x.a,x.b,x.c,x.d)},
$S:1}
A.ckZ.prototype={
$0(){var x=this.a
return x.w&&x.b.$0()&&this.b===x.y},
$S:1}
A.cl_.prototype={
$0(){var x=this.a
return x.w&&x.b.$0()&&this.b===x.y},
$S:1}
A.cl0.prototype={
$0(){var x=this.a
return x.w&&x.b.$0()&&this.b===x.y},
$S:1}
A.cl1.prototype={
$0(){var x=this.a
return x.w&&x.b.$0()&&this.b===x.y},
$S:1}
A.cl2.prototype={
$0(){var x=this.a
return x.w&&x.b.$0()&&this.b===x.y},
$S:1}
A.cBM.prototype={
$1(d){var x=this.a
if(x.c==null)return
$.uG().a7M()
x.z=B.ayS(x.gdN0())
x=x.d
x===$&&B.e()
x.ct()},
$S:2}
A.cBy.prototype={
$0(){},
$S:0}
A.cBx.prototype={
$0(){},
$S:0}
A.cBA.prototype={
$0(){var x=this.a,w=x.d
w===$&&B.e()
x.a.toString
w.Rx(new A.cBz())
return null},
$S:0}
A.cBz.prototype={
$1(d){return B.uD(d,D.lK,"_self")},
$S:1550}
A.cBB.prototype={
$1(d){var x=B.az("^[0-9]{6}$",!0,!1,!1,!1),w=d==null?"":d
return x.b.test(w)?null:this.a.gWm()},
$S:12}
A.cBC.prototype={
$1(d){},
$S:15}
A.cBE.prototype={
$0(){var x=this.a.d
x===$&&B.e()
x.bBh()
return null},
$S:0}
A.cBF.prototype={
$0(){var x=this.a.d
x===$&&B.e()
x.amG()
return null},
$S:0}
A.cBG.prototype={
$0(){var x=this.a.d
x===$&&B.e()
x.bFt(B.f8i())
return null},
$S:0}
A.cBH.prototype={
$0(){var x,w=this.a,v=w.r.gaj()
if((v==null?null:v.eT())!==!0)return
v=w.f
x=v.a.a
v.sC(D.a_)
w=w.d
w===$&&B.e()
w.bBg(x)},
$S:0}
A.cBI.prototype={
$0(){var x,w,v=this,u=v.b
if(u){x=v.a.r.gaj()
x=(x==null?null:x.eT())!==!0}else x=!1
if(x)return
w=u?v.a.e.a.a:null
u=v.a
u.e.sC(D.a_)
u=u.d
u===$&&B.e()
u.a3W(w)},
$S:0}
A.cBJ.prototype={
$0(){var x=this.a.d
x===$&&B.e()
x.a7()
return null},
$S:0}
A.cBK.prototype={
$0(){var x=this.a.d
x===$&&B.e()
x.ct()
return null},
$S:0}
A.cBL.prototype={
$0(){return this.a.cqv(!0)},
$S:0}
A.cBD.prototype={
$0(){return this.a.cqv(!1)},
$S:0};(function installTearOffs(){var x=a._instance_0u,w=a._static_0
var v
x(v=A.al5.prototype,"gcfC","dkV",0)
x(v,"gdB","q",0)
x(v=A.amU.prototype,"gdN_","awF",1)
x(v,"gclm","dAN",0)
x(v,"gdN0","cqu",0)
x(v,"gcqt","dMZ",0)
w(A,"f8j","f7I",2)})();(function inheritance(){var x=a.mixin,w=a.inheritMany,v=a.inherit
w(B.bu,[A.ckF,A.ckH,A.ckG,A.ckC,A.ckD,A.ckU,A.ckV,A.ckZ,A.cl_,A.cl0,A.cl1,A.cl2,A.cBy,A.cBx,A.cBA,A.cBE,A.cBF,A.cBG,A.cBH,A.cBI,A.cBJ,A.cBK,A.cBL,A.cBD])
w(B.bt,[A.ckL,A.ckM,A.ckN,A.cBM,A.cBz,A.cBB,A.cBC])
w(B.eD,[A.alh,A.oy])
v(A.Ng,B.A)
v(A.al5,B.hz)
v(A.G1,B.K)
v(A.beJ,B.Q)
v(A.amU,A.beJ)
x(A.beJ,B.es)})()
B.b0(b.typeUniverse,JSON.parse('{"al5":{"b1":[]},"G1":{"K":[],"m":[]},"amU":{"Q":["G1"],"es":[]}}'))
var y=(function rtii(){var x=B.C
return{J:x("bv"),q:x("fL<oy>"),h:x("v<bV<A?>>"),p:x("v<m>"),w:x("bg<iB>"),a:x("a2<n,@>"),P:x("b8"),N:x("n"),O:x("H<n>"),I:x("VB"),A:x("Nb"),V:x("aW4"),K:x("po"),e:x("Bt"),f:x("Nk"),X:x("A?"),H:x("~")}})();(function constants(){C.qT=new A.oy(2,"confirm")
C.vw=new A.oy(6,"twoFactor")
C.bEU=new B.fL([C.qT,C.vw],y.q)
C.qS=new A.oy(12,"invalid")
C.qV=new A.oy(9,"succeeded")
C.vr=new A.oy(10,"cancelled")
C.vs=new A.oy(11,"expired")
C.vt=new A.oy(13,"retired")
C.bF3=new B.fL([C.qS,C.qV,C.vr,C.vs,C.vt],y.q)
C.bFc=new B.fL([C.qV,C.vr,C.vs,C.vt],y.q)
C.bFM=new B.fL([C.qV,C.vr,C.vs,C.qS,C.vt],y.q)
C.c0D=new B.H("bindingOpenTelegram",y.O)
C.c0E=new B.H("bindingTelegramCode",y.O)
C.agf=new A.oy(0,"checking")
C.Bj=new A.oy(1,"resume")
C.qU=new A.oy(3,"telegramCode")
C.vu=new A.oy(4,"walletConnect")
C.vv=new A.oy(5,"walletSign")
C.hA=new A.oy(7,"pending")
C.agg=new A.oy(8,"missingProof")
C.agz=new A.alh(0,"ready")
C.c8p=new A.alh(1,"providerFailure")
C.agA=new A.alh(2,"invalid")
C.L1=new B.jl(409,"BINDING_NOT_READY",!1)})()};
(a=>{a["WEPzKrGccvlo0wMiU34eyDUn3+w="]=a.current})($__dart_deferred_initializers__);