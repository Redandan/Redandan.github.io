((a,b)=>{a[b]=a[b]||{}})(self,"$__dart_deferred_initializers__")
$__dart_deferred_initializers__.current=function(a,b,c,$){var A,C,E,B={
e7Z(d,e,f,g){return new B.aAw(d,g,f,e,null)},
aAw:function aAw(d,e,f,g,h){var _=this
_.c=d
_.z=e
_.Q=f
_.as=g
_.a=h},
aZ7:function aZ7(d,e,f,g,h,i){var _=this
_.e=d
_.f=e
_.r=f
_.x=g
_.c=h
_.a=i},
b8_:function b8_(d,e,f,g,h,i,j,k){var _=this
_.el=d
_.em=e
_.e6=f
_.U=null
_.aI=g
_.b6=h
_.V$=i
_.dy=j
_.b=_.fy=null
_.c=0
_.y=_.d=null
_.z=!0
_.Q=null
_.as=!1
_.at=null
_.ay=$
_.ch=k
_.CW=!1
_.cx=$
_.cy=!0
_.db=!1
_.dx=$},
b3J:function b3J(d,e,f){this.e=d
this.c=e
this.a=f},
ask:function ask(d,e,f,g){var _=this
_.U=d
_.V$=e
_.dy=f
_.b=_.fy=null
_.c=0
_.y=_.d=null
_.z=!0
_.Q=null
_.as=!1
_.at=null
_.ay=$
_.ch=g
_.CW=!1
_.cx=$
_.cy=!0
_.db=!1
_.dx=$},
cyT:function cyT(d,e,f,g,h,i,j,k,l){var _=this
_.x=d
_.z=_.y=$
_.a=e
_.b=f
_.c=g
_.d=h
_.e=i
_.f=j
_.r=k
_.w=l}},D
A=c[0]
C=c[2]
E=c[788]
B=a.updateHolder(c[169],B)
D=c[789]
B.aAw.prototype={
u(d){var x,w,v,u,t,s,r,q,p,o,n,m,l=this,k=null
if(!l.Q)return l.as
d.a8(y.c)
x=A.t(d).p4
w=new B.cyT(d,k,k,6,16,k,C.fb,E.BR,k)
v=l.c
if(v==null)v=x.a
u=new A.my(v==null?w.gbru().fy:v,k,k,k,C.qv)
v=l.z
t=v!=null
if(t){s=x.d
if(s==null)s=16
r=x.e
if(r==null){r=A.t(d).ok.ax
r.toString}q=x.b
r=r.a0(q==null?w.gbru().go:q)
q=x.f
p=A.o4(new B.b3J(s,A.W(C.au,v,C.aR,k,k,u,k,k,k,k,q==null?C.fb:q,k,k,k),k),k,k,C.ex,!0,r,k,k,C.bH)}else{s=x.c
if(s==null)s=6
p=A.W(k,k,C.aR,k,k,u,k,s,k,k,k,k,k,s)}o=x.r
if(o==null)o=E.BR
n=d.a8(y.o).w===C.Y?D.bqf:D.bqB
v=x.w
m=(v==null?n:v).au(0,C.kF)
return new A.d_(C.aT,k,C.aO,C.o,A.a([l.as,A.kZ(0,new B.aZ7(o,t?m:C.O,s,t,p,k))],y.u),k)}}
B.aZ7.prototype={
bl(d){var x=this,w=new B.b8_(x.f,x.x,x.r,x.e,A.hm(d),null,new A.ck(),A.bq(y.d))
w.bk()
w.sca(null)
return w},
bE(d,e){var x=this
e.siA(x.e)
e.sfP(x.f)
e.secC(x.r)
e.sdZY(x.x)
e.sdT(A.hm(d))}}
B.b8_.prototype={
sfP(d){if(this.el.p(0,d))return
this.el=d
this.aC()},
sdZY(d){if(this.em===d)return
this.em=d
this.aC()},
secC(d){if(this.e6===d)return
this.e6=d
this.aC()},
dq(){var x,w,v,u,t=this,s=y.a.a(A.af.prototype.gaj.call(t))
t.fy=new A.ae(A.an(1/0,s.a,s.b),A.an(1/0,s.c,s.d))
t.V$.ex(C.eG,!0)
x=t.V$.gL()
w=t.aI.al(t.b6)
v=t.V$.b
v.toString
y.w.a(v)
u=t.el.au(0,w.md(new A.M(t.gL().a-t.e6,t.gL().b)))
v.a=t.em?u.aw(0,new A.M(0,x.b/2)):u},
eu(d){return new A.ae(A.an(1/0,d.a,d.b),A.an(1/0,d.c,d.d))},
fF(d,e){var x,w,v,u,t,s=this,r=s.V$
if(r==null)return null
x=r.it(C.eG,e)
if(x==null)return null
w=s.aR(C.b3,d,s.ge8())
v=s.aI.al(s.b6)
u=r.aR(C.b3,C.eG,r.ge8())
t=s.el.au(0,v.md(new A.M(w.a-s.e6,w.b)))
return x+(s.em?t.aw(0,new A.M(0,u.b/2)):t).b}}
B.b3J.prototype={
bl(d){var x=new B.ask(this.e,null,new A.ck(),A.bq(y.d))
x.bk()
x.sca(null)
return x}}
B.ask.prototype={
d7(d){return this.aR(C.by,d,this.gd4())},
d5(d){return Math.max(this.aR(C.ce,1/0,this.gdJ()),this.br_(d))},
d6(d){return this.aR(C.ce,d,this.gdJ())},
d3(d){return Math.max(this.U,this.bqZ(d))},
c8L(d,e){var x=Math.max(this.U,d.aR(C.ce,e.b,d.gdJ()))
return e.aaE(x,Math.max(d.aR(C.by,e.d,d.gd4()),x))},
c6E(d,e){var x,w=this.V$
w.toString
x=e.$2(w,this.c8L(w,d))
w=x.b
if(w>x.a)return new A.ae(w,w)
return x},
eu(d){return this.c6E(d,A.lD())},
fF(d,e){var x=this.V$
x.toString
return x.it(this.c8L(x,d),e)},
dq(){this.fy=this.c6E(y.a.a(A.af.prototype.gaj.call(this)),A.rU())}}
B.cyT.prototype={
gbru(){var x,w=this,v=w.z
if(v===$){v=w.y
if(v===$){x=A.t(w.x)
w.y!==$&&A.bf()
w.y=x
v=x}w.z!==$&&A.bf()
v=w.z=v.ax}return v},
gc7(){return this.gbru().fy},
gzn(){return this.gbru().go},
giW(){return A.t(this.x).ok.ax}}
var z=a.updateTypes(["a4(a4)"]);(function installTearOffs(){var x=a._instance_1u
var w
x(w=B.ask.prototype,"gdK","d7",0)
x(w,"gd4","d5",0)
x(w,"gdL","d6",0)
x(w,"gdJ","d3",0)})();(function inheritance(){var x=a.inherit,w=a.inheritMany
x(B.aAw,A.x)
w(A.cy,[B.aZ7,B.b3J])
x(B.b8_,A.Lw)
x(B.ask,A.agZ)
x(B.cyT,A.Yo)})()
A.b_(b.typeUniverse,JSON.parse('{"aAw":{"x":[],"m":[]},"aZ7":{"cy":[],"bA":[],"m":[]},"b8_":{"ak":[],"cb":["ak"],"af":[],"bw":[]},"b3J":{"cy":[],"bA":[],"m":[]},"ask":{"ak":[],"cb":["ak"],"af":[],"bw":[]},"exR":{"fb":[],"ct":[],"ch":[],"m":[]}}'))
var y={c:A.C("exR"),a:A.C("ay"),w:A.C("jS"),d:A.C("i_"),o:A.C("lh"),u:A.C("v<m>")};(function constants(){D.bqf=new A.M(4,-4)
D.bqB=new A.M(-4,-4)})()};
(a=>{a["7+zeiRlLLFiHpHBDxIYxd/44PhM="]=a.current})($__dart_deferred_initializers__);