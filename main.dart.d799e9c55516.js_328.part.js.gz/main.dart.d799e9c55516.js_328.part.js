((a,b)=>{a[b]=a[b]||{}})(self,"$__dart_deferred_initializers__")
$__dart_deferred_initializers__.current=function(a,b,c,$){var A,B
A=c[0]
B=c[407]
var z=a.updateTypes([]);(function constants(){B.lt=new A.a_(62589,"MaterialIcons",!1)})()};
(a=>{a["+cut7vZXzleN/DoX9E8o/drnLOI="]=a.current})($__dart_deferred_initializers__);