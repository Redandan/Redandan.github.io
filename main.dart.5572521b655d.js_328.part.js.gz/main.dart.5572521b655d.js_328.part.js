((a,b)=>{a[b]=a[b]||{}})(self,"$__dart_deferred_initializers__")
$__dart_deferred_initializers__.current=function(a,b,c,$){var C,B,A={aOn:function aOn(d,e,f,g,h,i){var _=this
_.a=d
_.b=e
_.c=f
_.d=g
_.e=h
_.f=i},aOo:function aOo(d,e,f,g,h,i){var _=this
_.a=d
_.b=e
_.c=f
_.d=g
_.e=h
_.f=i}},D
C=c[0]
B=c[2]
A=a.updateHolder(c[188],A)
D=c[673]
A.aOn.prototype={}
A.aOo.prototype={}
var z=a.updateTypes([]);(function inheritance(){var y=a.inheritMany
y(C.bV,[A.aOn,A.aOo])})()
C.b0(b.typeUniverse,JSON.parse('{"aOn":{"bV":["~"]},"aOo":{"bV":["~"]}}'));(function constants(){D.Sr=new C.a0(61259,"MaterialIcons",!1)
D.I1=new A.aOn("ProductImportPCRoute",null,B.ae,B.ae,null,"")
D.aav=new A.aOo("ProductImportRoute",null,B.ae,B.ae,null,"")})()};
(a=>{a["sqxaqqfC0TNbQOVWzccEZUNzB7E="]=a.current})($__dart_deferred_initializers__);